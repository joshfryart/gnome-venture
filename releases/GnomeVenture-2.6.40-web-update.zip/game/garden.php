<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/garden_logic.php';
require_once __DIR__ . '/includes/yard.php';
require_once __DIR__ . '/includes/catalog.php';
$u = require_login();
$uid = (int)$u['id'];
require_once __DIR__ . '/includes/breeding110.php'; breeding110_boot();   // v1.1.0: imports the hybrids once on an upgraded world

if (is_post()) {
    csrf_check();
    unset($_SESSION['nav_badges']);   // v1.4.0: any garden action refreshes the Garden "ready" badge
    refresh_energy($u);
    $do = (string)($_POST['do'] ?? '');
    $x = (int)($_POST['x'] ?? -1);
    $y = (int)($_POST['y'] ?? -1);
    // v1.4.0: every panel action returns to its own tab (Beds is the default)
    $tabOfDo = ['build' => 'bld', 'upgrade' => 'bld', 'pantry_buy' => 'bld', 'add_scraps' => 'bld', 'heap_out' => 'bld', 'collect' => 'bld',
                'hire' => 'help', 'dismiss' => 'help', 'crew_assign' => 'help', 'crew_recall' => 'help', 'crew_seeds' => 'help', 'crew_skip' => 'help', 'expand' => 'grow', 'sign_buy' => 'grow', 'sign_use' => 'grow'];
    if ($do === 'collect' && ($_POST['from'] ?? '') === 'yard') unset($tabOfDo['collect']);   // v1.9.7: tapping a glowing building on the yard collects and stays on the garden
    $postTab = $tabOfDo[$do] ?? (in_array((string)($_POST['t'] ?? ''), ['bld', 'an', 'help', 'grow'], true) ? (string)$_POST['t'] : 'beds');
    $tq = $postTab !== 'beds' ? '?t=' . $postTab : '';
    $back = 'garden.php' . ($x >= 0 ? "?sel=$x-$y" : $tq);

    if ($do === 'switch') {
        if (!switch_garden($uid, (int)($_POST['plot_id'] ?? 0))) flash('That isn’t your garden.', 'err');
        redirect('garden.php' . $tq);
    } elseif ($do === 'rename') {
        [$ok, $msg] = rename_garden($uid, active_plot_id($uid), (string)($_POST['name'] ?? ''));
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'build') {
        [$ok, $msg] = build_building($u, active_plot_id($uid), (string)($_POST['building'] ?? ''));
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'upgrade') {   // v0.7.95
        [$ok, $msg] = upgrade_building($u, active_plot_id($uid), (string)($_POST['building'] ?? ''));
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'pantry_buy') {   // v0.9.8: the Pantry, a Kitchen add-on
        [$ok, $msg] = pantry_buy($u, active_plot_id($uid));
        flash($msg, $ok ? 'ok' : 'err');
        redirect('garden.php?bld=kitchen#b-kitchen');
    } elseif ($do === 'collect_all') {   // v0.7.99
        [$ok, $msg] = collect_all_buildings($u, active_plot_id($uid));
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'add_scraps') {   // v0.9.4: Food Scraps from the satchel onto the compost heap
        [$ok, $msg] = add_food_scraps($u, active_plot_id($uid), 'all');
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'heap_out') {   // v0.9.4: what the heap makes
        [$ok, $msg] = set_heap_output($u, active_plot_id($uid), (string)($_POST['out'] ?? ''));
        flash($msg, $ok ? 'ok' : 'err');
    } elseif (in_array($do, ['skin_buy', 'skin_use'], true)) {   // v0.9.7: building looks
        $bk = (string)($_POST['building'] ?? '');
        [$ok, $msg] = $do === 'skin_buy' ? skin_buy($u, active_plot_id($uid), $bk, (string)($_POST['skin'] ?? ''))
                                         : skin_use($u, active_plot_id($uid), $bk, (string)($_POST['skin'] ?? ''));
        flash($msg, $ok ? 'ok' : 'err');
        redirect('garden.php?bld=' . urlencode(isset(BUILDINGS[$bk]) ? $bk : '') . '#b-' . urlencode($bk));
    } elseif (in_array($do, ['sign_buy', 'sign_use'], true)) {   // v0.9.7: garden signposts
        [$ok, $msg] = $do === 'sign_buy' ? sign_buy($u, active_plot_id($uid), (string)($_POST['style'] ?? ''))
                                         : sign_use($u, active_plot_id($uid), (string)($_POST['style'] ?? ''));
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'pick') {   // v1.0.0: pick a pest off a bed by hand
        [$ok, $msgs] = pest_pick($uid, $x, $y);
        foreach ($msgs as $m) flash($m, $ok ? 'ok' : 'err');
    } elseif ($do === 'pick_all') {
        [, $tiles] = load_plot($uid);
        $done = 0;
        $err = null;
        foreach ($tiles as $row) foreach ($row as $t) {
            if (empty($t['pest']) || empty($t['plant_id'])) continue;
            [$ok, $m] = pest_pick($uid, (int)$t['x'], (int)$t['y']);
            if (!$ok) { $err = end($m); break 2; }
            $done++;
        }
        if ($done) flash("🐛 You picked pests off $done bed" . ($done === 1 ? '' : 's') . '.', 'ok');
        if ($err) flash($err, 'err');
        if (!$done && !$err) flash('No pests to pick.', 'err');
    } elseif ($do === 'critter_feed') {   // v1.0.0: garden animals
        [$ok, $msg] = critter_feed($u, active_plot_id($uid), (string)($_POST['building'] ?? ''));
        flash($msg, $ok ? 'ok' : 'err');
        redirect('garden.php?bld=' . urlencode((string)($_POST['building'] ?? '')) . '#b-' . urlencode((string)($_POST['building'] ?? '')));
    } elseif ($do === 'critter_welcome') {
        [$ok, $msg] = critter_welcome($u, active_plot_id($uid), (string)($_POST['building'] ?? ''), (string)($_POST['name'] ?? ''));
        flash($msg, $ok ? 'ok' : 'err');
        redirect('garden.php?bld=' . urlencode((string)($_POST['building'] ?? '')) . '#b-' . urlencode((string)($_POST['building'] ?? '')));
    } elseif ($do === 'critter_rename') {
        [$ok, $msg] = critter_rename($u, active_plot_id($uid), (int)($_POST['critter'] ?? 0), (string)($_POST['name'] ?? ''));
        flash($msg, $ok ? 'ok' : 'err');
        redirect('garden.php?bld=' . urlencode((string)($_POST['building'] ?? '')) . '#b-' . urlencode((string)($_POST['building'] ?? '')));
    } elseif ($do === 'critter_hatch') {
        [$ok, $msg] = critter_hatch($u, active_plot_id($uid));
        flash($msg, $ok ? 'ok' : 'err');
        redirect('garden.php?bld=frog_pond#b-frog_pond');
    } elseif ($do === 'biddy') {   // v1.0.0: trade scraps for eggs at the fence
        [$ok, $msg] = biddy_trade($u, active_plot_id($uid), (int)($_POST['scraps'] ?? 0));
        flash($msg, $ok ? 'ok' : 'err');
        redirect('garden.php?an=1#biddy');
    } elseif ($do === 'clementine') {   // v1.2.0: trade scraps for goat milk at the fence
        [$ok, $msg] = clementine_trade($u, active_plot_id($uid), (int)($_POST['scraps'] ?? 0));
        flash($msg, $ok ? 'ok' : 'err');
        redirect('garden.php?an=1#biddy');
    } elseif ($do === 'percy') {   // v1.2.0: seeds for a far-off seed from Percy
        [$ok, $msg] = percy_trade($u, active_plot_id($uid), (int)($_POST['seed'] ?? 0));
        flash($msg, $ok ? 'ok' : 'err');
        redirect('garden.php?an=1#biddy');
    } elseif ($do === 'collect') {
        [$ok, $msg] = collect_building($u, active_plot_id($uid), (string)($_POST['building'] ?? ''));
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'hire') {
        flash('Hired helpers have gone home. Your pals do the garden work now: see the Crew tab.', 'err');   // v2.6.40
    } elseif ($do === 'crew_seeds' || $do === 'crew_skip') {
        require_once __DIR__ . '/includes/pal_crew.php';
        [$ok, $msg] = $do === 'crew_seeds' ? pcrew_set_seeds($u, active_plot_id($uid), (array)($_POST['seeds'] ?? [])) : pcrew_set_skip($u, active_plot_id($uid), (array)($_POST['skip'] ?? []));
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'crew_assign' || $do === 'crew_recall') {
        require_once __DIR__ . '/includes/pal_crew.php';
        $slotRole = (string)($_POST['role'] ?? '');
        if ($do === 'crew_assign') {
            $m = (string)($_POST['mode'] ?? '');
            [$ok, $msg] = pcrew_assign($u, active_plot_id($uid), $slotRole, (string)($_POST['pal'] ?? ''), $m === 'full' ? 'full' : 'timed', (int)$m, !empty($_POST['unequip']), (array)($_POST['seeds'] ?? []));
        } else {
            [$ok, $msg] = pcrew_recall($u, active_plot_id($uid), $slotRole);
        }
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'dismiss') {
        [$ok, $msg] = dismiss_helper($u, active_plot_id($uid), (int)($_POST['hire_id'] ?? 0));
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'expand') {
        [$ok, $msg] = expand_plot($uid);
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'weed_all') {
        [, $tiles] = load_plot($uid);
        $done = 0;
        $err = null;
        foreach ($tiles as $row) {
            foreach ($row as $t) {
                if ($t['method'] !== 'notill' || (int)$t['weeds'] < 5) continue;
                [$ok, $m] = garden_action($uid, 'weed', (int)$t['x'], (int)$t['y']);
                if (!$ok) { $err = end($m); break 2; }
                $done++;
            }
        }
        if ($done || !$err) flash($done ? "Weeded $done bed(s)." : 'No beds need weeding.', $done ? 'ok' : 'err');   // v0.7.61: just the real reason when tired
        if ($err) flash($err, 'err');
    } elseif ($do === 'water_all' || $do === 'harvest_all') {
        [, $tiles, $plants] = load_plot($uid);
        $done = 0;
        $all = [];
        $freeWater = $perkFree = false;
        if ($do === 'water_all') [$freeWater, $perkFree] = garden_claim_free_water($u, $uid, $tiles, $plants);
        foreach ($tiles as $row) {
            foreach ($row as $t) {
                if (!$t['plant_id']) continue;
                $info = tile_info($t, $plants[(int)$t['plant_id']]);
                if (($do === 'water_all' && $info['thirsty']) || ($do === 'harvest_all' && $info['ready'])) {
                    [$ok, $m] = garden_action($uid, $do === 'water_all' ? 'water' : 'harvest', (int)$t['x'], (int)$t['y']);
                    if (!$ok) {
                        $all[] = end($m);
                        break 2;
                    }
                    $done++;
                    if ($do === 'harvest_all') $all = array_merge($all, $m);
                }
            }
        }
        // v0.7.61: harvests fold into one summary; when the first square already failed (tired), only say why
        if ($do === 'harvest_all' && $done) {
            foreach (harvest_summary($all, $done) as $m) flash($m, str_contains($m, 'tired') ? 'err' : 'ok');
        } else {
            $GLOBALS['gv_free_water'] = false;
            if ($perkFree && !$done) q('UPDATE plots SET free_water_n = free_water_n - 1 WHERE id = ? AND free_water_n > 0', [active_plot_id($uid)]);   // v0.9.1: nothing watered, give the free use back
            if ($done || !$all) flash($done ? ($perkFree ? '💧 Your Bloomcaller touch watered ' . $done . ' plant(s) for free.' : ($freeWater ? '🛢️ The rain barrel watered ' . $done . ' plant(s) for free (once a day).' : "Watered $done plant(s).")) : 'Nothing needed doing.', $done ? 'ok' : 'err');
            foreach (array_unique($all) as $m) flash($m, str_contains($m, 'tired') ? 'err' : 'ok');
        }
    } elseif ($do === 'cellar') {   // v0.7.56: root cellar
        [$ok, $msg] = cellar_store($uid, $x, $y);
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'uncellar') {
        [$ok, $msg] = cellar_replant($uid, (int)($_POST['cellar_id'] ?? 0), $x, $y);
        flash($msg, $ok ? 'ok' : 'err');
    } elseif ($do === 'batch') {   // v0.7.54: one action on the squares picked in select mode
        $squares = [];
        foreach ((array)($_POST['sq'] ?? []) as $k) {
            if (is_string($k) && preg_match('/^(\d{1,3})-(\d{1,3})$/', $k, $mm)) $squares[$k] = [(int)$mm[1], (int)$mm[2]];
        }
        $squares = array_slice(array_values($squares), 0, 400);
        $act = (string)($_POST['act'] ?? '');
        $queue = [];
        if ($act === 'plant') {
            foreach ((array)($_POST['seed'] ?? []) as $id => $n) if ((int)$id > 0 && (int)$n > 0) $queue[] = [(int)$id, min(400, (int)$n)];
        } elseif ((int)($_POST['item_id'] ?? 0) > 0) {
            $queue[] = [(int)$_POST['item_id'], 0];
        }
        if (!$squares) {
            flash('Pick some squares first.', 'err');
        } else {
            // v1.2.2: picking every thirsty square and tapping Water counts as "Water all" (rain barrel III / Bloomcaller free water)
            $freeWater = $perkFree = false;
            if ($act === 'water') {
                [, $wt, $wp] = load_plot($uid);
                $picked = [];
                foreach ($squares as [$sx, $sy]) $picked[$sx . '-' . $sy] = true;
                $allIn = true;
                foreach ($wt as $row) foreach ($row as $t) {
                    if ($t['plant_id'] && isset($wp[(int)$t['plant_id']]) && tile_info($t, $wp[(int)$t['plant_id']])['thirsty'] && empty($picked[(int)$t['x'] . '-' . (int)$t['y']])) { $allIn = false; break 2; }
                }
                if ($allIn) [$freeWater, $perkFree] = garden_claim_free_water($u, $uid, $wt, $wp);
            }
            [$ok, $msgs] = garden_batch_action($uid, $act, $squares, $queue);
            $GLOBALS['gv_free_water'] = false;
            if ($perkFree && !$ok) q('UPDATE plots SET free_water_n = free_water_n - 1 WHERE id = ? AND free_water_n > 0', [active_plot_id($uid)]);   // nothing watered: give the free use back
            if ($freeWater && $ok) flash($perkFree ? '💧 Your Bloomcaller touch made that watering free.' : '🛢️ The rain barrel made that watering free (once a day).', 'ok');
            foreach ($msgs as $i => $m) flash($m, $ok && !str_contains($m, 'too tired') && !str_contains($m, 'ran out') ? 'ok' : 'err');
        }
        redirect('garden.php');
    } else {
        [$ok, $msgs] = garden_area_action($uid, $do, $x, $y, (int)($_POST['item_id'] ?? 0), (string)($_POST['reach'] ?? 'one'));
        foreach ($msgs as $m) flash($m, $ok ? 'ok' : 'err');
    }
    redirect($back);
}

refresh_energy($u);
$GLOBALS['CURRENT_USER'] = $u;
[$plot, $tiles, $plants] = load_plot($uid);
if (!$plot) {   // no garden yet (e.g. the welcome flow was skipped in Admin): set one up properly
    q('UPDATE users SET onboarded = 0 WHERE id = ?', [$uid]);
    redirect('welcome.php');
}
critter_ready_map((int)$plot['id']); critter_flush_news();   // v1.0.0: bring the animals up to date (a tadpole may have grown up) before the page starts
$known = known_plants($u);
$hasKit = tool_power($uid, 'soiltest') > 0;
$canNoTill = (int)$u['level'] >= (int)setting('notill_level');

$sel = null;
if (preg_match('/^(\d+)-(\d+)$/', (string)($_GET['sel'] ?? ''), $m)) {
    $sel = $tiles[(int)$m[2]][(int)$m[1]] ?? null;
}
$byCat = function (string $cat) use ($uid): array {
    return q('SELECT i.id, i.name, ui.qty, i.effects FROM user_items ui JOIN items i ON i.id = ui.item_id
              WHERE ui.user_id = ? AND ui.qty > 0 AND i.category = ? ORDER BY i.name', [$uid, $cat])->fetchAll();
};
$seeds = q('SELECT i.id, i.name, ui.qty, p.id AS plant_id, p.xp_per_harvest, p.min_soil, p.perennial, p.kind, p.nutrient, p.seasons FROM user_items ui
            JOIN items i ON i.id = ui.item_id JOIN plants p ON p.seed_item_id = i.id
            WHERE ui.user_id = ? AND ui.qty > 0 ORDER BY i.name', [$uid])->fetchAll();
// v0.8.6: during Wren's tour the quick radish comes first (the tour says radishes are quickest)
$ts = (int)q_val('SELECT tour_step FROM users WHERE id = ?', [$uid]);
if ($ts >= 1 && $ts <= 3) {
    usort($seeds, fn($a, $b) => (int)(stripos($b['name'], 'radish') === 0) <=> (int)(stripos($a['name'], 'radish') === 0));
}
// Saplings (v0.7.10) can be planted by anyone, known crop or not
foreach (q("SELECT i.id, i.name, ui.qty, i.effects FROM user_items ui JOIN items i ON i.id = ui.item_id
            WHERE ui.user_id = ? AND ui.qty > 0 AND i.category = 'sapling' ORDER BY i.name", [$uid])->fetchAll() as $sp) {
    $spid = (int)((json_decode((string)$sp['effects'], true) ?: [])['sapling'] ?? 0);
    $minSoil = q_val('SELECT min_soil FROM plants WHERE id = ?', [$spid]);
    $spp = q_one('SELECT min_soil, perennial, kind, nutrient, seasons FROM plants WHERE id = ?', [$spid]);
    if ($minSoil !== false && $minSoil !== null) $seeds[] = ['id' => $sp['id'], 'name' => '🌱 ' . $sp['name'], 'qty' => $sp['qty'], 'plant_id' => $spid, 'min_soil' => $minSoil, 'sapling' => 1,
        'perennial' => $spp['perennial'] ?? 0, 'kind' => 'tree', 'nutrient' => $spp['nutrient'] ?? null, 'seasons' => $spp['seasons'] ?? ''];
}
$soils = $byCat('soil');
$mulches = $byCat('mulch');
[$pages, $totalPages] = almanac_counts($uid);
$gardens = user_gardens($uid);
$here = null;
foreach ($gardens as $g) if ((int)$g['id'] === (int)$plot['id']) $here = $g;
$built = [];
foreach (q('SELECT * FROM garden_buildings WHERE plot_id = ?', [$plot['id']])->fetchAll() as $b) $built[$b['building']] = $b;
// v1.4.0: the page is split into tabs (?t=); the old ?bld= and ?an= links still land on their tab
$tab = (string)($_GET['t'] ?? '');
if (!in_array($tab, ['beds', 'bld', 'an', 'help', 'grow'], true)) $tab = isset($_GET['bld']) ? 'bld' : (isset($_GET['an']) ? 'an' : 'beds');

function action_form(string $do, array $t, string $label, int $cost, string $extra = '', string $confirm = ''): string
{
    return '<form method="post" class="inline"' . ($confirm ? ' data-confirm="' . e($confirm) . '"' : '') . '>' . csrf_field()
        . '<input type="hidden" name="do" value="' . e($do) . '"><input type="hidden" name="x" value="' . (int)$t['x'] . '">'
        . '<input type="hidden" name="y" value="' . (int)$t['y'] . '">' . $extra
        . '<button class="btn act">' . e($label) . ' <span class="cost">⚡' . $cost . '</span></button></form> ';
}

/**
 * v0.7.86: the energy a harvest over the squares a tool reaches can take ("2", or "1–3" when the crops differ in tier).
 * Same squares as garden_area_action(): this square's row neighbours, or the whole row.
 */
function harvest_cost_range(array $t, int $reach): string
{
    $sql = 'SELECT DISTINCT plant_id FROM plot_tiles WHERE plot_id = ? AND yy = ? AND plant_id IS NOT NULL';
    $args = [(int)$t['plot_id'], (int)$t['yy']];
    if ($reach < 99) {
        $sql .= ' AND ABS(yx - ?) <= 1';
        $args[] = (int)$t['yx'];
    }
    $costs = array_map(fn($pid) => harvest_energy_cost((int)$pid), q($sql, $args)->fetchAll(PDO::FETCH_COLUMN));
    if (!$costs) return (string)harvest_energy_cost((int)($t['plant_id'] ?? 0));
    $lo = min($costs);
    $hi = max($costs);
    return $lo === $hi ? (string)$lo : $lo . '–' . $hi;
}

/**
 * A garden action form whose tool may reach further: one button for this square, and one for 3 squares
 * or the whole row when the gnome's tool allows. Energy shown is per square, after tool discounts.
 */
function tool_action_form(string $do, array $t, string $label, int $unused = 0, string $extra = '', string $confirm = ''): string
{
    global $uid;
    $pid = $do === 'harvest' ? (int)($t['plant_id'] ?? 0) : 0;   // v0.7.86: a harvest costs by the crop's tier
    $cost = action_cost($uid, $do, $pid);
    $type = ACTION_TOOL[$do] ?? null;
    $reach = $type ? tool_reach(tool_tier($uid, $type)) : 1;
    $btns = '<button class="btn act" name="reach" value="one">' . e($label) . ' <span class="cost">⚡' . $cost . '</span></button>';
    if ($reach > 1) {
        $each = $do === 'harvest' ? harvest_cost_range($t, $reach) : (string)$cost;
        $btns .= ' <button class="btn act alt" name="reach" value="' . ($reach >= 99 ? 'row' : 'three') . '">'
            . ($reach >= 99 ? 'Whole row' : '×3') . ' <span class="cost">⚡' . $each . ' each</span></button>';   // v2.4.85: sits next to its main button, so no repeated name
    }
    return '<form method="post" class="inline toolform"' . ($confirm ? ' data-confirm="' . e($confirm) . '"' : '') . '>' . csrf_field()
        . '<input type="hidden" name="do" value="' . e($do) . '"><input type="hidden" name="x" value="' . (int)$t['x'] . '">'
        . '<input type="hidden" name="y" value="' . (int)$t['y'] . '">' . $extra . $btns . '</form> ';
}

function item_select(array $items, callable $label, string $pick = ''): string
{
    return '<select name="item_id"' . ($pick !== '' ? ' data-pick="' . e($pick) . '"' : '') . '>' . implode('', array_map(fn($i) => '<option value="' . (int)$i['id'] . '">' . e($label($i)) . '</option>', $items)) . '</select>';
}

/** A pop-up grid of items to choose from (the Satchel look), used by select mode and by the square panel.
 *  v2.0.67: each choice is an item square (includes/item_square.php); hooks kept: .pcard[data-id][data-qty], .pccount, .pcbtns [data-step], .pickgrid. */
function picker_html(string $kind, string $title, array $items, callable $icon, callable $info, string $go, ?callable $more = null): string   // v1.6.2: $more = a smaller second line
{
    require_once __DIR__ . '/includes/item_square.php';
    $rows = [];   // the items rows (picture, rarity); the root cellar lists plants, not items
    $ids = $kind === 'cellar' ? [] : array_values(array_unique(array_map(fn($i) => (int)$i['id'], $items)));
    if ($ids) foreach (q('SELECT * FROM items WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', $ids)->fetchAll() as $r) $rows[(int)$r['id']] = $r;
    $cards = '';
    foreach ($items as $i) {
        $row = $rows[(int)$i['id']] ?? null;
        $chips = [];
        $inf = (string)$info($i); $mt = $more ? (string)$more($i) : '';
        if ($kind === 'seed') {   // v2.4.80: the seed squares stay clean; what it needs and how it grows ride in a hidden span the quantity popover reads
            $tail = '<span class="pccount" hidden></span><span class="pcinfo" hidden>' . $inf . '</span><span class="pcmore" hidden>' . $mt . '</span>';
        } else {
            if ($inf !== '') $chips[] = ['note', $inf];
            if ($mt !== '') $chips[] = ['note', '<small class="pcmore">' . $mt . '</small>'];
            $tail = '<span class="pccount" hidden></span>';
        }
        $cards .= item_square(['item' => $row ?? [], 'name' => $row ? (string)$row['name'] : (string)$i['name'], 'icon' => $row ? '' : (string)$icon($i), 'rarity' => $row ? '' : 'C',
            'count' => $kind === 'cellar' ? null : (int)$i['qty'], 'chips' => $chips, 'pressed' => false, 'class' => 'pcard',
            'attrs' => ['data-id' => (int)$i['id'], 'data-qty' => (int)$i['qty']] + ($kind === 'seed' ? ['data-pk' => (string)($i['kind'] ?? ''), 'data-nm' => mb_strtolower((string)$i['name']), 'data-in' => !empty($i['_in']) ? '1' : '0'] : []), 'vh' => $tail]);
    }
    $filter = '';   // v2.4.87: seed picker search + type chips + in-season toggle (shown from 5 seeds up)
    if ($kind === 'seed' && count($items) >= 5) {
        $kinds = []; foreach ($items as $i) $kinds[(string)($i['kind'] ?? '')] = 1;
        $kl = ['vegetable' => 'Veg', 'herb' => 'Herbs', 'flower' => 'Flowers', 'tree' => 'Trees'];
        $ks = array_values(array_filter(array_keys($kinds), fn($k) => $k !== '')); usort($ks, fn($x, $y) => strcmp($kl[$x] ?? ucfirst($x), $kl[$y] ?? ucfirst($y)));
        if (count($ks) > 5) {   // many kinds: a <select>, not a wall of chips (DESIGN.md)
            $chips = '<select class="pfsel" aria-label="Seed type"><option value="" data-l="All types">All types</option>';
            foreach ($ks as $k) $chips .= '<option value="' . e($k) . '" data-l="' . e($kl[$k] ?? ucfirst($k)) . '">' . e($kl[$k] ?? ucfirst($k)) . '</option>';
            $chips = '<div class="pfchips">' . $chips . '</select></div>';
        } else {
            $chips = '<div class="pfchips" role="group" aria-label="Seed type"><button type="button" class="pfchip" data-pk="" aria-pressed="true">All <small></small></button>';
            foreach ($ks as $k) $chips .= '<button type="button" class="pfchip" data-pk="' . e($k) . '" aria-pressed="false">' . e($kl[$k] ?? ucfirst($k)) . ' <small></small></button>';
            $chips .= '</div>';
        }
        $filter = '<div class="pickfilter"><div class="pfsearch"><input type="search" class="pfq" placeholder="Search seeds…" aria-label="Search seeds" autocomplete="off"><button type="button" class="pfx" aria-label="Clear search">✕</button></div>'
            . $chips
            . '<label class="pfin"><input type="checkbox" class="pfnow"> In season only</label></div>';
    }
    return '<dialog class="picker" data-kind="' . e($kind) . '" aria-label="' . e($title) . '"><div class="pickbox">'
        . '<div class="pickhead"><b>' . e($title) . '</b> <span class="pickhint muted"></span><button type="button" class="pickx" aria-label="Close">✕</button></div>'
        . $filter
        . ($cards !== '' ? item_grid($cards, 'pickgrid') : '<p class="muted">You don’t have any.</p>')
        . ($filter !== '' ? '<p class="muted pfempty" hidden>No seeds match. Clear the search or filter.</p>' : '')
        . '<div class="pickfoot"><span class="picksum muted"></span><button type="button" class="btn" data-go>' . e($go) . '</button></div></div></dialog>';
}

page_header('My Garden');
?>
<?php require_once __DIR__ . '/includes/catfish.php'; $cfGarden = empty($u['guest']) ? catfish_garden_html((int)$u['id']) : '';   // Cat Fish: the active cat naps in the garden ?>
<div class="ghead"><h1><?= eu($plot['garden_name'] ?: gnome_name($u) . '’s Garden') ?></h1>
  <details class="renamefold"><summary aria-label="Rename this garden">✏️ Rename</summary>
    <form method="post" class="inline renamer"><?= csrf_field() ?><input type="hidden" name="do" value="rename"><input type="hidden" name="t" value="<?= e($tab) ?>">
      <label>Garden name <input name="name" value="<?= e($plot['garden_name'] ?? '') ?>" maxlength="40"></label>
      <button class="btn small">Rename</button></form></details></div>
<?= $cfGarden /* Cat Fish: the active cat */ ?>
<?php if (count($gardens) > 1): ?>
  <nav class="gardentabs">
    <?php foreach ($gardens as $g): ?>
      <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="do" value="switch"><input type="hidden" name="t" value="<?= e($tab) ?>"><input type="hidden" name="plot_id" value="<?= (int)$g['id'] ?>">
        <button class="tab<?= (int)$g['id'] === (int)$plot['id'] ? ' on' : '' ?>">🏡 <?= eu($g['garden_name'] ?: 'Garden') ?> <small>L<?= (int)$g['garden_level'] ?></small></button></form>
    <?php endforeach; ?>
  </nav>
<?php endif; ?>
<?php   // v1.4.0: tab bar (badges: ready crops, buildings with something to collect, animals about, helpers working)
$yobjs = yard_objects((int)$plot['id']);
$readyB = [];
foreach ($built as $bk => $brow) if (isset(BUILDING_PRODUCE[$bk]) && building_ready($brow) + heap_ready($brow) > 0) $readyB[$bk] = true;
foreach (critter_ready_map((int)$plot['id']) as $bk => $_n) $readyB[$bk] = true;   // v1.0.0: gifts from the garden animals
$biddy = biddy_html($u, $plot);
$homes = array_values(array_filter(array_keys($built), 'critter_is_home'));
$nbr = animals120_neighbours($u, $plot);   // v1.2.0: Clementine and Percy
$hasAnimals = $biddy !== '' || $nbr['html'] !== '' || $homes;
if ($tab === 'an' && !$hasAnimals) $tab = 'beds';
require_once __DIR__ . '/includes/pal_crew.php'; pcrew_retire_helpers();   // v2.6.40: hired helpers go home, wages refunded (once)
$hires = current_hires((int)$plot['id']); $slots = helper_slots((int)$plot['id']);   // v0.7.99: one helper per Tool Shed level
$nReadyBeds = 0;
foreach ($tiles as $row) foreach ($row as $t) if ($t['plant_id'] && isset($plants[(int)$t['plant_id']]) && tile_info($t, $plants[(int)$t['plant_id']])['ready']) $nReadyBeds++;
$nAnimals = ($biddy !== '' ? 1 : 0) + substr_count($nbr['hint'], ' · ');
$tb = fn(int $n, string $cls = '') => $n > 0 ? ' <span class="tbadge' . $cls . '">' . $n . '</span>' : '';
?>
<nav class="tabs gardentabnav" aria-label="Garden sections">
  <a class="<?= $tab === 'beds' ? 'on' : '' ?>" href="<?= e(url('garden.php')) ?>"><span class="tabic">🌱</span> Beds<?= $tb($nReadyBeds) ?></a>
  <a class="<?= $tab === 'bld' ? 'on' : '' ?>" href="<?= e(url('garden.php?t=bld')) ?>"><span class="tabic">🏠</span> Buildings<?= $tb(count($readyB)) ?></a>
  <?php if ($hasAnimals): ?><a class="<?= $tab === 'an' ? 'on' : '' ?>" href="<?= e(url('garden.php?t=an')) ?>"><span class="tabic">🐾</span> Animals<?= $tb($nAnimals) ?></a><?php endif; ?>
  <a class="<?= $tab === 'help' ? 'on' : '' ?>" href="<?= e(url('garden.php?t=help')) ?>"><span class="tabic">🧩</span> Crew<?php require_once __DIR__ . '/includes/pal_crew.php'; echo $tb(count(pcrew_slots((int)$plot['id'])), ' muted'); ?></a>
  <a class="<?= $tab === 'grow' ? 'on' : '' ?>" href="<?= e(url('garden.php?t=grow')) ?>"><span class="tabic">📐</span> Grow</a>
</nav>
<?php if ($tab === 'beds'): ?>
<details class="helpfold gardeninfo"><summary>📍 <?= $here && $here['region'] ? e($here['region']) : 'This garden' ?> · about this spot</summary>   <?php /* v1.0.1: folded so the yard comes first on a phone */ ?>
<p class="help">📍 <?= $here && $here['region'] ? e($here['region']) . ($here['region_real'] ? ' (' . e($here['region_real']) . ')' : '') : 'Somewhere on Earth' ?>.
  Crops native to <?= $here && $here['region'] ? e($here['region']) : 'this region' ?> grow <?= (int)setting('native_bonus_percent') ?>% faster here.
  You tend <?= count($gardens) ?> of <?= max_gardens($u) ?> possible garden<?= max_gardens($u) === 1 ? '' : 's' ?><?= next_garden_level($u) ? ' (another at gnome level ' . next_garden_level($u) . ')' : '' ?>.</p>
<?php if (!empty($plot['region_id'])):   // v0.7.61: say plainly which crops get the home bonus here
    $natives = q('SELECT DISTINCT p.name, p.kind FROM plant_regions pr JOIN plants p ON p.id = pr.plant_id WHERE pr.region_id = ? ORDER BY p.kind, p.name', [$plot['region_id']])->fetchAll();
    if ($natives):
        $byKind = [];
        foreach ($natives as $n) $byKind[$n['kind']][] = $n['name'];
        arsort($byKind);
        uasort($byKind, fn($a, $b) => count($b) <=> count($a)); ?>
  <details class="helpfold nativefold"><summary>🌍 Native bonus here: <?= e(implode(', ', array_map(fn($k, $l) => count($l) . ' ' . $k . (count($l) > 1 && $k !== 'fruit' ? 's' : ''), array_keys($byKind), $byKind))) ?> grow <?= (int)setting('native_bonus_percent') ?>% faster</summary>
    <?php foreach ($byKind as $k => $list): ?><p class="help"><?= catalog_kind_icon((string)$k) ?> <b><?= e(ucfirst((string)$k)) ?>:</b> <?= e(implode(', ', $list)) ?></p><?php endforeach; ?>
  </details>
<?php endif; endif; ?>
<?php if (!empty($plot['region_id']) && setting('climate_on') === '1'):   // v0.8.9: this garden's climate
    require_once __DIR__ . '/includes/climate.php';
    $climReg = q_one('SELECT id, climate_trait FROM regions WHERE id = ?', [$plot['region_id']]);
    if ($climReg && climate_fx((int)$climReg['id'])): ?>
  <p class="help">🌦️ <b>Climate here:</b> <?= e(climate_text($climReg)) ?><?= garden_mods((int)$plot['id'])['greenhouse'] ? ' Your greenhouse shelters crops from any slowdown.' : '' ?></p>
<?php endif; endif; ?>
</details>
<?php // v1.0.0: what today's season and weather do here
    [$wxHead, $wxText, $wxCls] = garden_weather_note((int)$plot['id'], $tiles, $plants);
    $seasonNow = hollow_now(garden_region_code((int)$plot['id'])); ?>
<p class="wxline wx-<?= e($wxCls) ?>"><b><?= e($wxHead) ?></b> · <?= e($wxText) ?>
  <span class="muted"><?= $seasonNow['season_emoji'] ?> <?= e($seasonNow['season_label']) ?>, day <?= (int)$seasonNow['season_day'] ?>. <a href="<?= e(url('world.php?tab=seasons#seasons')) ?>">Forecast</a></span></p>
<?php if (empty($u['region_id'])): ?>
  <div class="flash err">You haven’t chosen a home region yet. <a href="<?= e(url('world.php')) ?>">Choose one</a> to get your home seeds.</div>
<?php endif; ?>

<div class="gardenwrap">
  <div>
    <?php $appeal = yard_appeal((int)$plot['id'], $yobjs);
        if ($appeal !== (int)$plot['appeal']) q('UPDATE plots SET appeal = ? WHERE id = ?', [$appeal, $plot['id']]); ?>
    <?php   // v1.6.3: on phones the view crops to EVERYTHING in use (every bed, building, critter home, decor, fence, path) + 1 square of margin.
        // Only when that box is clearly smaller than the yard and not wider than 8 squares; otherwise the whole yard shows.
        [$ycw, $ych] = yard_size($plot);
        $bx0 = $by0 = 99; $bx1 = $by1 = -1;
        $grow = function (int $x, int $y, int $w, int $h) use (&$bx0, &$bx1, &$by0, &$by1): void { $bx0 = min($bx0, $x); $by0 = min($by0, $y); $bx1 = max($bx1, $x + max(1, $w) - 1); $by1 = max($by1, $y + max(1, $h) - 1); };
        foreach ($tiles as $row) foreach ($row as $t) if ($t['yx'] !== null) $grow((int)$t['yx'], (int)$t['yy'], 1, 1);
        foreach ($yobjs as $o) if ((int)$o['x'] >= 0) { $odd = (int)$o['rot'] % 2 === 1; $grow((int)$o['x'], (int)$o['y'], $odd ? (int)$o['h'] : (int)$o['w'], $odd ? (int)$o['w'] : (int)$o['h']); }
        $cropCls = '';
        if ($bx1 >= 0) {
            $cx0 = max(0, $bx0 - 1); $cx1 = min($ycw - 1, $bx1 + 1); $cy0 = max(0, $by0 - 1); $cy1 = min($ych - 1, $by1 + 1);
            $cw = $cx1 - $cx0 + 1; $ch = $cy1 - $cy0 + 1;
            if ($cw <= 8 && $cw * $ch <= 0.7 * $ycw * $ych) $cropCls = ' crop ycx' . $cx0 . ' ycy' . $cy0 . ' ycw' . $cw . ' ych' . $ch;
        } ?>
    <?php if ($cropCls !== ''): ?><p class="yardzoom"><button type="button" class="linkbtn" data-yardwhole><span class="yz-a">🔭 Show whole yard</span><span class="yz-b">🔍 Zoom to my beds</span></button></p><?php endif; ?>
    <div class="yardwrap<?= $cropCls ?>" id="yard"><?= render_yard($plot, $tiles, $plants, $yobjs, 'own', $sel, ['ready' => $readyB]) ?></div>
    <p class="yardbar"><a class="btn small" href="<?= e(url('yard.php')) ?>">✏️ Design yard</a>
      <span title="How lovely your yard looks: decor, variety, buildings and flowers in bloom">🌼 Curb appeal <b><?= $appeal ?></b> (<?= e(appeal_word($appeal)) ?>)</span>
      <?php require_once __DIR__ . '/includes/social169.php'; echo social169_garden_counts((int)$plot['id']); /* v1.6.9 */ ?>
      <a class="muted" href="<?= e(url('visit.php?g=' . (int)$plot['id'])) ?>">See it as visitors do</a></p>
    <details class="helpfold needhelp"><summary>🤝 Need help?</summary>   <?php /* v1.7.0 */ ?>
      <ul>
        <li><a href="<?= e(url('garden.php?t=help')) ?>">🧑‍🌾 Hire a villager</a> to tend while you’re out.</li>
        <li><a href="<?= e(url('jobs.php?t=jobs&p=post')) ?>">📌 Post a job</a> for other players.</li>
        <li>💧 Other gnomes can water for you when they visit.</li>
      </ul>
    </details>
    <?php // v0.7.54: select squares, then do one thing to all of them
        $flags = [];
        $pnames = [];
        $hcosts = [];   // v0.7.86: energy a harvest of each square takes (by crop tier)
        foreach ($tiles as $row) foreach ($row as $t) {
            $f = '';
            $pl = $t['plant_id'] && isset($plants[(int)$t['plant_id']]) ? $plants[(int)$t['plant_id']] : null;
            if ($pl) $hcosts[] = (int)$t['x'] . '-' . (int)$t['y'] . ':' . harvest_energy_cost((int)$t['plant_id']);
            if ($t['method'] === 'notill') $f .= 'N';   // v1.6.2: a no-till bed (tilling it loses its grade)
            if (tile_plantable($t)) $f .= 'P';
            if ((int)$t['tilled'] && (int)$t['feed_hours'] <= 0 && (int)$t['fertility'] < (int)setting('amend_max_fertility')) $f .= 'A';
            if ((int)$t['tilled']) $f .= 'M';
            // v0.7.85: a no-till bed is never picked for tilling (tilling it loses its grade)
            if (!$pl && $t['method'] !== 'notill' && !((int)$t['tilled'] && $t['method'] === 'till')) $f .= 'T';
            if ($pl) { $ti = tile_info($t, $pl); if ($ti['thirsty']) $f .= 'W'; if ($ti['ready']) $f .= 'H'; }
            $flags[] = (int)$t['x'] . '-' . (int)$t['y'] . ':' . $f . ':' . ($pl ? (int)$t['plant_id'] : 0);   // v0.9.1a: plant id for "select all of this crop"
            if ($pl) $pnames[(int)$t['plant_id']] = (int)$t['plant_id'] . ':' . str_replace([',', ':'], ' ', (string)$pl['name']);
        }
        $plantableSeeds = $seeds; $ghOn = building_level((int)$plot['id'], 'greenhouse') > 0;
        foreach ($plantableSeeds as &$ps) $ps['_in'] = empty($ps['sapling']) ? plant_season_state($ps, gclock_my_date(), $ghOn) === 'in' : true;   // v2.4.87: for the in-season toggle
        unset($ps);
          // v0.7.65: anything can be planted; unstudied ones are marked
        $costs = []; foreach (['plant', 'soil', 'mulch', 'till', 'water', 'harvest', 'dig', 'sheet'] as $a) $costs[] = $a . ':' . action_cost($uid, $a); ?>
    <div class="selbar" data-tiles="<?= e(implode(',', $flags)) ?>" data-costs="<?= e(implode(',', $costs)) ?>" data-hcosts="<?= e(implode(',', $hcosts)) ?>" data-pnames="<?= e(implode(',', $pnames)) ?>" hidden>
      <button type="button" class="btn small" data-sel="on">☑️ Select squares</button>
      <div class="selon" hidden>
        <p><b>☑️ <span class="selcount">0</span> selected.</b> Tap squares to pick them, or pick:
          <button type="button" class="btn small alt" data-q="P">🟫 empty &amp; ready to plant</button>
          <button type="button" class="btn small alt" data-q="A">🪱 can take a soil improver</button>
          <button type="button" class="btn small alt" data-q="T">⛏️ needs tilling</button>
          <button type="button" class="btn small alt" data-q="W">💧 thirsty</button>
          <button type="button" class="btn small alt" data-q="H">🧺 ready</button>
          <button type="button" class="btn small alt" data-q="none">✖ none</button></p>
        <p class="selcrop" hidden><button type="button" class="btn small" data-selcrop></button></p>
        <p class="selacts">
          <button type="button" class="btn" data-open="seed">🌱 Plant…</button>
          <button type="button" class="btn" data-open="soil">🪱 Work in…</button>
          <button type="button" class="btn" data-open="mulch">🍂 Mulch…</button>
          <?php if ($canNoTill): ?><button type="button" class="btn" data-open="mulch" data-act="sheet" title="Cardboard + mulch: turns squares into no-till beds">📦 Sheet mulch…</button><?php endif; ?>
          <button type="button" class="btn alt" data-act="till" data-ask="Till the N selected squares? Tilling a no-till bed loses its grade." data-askif="N">⛏️ Till</button>
          <button type="button" class="btn alt" data-act="water">💧 Water</button>
          <button type="button" class="btn alt" data-act="harvest">🧺 Harvest</button> <span class="cost selhcost"></span>
          <button type="button" class="btn alt" data-act="dig" data-ask="Dig up the plants on the N selected squares? You won’t get a harvest from them.">🪏 Dig up</button>
          <button type="button" class="btn small alt" data-sel="off">Done</button></p>
        <p class="help">Squares that can’t take it are skipped (you’ll be told why), and it stops if you run out of energy.</p>
      </div>
    </div>
    <form class="batchform" method="post" hidden><?= csrf_field() ?><input type="hidden" name="do" value="batch"><input type="hidden" name="act" value=""><input type="hidden" name="item_id" value=""></form>
    <?= picker_html('seed', 'Choose seeds', $plantableSeeds, fn($i) => (($pic = item_pic(['id' => $i['id'], 'name' => $i['name']], 'md')) !== '' ? $pic : (!empty($i['sapling']) ? '🌳' : catalog_kind_icon((string)($i['kind'] ?? '')))),   // v1.6.2: the packet's own picture
        fn($i) => implode(' · ', array_filter([trim(season_chip_text($i, building_level((int)$plot['id'], 'greenhouse') > 0)), (empty($i['sapling']) && empty($known[(int)$i['plant_id']]) ? '📕 unstudied' : ''), (!empty($i['perennial']) ? '🔄 regrows' : '')], fn($x) => trim((string)$x) !== '')), 'Plant',
        fn($i) => e((empty($i['sapling']) && empty($known[(int)$i['plant_id']]) ? '−' . (100 - unstudied_yield_pct($u)) . '% harvest · ' : '')
            . ((int)$i['min_soil'] <= 0 ? 'any soil' : ((int)$i['min_soil'] < 40 ? 'decent soil' : 'rich soil')))) ?>
    <?php if (isset($built['root_cellar'])):   // v0.7.57: the root cellar uses the same picker
        $celPick = array_map(fn($c) => ['id' => $c['id'], 'name' => $c['name'], 'qty' => 1, 'kind' => $c['kind'],
            'pct' => (int)min(100, round((int)$c['growth_seconds'] / max(1, (int)$c['grow_minutes'] * 60) * 100))], cellar_plants((int)$plot['id'])); ?>
      <?= picker_html('cellar', 'Replant from the root cellar', $celPick, fn($i) => catalog_kind_icon((string)$i['kind']), fn($i) => '🔄 Perennial · ' . (int)$i['pct'] . '% grown', 'Replant') ?>
    <?php endif; ?>
    <?= picker_html('soil', 'Choose a soil improver', $soils, fn($i) => '🪱', fn($i) => e(amend_summary($i)), 'Work in') ?>
    <?= picker_html('mulch', 'Choose a mulch', $mulches, fn($i) => '🍂', fn($i) => e(amend_summary($i)), 'Spread') ?>
    <div class="bulk">
      <?php $nThirsty = $nReady = $nWeedy = 0;
          $hEnergy = 0;   // v0.7.86: the energy all the ready crops would take, each by its tier
          foreach ($tiles as $row) foreach ($row as $t) {
              if ($t['plant_id'] && isset($plants[(int)$t['plant_id']])) {
                  $ti = tile_info($t, $plants[(int)$t['plant_id']]);
                  if ($ti['thirsty']) $nThirsty++;
                  if ($ti['ready']) { $nReady++; $hEnergy += harvest_energy_cost((int)$t['plant_id']); }
              }
              if ($t['method'] === 'notill' && (int)$t['weeds'] >= 5) $nWeedy++;
          }
          $nPest = 0;   // v1.0.0: beds with a pest
          foreach ($tiles as $row) foreach ($row as $t) if (!empty($t['pest']) && $t['plant_id']) $nPest++;
          $bulk = function (string $do, string $label, int $n, int $energy) {
              return '<form method="post" class="inline">' . csrf_field() . '<input type="hidden" name="do" value="' . $do . '"><button class="btn small"' . ($n ? '' : ' disabled') . '>'
                  . $label . ($n ? ' (' . $n . ') <span class="cost">⚡' . $energy . '</span>' : '') . '</button></form> ';
          }; ?>
      <?php $freeW = isset($built['rain_barrel']) && (int)$built['rain_barrel']['level'] >= 3 && (string)$built['rain_barrel']['free_day'] !== gclock_my_date();   // v0.7.96
          $perkN = calling_perk($u, 'free_water_all');   // v0.9.1: Bloomcaller master
          $perkLeft = $perkN > 0 ? max(0, $perkN - ((string)($plot['free_water_day'] ?? '') === gclock_my_date() ? (int)$plot['free_water_n'] : 0)) : 0;
          if ($perkLeft > 0) $freeW = true; ?>
      <?= $bulk('water_all', $nThirsty ? '💧 Water all thirsty' : '💧 Nothing thirsty', $nThirsty, $freeW ? 0 : action_cost($uid, 'water') * $nThirsty) ?>
      <?php if ($perkLeft > 0): ?><span class="help">💧 Free Water all: <?= $perkLeft ?> left today</span> <?php endif; ?>
      <?= $bulk('harvest_all', $nReady ? '🧺 Harvest all ready' : '🧺 Nothing ready', $nReady, $hEnergy) ?>
      <?php if ($readyB): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="do" value="collect_all"><button class="btn small">📦 Collect all (<?= count($readyB) ?>)</button></form> <?php endif;   // v0.7.99 ?>
      <?php if ($nPest): ?><?= $bulk('pick_all', '🧤 Pick pests off', $nPest, max(0, (int)setting('pest_pick_energy')) * $nPest) ?><?php endif; ?>
      <?php if ($canNoTill): ?><?= $bulk('weed_all', $nWeedy ? '🌿 Weed all beds' : '🌿 No weeds', $nWeedy, action_cost($uid, 'weed') * $nWeedy) ?><?php endif; ?>
      <p class="help">Energy shown is the most it can cost: good tools sometimes make squares free.</p>
    </div>
    <p class="help legend"><span class="sw wild"></span> wild <span class="sw tilled"></span> tilled <span class="sw notill"></span> no-till bed (green edge). Hover a bed to see its yard bonuses.</p>
  </div>

  <div class="panel box" data-inplace-show>
    <?php if (!$sel): ?>
      <h3>Pick a square</h3>
      <p>Tap a square of your plot to tend it.</p>
      <p class="help">Till (or sheet mulch) → add compost → plant → water → harvest. Plants only grow while watered.
        <?= $canNoTill ? '' : 'Wren will teach you no-till gardening at level ' . (int)setting('notill_level') . '.' ?></p>
    <?php else:
        $p = $sel['plant_id'] ? $plants[(int)$sel['plant_id']] : null;
        $w = soil_words($sel);
        $method = $sel['method'] === 'notill' ? '🍂 No-till bed' : ((int)$sel['tilled'] ? '⛏️ Tilled' : '🌾 Wild ground'); ?>
      <h3 class="sqh">Square <?= (int)$sel['x'] + 1 ?>, <?= (int)$sel['y'] + 1 ?> · <?= $method ?> <a class="backtoyard" href="#yard">⬆ yard</a></h3>
      <?php   // v2.3.100: one status line, a row of chips and ONE "Next:" line; the numbers are behind "Soil details"
          $sumWord = $sel['method'] === 'notill' ? 'No-till bed' : ((int)$sel['tilled'] ? 'Tilled' : 'Wild ground');
          $sumState = $p ? ($p['kind'] === 'cover' ? 'cover crop growing' : 'growing ' . $p['name']) : (ts($sel['settle_until']) > gclock_plot_now((int)$sel['plot_id']) ? 'settling · ready to plant in ' . nice_time(ts($sel['settle_until']) - gclock_plot_now((int)$sel['plot_id'])) : (tile_plantable($sel) ? 'ready to plant' : ((int)$sel['tilled'] ? 'ready for soil care' : 'till it first')));
          $fertLow = (int)$sel['fertility'] < 40;
          $chips = [];
          $pNeed = $p ? (string)($p['nutrient'] ?? '') : '';
          if ($pNeed !== '' && isset(NUTRIENTS[$pNeed]) && (int)($sel[$pNeed] ?? 50) < 35) $chips[] = [NUTRIENTS[$pNeed][1] . ' ▼ low', 'warn', ''];
          if ($sel['method'] === 'notill') { $gi0 = grade_index($sel); $pb0 = bed_problems($sel); $chips[] = ['grade ' . grade_name($gi0), $pb0 ? 'warn' : 'ok', '🍂']; if ($pb0) $chips[] = [count($pb0) . ' to fix', 'warn', '⚠️']; }
          if ((int)$sel['feed_hours'] > 0) $chips[] = ['improver working', 'ok', '🪱'];
          // the one next step, most urgent first
          $next = '';
          if ($p && !empty($info0 = tile_info($sel, $p))) {
              if ($info0['ready']) $next = ($p['kind'] === 'cover' ? 'Dig it in' : 'Harvest it') . ' now.';
              elseif ($info0['thirsty'] && empty($info0['rain'])) $next = 'Water it now.';
          }
          if ($next === '' && $pNeed !== '' && isset(NUTRIENTS[$pNeed]) && (int)($sel[$pNeed] ?? 50) < 35) $next = NUTRIENTS[$pNeed][0] . ' is low: ' . ['n' => 'worm tea, fern tea, or beans or a cover crop first.', 'p' => 'shell meal or rock dust.', 'k' => 'kelp meal or wood ash.'][$pNeed];
          elseif ($fertLow && (int)$sel['tilled'] && (int)$sel['feed_hours'] <= 0) $next = ($next !== '' ? $next . ' Then add' : 'Add') . ' compost: the soil is tired.';
          elseif ($sel['method'] === 'notill' && !empty($pb0)) $next = ['mulch' => 'Add mulch.', 'weeds' => 'Pull the weeds.', 'moisture' => 'Water the bed.', 'fertility' => 'Add compost.'][array_key_first($pb0)] ?? 'This bed needs care.';
          elseif (!(int)$sel['tilled'] && $sel['method'] !== 'notill') $next = 'Till it first.'; ?>
      <p class="sqsum"><b><?= e(ucfirst($sumState)) ?></b></p>   <?php /* v2.4.82: the method is in the heading already */ ?>
      <?php if ($chips): ?><p class="sqchips"><?php foreach ($chips as [$ct, $cc, $ci]): ?><span class="sqchip <?= $cc ?>"><?= $ci ? $ci . ' ' : '' ?><?= e($ct) ?></span> <?php endforeach; ?></p><?php endif; ?>
      <?php if ($next !== ''): ?><p class="sqnext"><b>Next:</b> <?= e($next) ?></p><?php endif; ?>
      <?php $yb = yard_tile_bonuses($sel); if ($yb): ?>
        <p class="yardbonus"><?php foreach (array_keys($yb) as $bk): ?><span class="tag" title="<?= e(YARD_BONUSES[$bk][3]) ?>"><?= YARD_BONUSES[$bk][0] ?> <?= e(YARD_BONUSES[$bk][1]) ?></span> <?php endforeach; ?></p>
      <?php endif; ?>
      <div class="soiltop">
      <p class="soilstats"><span><small>Fertility</small> <?= e($w['fertility']) ?> <b><?= (int)$sel['fertility'] ?></b></span>
        <span><small>Soil life</small> <b><?= $hasKit ? (int)$sel['soil_life'] . '/100' : e($w['life']) ?></b></span>
        <span title="How well the soil holds water. Better soil makes each watering last longer (up to twice as long). Mulch, compost and no-till beds improve it; watering helps a little."><small>Holds water</small> <b><?= $hasKit ? (int)$sel['moisture'] . '/100' : e($w['moisture']) ?></b></span></p>
        <?php $need = $p ? (string)($p['nutrient'] ?? '') : ''; ?>
        <?php ob_start(); ?><p class="npkwrap"><span class="npkrow"><?php foreach (NUTRIENTS as $nu => [$nName, $nLetter, $nIcon]): $nv = (int)($sel[$nu] ?? 50);
            $mark = $nv < 35 ? '▼' : ($nv >= 65 ? '▲' : '●'); ?><span class="npkchip<?= $need === $nu ? ' need' : '' ?><?= $nv < 35 ? ' low' : '' ?>" title="<?= e($nName . ': ' . nutrient_word($nv) . ($need === $nu ? ' (' . $p['name'] . ' feeds on this)' : '')) ?>"><span class="npkb <?= $nu ?>"><?= $nLetter ?></span><span class="npkm"><?= $hasKit ? $nv : $mark ?></span><?= $need === $nu ? '<span class="npkcrop" aria-hidden="true">←🌱</span>' : '' ?></span><?php endforeach; ?></span>
          <small class="npkleg" title="● ok · ▼ low · ▲ high<?= $need !== '' ? ' · ring = what the crop feeds on' : '' ?>">● ok ▼ low ▲ high<?= $need !== '' ? ' · ring = crop food' : '' ?></small></p><?php $npkHtml = ob_get_clean(); if ($sel['method'] !== 'notill') echo $npkHtml; ?>

      <?php if ($sel['method'] !== 'notill'):   // v0.8.7: soil care stars for tilled squares
          $cp = care_points($sel); $cs = care_stars_for($cp); $steps = care_steps();
          $prev = $cs > 0 ? $steps[$cs - 1] : 0;
          $todayDone = ($sel['care_day'] ?? '') === job_period_key('daily');
          $lifeOk = (int)$sel['soil_life'] >= (int)setting('care_min_life'); ?>
        <div class="gradebox carebox">
          <div>
            <b>Soil care <?= care_star_text($cs) ?></b> <span class="muted"><?= e(CARE_NAMES[$cs]) ?></span>
            <?php if ($cs < 5): ?><progress max="<?= $steps[$cs] - $prev ?>" value="<?= $cp - $prev ?>"></progress>
              <span class="help"><?= $steps[$cs] - $cp ?> more good harvest<?= $steps[$cs] - $cp === 1 ? '' : 's' ?> (one a day) to <?= care_star_text($cs + 1) ?></span>
            <?php else: ?><span class="help">The best tilled soil there is.</span><?php endif; ?>
          </div>
        </div>
        <ul class="upkeep upkeepchips">
          <li class="<?= (int)$sel['care_fed'] ? 'good' : 'muted' ?>"><?= (int)$sel['care_fed'] ? '✔ Improver added' : '✖ Work in an improver' ?></li>
          <li class="<?= $lifeOk ? 'good' : 'bad' ?>"><?= $lifeOk ? '✔ Soil life' : '✖ Soil life too low' ?></li>
          <li class="<?= $todayDone ? 'good' : 'muted' ?>"><?= $todayDone ? '✔ Point today' : '• No point yet today' ?></li>
        </ul>
      <?php endif; ?>
      <?php if ($sel['method'] === 'notill'):
          $gi = grade_index($sel);
          $into = (int)$sel['bed_score'] - $gi * GRADE_STEP;
          $probs = bed_problems($sel); ?>
        <div class="soilrow">
        <div class="gradebox">
          <span class="grade big g<?= $gi ?>"><?= e(grade_name($gi)) ?></span>
          <div>
            <b>Soil grade <?= e(grade_name($gi)) ?></b>
            <?php if ($gi < 10): ?><progress max="<?= GRADE_STEP ?>" value="<?= max(0, $into) ?>"></progress>
              <span class="help"><?= max(0, GRADE_STEP - $into) ?> points to <?= e(grade_name($gi + 1)) ?></span>
            <?php else: ?><span class="help">The finest soil there is. Keep it that way!</span><?php endif; ?>
          </div>
        <?= $npkHtml ?></div>
        </div>
        <ul class="upkeep">
          <li class="<?= isset($probs['mulch']) ? 'bad' : ((int)$sel['mulch'] < 24 ? 'warn' : 'good') ?>">Mulch: <?= e(mulch_text((int)$sel['mulch'])) ?> <?= isset($probs['mulch']) ? '— add mulch' : ((int)$sel['mulch'] < 24 ? '— top up soon' : '✔') ?></li>
          <li class="<?= isset($probs['weeds']) ? 'bad' : 'good' ?>">Weeds <?= (int)$sel['weeds'] ?>/100 <?= isset($probs['weeds']) ? '— pull them' : '✔' ?></li>
          <li class="<?= isset($probs['moisture']) ? 'bad' : 'good' ?>">Moisture <?= isset($probs['moisture']) ? '— water the bed' : '✔' ?></li>
          <li class="<?= isset($probs['fertility']) ? 'bad' : 'good' ?>">Fertility <?= isset($probs['fertility']) ? '— add compost' : '✔' ?></li>
          <li class="<?= $sel['plant_id'] ? 'good' : 'muted' ?>">Living roots <?= $sel['plant_id'] ? '✔ (double points)' : '— plant something or a cover crop' ?></li>
        </ul>
        <p class="help"><?= $probs ? '⚠️ This bed is slowly losing points until it’s fixed.' : 'Well kept! Gaining points every hour.' ?></p>
        <?php if ((int)$sel['checkpoint'] > 0):
            $graceLeft = (int)setting('notill_checkpoint_days') * 24 - (int)$sel['neglect_hours']; ?>
          <p class="checkpoint">🛡️ Checkpoint <?= checkpoint_name((int)$sel['checkpoint']) ?> — this bed can’t fall below grade <?= checkpoint_name((int)$sel['checkpoint']) ?><?= (int)$sel['neglect_hours'] > 0 ? '. Neglected for ' . nice_time((int)$sel['neglect_hours'] * 3600) . '; the checkpoint is lost after ' . nice_time($graceLeft * 3600) . ' more.' : ' unless tilled or neglected for ' . (int)setting('notill_checkpoint_days') . ' days straight.' ?></p>
        <?php endif; ?>
        <?php $ntForms = ((int)$sel['weeds'] >= 5 ? tool_action_form('weed', $sel, 'Pull weeds', ENERGY_COST['weed']) : '') . (!$sel['plant_id'] ? tool_action_form('water', $sel, 'Water bed', ENERGY_COST['water']) : ''); ?>
      <?php endif; ?>
      </div>
      <?php if ($p):
          $info = tile_info($sel, $p); ?>
      <div class="plantinfo<?= $info['ready'] ? ' ready' : ($info['thirsty'] ? ' thirsty' : '') ?>">
        <p class="pihead"><b><?= e($p['name']) ?></b><?= !empty($sel['_native']) ? ' <span class="tag">🌍 native +' . (int)setting('native_bonus_percent') . '%</span>' : '' ?><?= $p['perennial'] ? ' <span class="tag">🔄 Perennial</span>' : '' ?><?= plant_unstudied($u, $p) ? ' <span class="tag">📕 Unstudied</span>' : '' ?><?= $p['kind'] === 'cover' ? ' <span class="tag">cover crop</span>' : '' ?></p>
        <?= tile_fx_html($sel, $p, $plants) /* v1.0.0: season, weather, pests, companions */ ?>
        <progress max="100" value="<?= (int)round($info['progress'] * 100) ?>"></progress>
        <p class="pistat"><?php if ($info['ready']): ?><?= $p['kind'] === 'cover' ? 'Ready to dig in! ☘️' : 'Ready to harvest! 🧺' ?>
           <?php elseif (!empty($info['rain'])): ?>🌧️ Rain is watering it · about <?= nice_time($info['time_left']) ?> left
           <?php elseif ($info['thirsty']): ?>💧 Thirsty, growth paused · about <?= nice_time($info['time_left']) ?> of watered growing left
           <?php else: ?>Growing · about <?= nice_time($info['time_left']) ?> left · water lasts <?= nice_time($info['wet_left']) ?><?php endif; ?></p>
        <div class="piact">
        <?= $info['ready'] ? tool_action_form('harvest', $sel, $p['kind'] === 'cover' ? 'Dig in' : 'Harvest', ENERGY_COST['harvest'])
                           : tool_action_form('water', $sel, 'Water', ENERGY_COST['water']) ?>
        <?= action_form('dig', $sel, 'Dig up', ENERGY_COST['dig'], '', 'Dig up this plant? You won’t get a harvest.') ?>
        <?php if (isset($built['root_cellar']) && (int)$p['perennial'] && $p['kind'] !== 'cover'): $cc = (int)setting('cellar_store_cost'); ?>
          <form method="post" class="inline" data-confirm="Dig the <?= e($p['name']) ?> up into the root cellar<?= $cc ? ' for ' . number_format($cc) : '' ?>?"><?= csrf_field() ?>
            <input type="hidden" name="do" value="cellar"><input type="hidden" name="x" value="<?= (int)$sel['x'] ?>"><input type="hidden" name="y" value="<?= (int)$sel['y'] ?>">
            <button class="btn act alt">🚪 Store in root cellar<?= $cc ? ' · ' . money($cc) : '' ?></button></form>
        <?php endif; ?>
        </div>
        <details class="plantmore"><summary>About this plant</summary>
        <?php if (plant_unstudied($u, $p)): ?><p class="help unstudied">📕 Unstudied: grows <?= unstudied_slow_pct($u) ?>% slower and gives <?= 100 - unstudied_yield_pct($u) ?>% less. Study <?= e(plant_home_name((int)$p['id']) ?: 'its region') ?> or master it to fix that.</p><?php endif; ?>
        <?php if ($p['kind'] === 'cover'): ?><p class="help">A cover crop: it feeds N, P and K when dug in.</p><?php endif; ?>
        <?php if ($lt = perennial_life_text($sel, $p)): ?><p class="help lifeline"><?= e($lt) ?></p><?php endif; ?>
        <?php if (isset(NUTRIENTS[(string)($p['nutrient'] ?? '')])): $nu = (string)$p['nutrient']; $nv = (int)($sel[$nu] ?? 50); ?>
          <p class="help">Feeds on <?= e(strtolower(NUTRIENTS[$nu][0])) ?> (<?= NUTRIENTS[$nu][1] ?>): growing at <?= (int)round(nutrient_speed($sel) * 100) ?>% speed from it.
            <?= $p['kind'] === 'legume' ? 'Beans give nitrogen back when harvested.' : '' ?></p>
        <?php endif; ?>
        <?php require_once __DIR__ . '/includes/breeding110.php'; echo breeding110_garden_note($u, $sel, $p); /* v1.1.0: hybrids */ ?>
        </details>
      </div>
      <?php endif; ?>
      <div class="sqactions">
      <?= $ntForms ?? '' ?>

      <?php if ($p): ?>
      <?php else: ?>
        <?php if ($sel['method'] !== 'till' || !(int)$sel['tilled']): ?>
          <?= tool_action_form('till', $sel, 'Till', action_cost($uid, 'till'), '',
              $sel['method'] === 'notill' ? 'Tilling a no-till bed destroys all the soil life you have built. Are you sure?' : '') ?>
        <?php endif; ?>
        <?php if ($canNoTill && $sel['method'] !== 'notill'): ?>
          <?= $mulches ? action_form('sheet', $sel, 'Sheet mulch (no-till)', action_cost($uid, 'sheet'), item_select($mulches, fn($i) => $i['name'] . ' ×' . $i['qty'], 'mulch'))
                       : '<p class="help">To start a no-till bed you need a Cardboard Sheet and some mulch.</p>' ?>
        <?php endif; ?>
        <?php if ($sel['method'] === 'notill' && tool_power($uid, 'broadfork')):
            $forkWait = $sel['fork_at'] ? (int)setting('broadfork_days') * 86400 - (time() - ts($sel['fork_at'])) : 0; ?>
          <?= $forkWait > 0 ? '<p class="help">⛏️ Broadforked recently. Again in ' . nice_time($forkWait) . '.</p>'
                            : action_form('broadfork', $sel, 'Broadfork', ENERGY_COST['broadfork']) ?>
        <?php endif; ?>
        <?php if (tile_plantable($sel)):
            $plantable = $seeds;   // v0.7.65
            $unknownCount = count(array_filter($seeds, fn($s) => empty($s['sapling']) && empty($known[(int)$s['plant_id']]))); ?>
          <?php if ($plantable): ?>
            <?= tool_action_form('plant', $sel, 'Plant', ENERGY_COST['plant'], item_select($plantable, fn($s) =>
                $s['name'] . ' ×' . $s['qty']
                . (isset($s['xp_per_harvest']) ? ' · +' . (int)$s['xp_per_harvest'] . ' XP' : '')   // v2.3.94: what a harvest pays
                . (empty($s['sapling']) && empty($known[(int)$s['plant_id']]) ? ' 📕 unstudied' : '')
                . (!empty($s['perennial']) ? ' 🔄 Perennial' : '')
                . ((int)$s['min_soil'] > (int)$sel['fertility'] ? ' (needs fertility ' . $s['min_soil'] . ')' : ''), 'seed')) ?>
          <?php else: ?><p class="muted">No seeds in your satchel. Visit a market!</p><?php endif; ?>
          <?php $cel = isset($built['root_cellar']) ? cellar_plants((int)$plot['id']) : [];
          if ($cel): ?>
            <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="do" value="uncellar"><input type="hidden" name="x" value="<?= (int)$sel['x'] ?>"><input type="hidden" name="y" value="<?= (int)$sel['y'] ?>">
              <select name="cellar_id" data-pick="cellar"><?php foreach ($cel as $cp): ?><option value="<?= (int)$cp['id'] ?>"><?= e($cp['name']) ?> (<?= (int)min(100, round((int)$cp['growth_seconds'] / max(1, (int)$cp['grow_minutes'] * 60) * 100)) ?>% grown)</option><?php endforeach; ?></select>
              <button class="btn act alt">🚪 Replant from cellar</button></form>
          <?php endif; ?>
          <?php if ($unknownCount): ?><p class="help">📕 <?= $unknownCount ?> kind(s) of seed in your satchel are unstudied: they grow <?= unstudied_slow_pct($u) ?>% slower and give <?= 100 - unstudied_yield_pct($u) ?>% less until you study their region (its gardening guide, or its questline in Almanac → Journey) or master the crop.</p><?php endif; ?>
        <?php endif; ?>
      <?php endif; ?>
      <?php if ((int)$sel['tilled']): ?>
        <?php if ($soils && (int)$sel['feed_hours'] <= 0 && (int)$sel['fertility'] < (int)setting('amend_max_fertility')) echo tool_action_form('soil', $sel, 'Work in', ENERGY_COST['soil'], item_select($soils, fn($i) => $i['name'] . ' ×' . $i['qty'], 'soil')); ?>
        <?php if ($mulches) echo tool_action_form('mulch', $sel, 'Add mulch', ENERGY_COST['mulch'], item_select($mulches, fn($i) => $i['name'] . ' ×' . $i['qty'], 'mulch')); ?>
      <?php endif; ?>
      </div>
      <details class="soildet"><summary>More soil details <small class="muted">tips and how care works</small></summary>   <?php /* v1.6.2 */ ?>
      <?php if (!$hasKit): ?><p class="help">A Soil Test Kit from the Mossbottom hub shows exact numbers.</p><?php endif; ?>
      <?php if (tool_tier($uid, 'soiltest') >= 2 && (int)$sel['tilled'] && !$p && ($best = probe_best_crops($u, $sel))): ?>
        <p class="probe">🔬 <b>Soil Probe:</b> best crops you know for this square:
          <?= implode(' · ', array_map(fn($b) => '<b>' . e($b[0]['name']) . '</b> <small class="muted">(' . e($b[1]) . ')</small>', $best)) ?></p>
      <?php endif; ?>
      <?php if ((int)$sel['feed_hours'] > 0): ?>
        <?php $still = array_filter([(int)$sel['feed_fert'] ? '+' . (int)$sel['feed_fert'] . ' fertility' : '', (int)$sel['feed_life'] ? '+' . (int)$sel['feed_life'] . ' soil life' : '',
            npk_text(['n' => (int)($sel['feed_n'] ?? 0), 'p' => (int)($sel['feed_p'] ?? 0), 'k' => (int)($sel['feed_k'] ?? 0)])]); ?>
        <p class="feeding">🪱 Soil improver working in<?= $hasKit && $still ? ': ' . e(implode(', ', $still)) . ' still to come' : '' ?>.
          Ready for more in <?= nice_time(feed_seconds_left($sel)) ?>.</p>
      <?php endif; ?>
      <?php if ($sel['method'] !== 'notill'): ?>
<details class="whycare"><summary>How care works</summary>        <p class="help">A harvest with both earns a point. Each star makes crops here grow <?= (int)setting('care_growth_percent') ?>% faster
          and tilling less harmful: the next till costs <?= care_till_damage($sel) ?> soil life. Left as wild ground, a square loses a star every <?= (int)setting('care_decay_days') ?> days.
          <?= $cs >= 2 ? 'Turning it into a no-till bed starts it at grade ' . e(grade_name(intdiv($cs, 2))) . '.' : '' ?></p></details>
      <?php endif; ?>
      </details>
    <?php endif; ?>
  </div>
</div>
<?php endif; /* v1.4.0: end of the Beds tab */ ?>

<?php if ($tab === 'bld'):   // v0.9.6: compact buildings panel
$bBuilt = $bCan = $bLater = [];
foreach (BUILDINGS as $key => $bdef) {
    if (critter_is_home($key) && (setting('animals_on') === '0' || animals120_blocked($key) || animals140_blocked($key)) && !isset($built[$key])) continue;   // v1.0.0: animals switched off
    if (isset($built[$key])) $bBuilt[$key] = $bdef;
    elseif ((int)$plot['garden_level'] >= $bdef[2]) $bCan[$key] = $bdef;
    else $bLater[$key] = $bdef;
}
$maxLv = fn(string $k): int => 1 + count(BUILDING_UPGRADES[$k] ?? []);
?>
<div class="box gtab" id="buildings">
  <?php if ($readyB): ?><p><b>📦 Something to collect!</b></p><?php endif; ?>
  <p class="help">Tap a building for details. New ones appear in a free yard spot: move them with ✏️ Design yard.</p>
  <?php if ($bBuilt): ?>
  <div class="btiles">
  <?php foreach ($bBuilt as $key => [$bname, $icon, $lvl, $cost, $desc]):
      $blv = max(1, (int)($built[$key]['level'] ?? 1)); $mx = $maxLv($key);
      $ready = isset(BUILDING_PRODUCE[$key]) ? building_ready($built[$key]) + heap_ready($built[$key]) : (critter_is_home($key) ? critter_ready((int)$plot['id'], $key) : 0);
      $next = BUILDING_UPGRADES[$key][$blv + 1] ?? null; $uc = $um = $ul = 0;
      if ($next !== null) [$uc, $um, $ul] = upgrade_cost($key, $blv + 1);
      $canUp = $next !== null && (int)$plot['garden_level'] >= $ul;
      if ($key === 'compost_bin') {
          $hout = heap_output($built[$key]); $need = heap_need($blv, $hout); $sc = (int)$built[$key]['scraps']; $hr = heap_ready($built[$key]);
          $haveScraps = (int)q_val("SELECT ui.qty FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND i.slug = 'food-scrap'", [$uid]);
      }
      if ($key === 'root_cellar') { $cel = cellar_plants((int)$plot['id']); $cslots = cellar_slots((int)$plot['id']); }
      if ($key === 'kitchen') $kb = user_building_bonus($uid, 'kitchen');   // stacking
      $status = $ready > 0 ? $ready . ' ready'
          : ($key === 'compost_bin' ? 'Heap ' . ($sc % $need) . '/' . $need
          : ($key === 'beehive' ? 'Making honey'
          : ($key === 'kitchen' ? cook_pot_limit($u) . ' pots' . (!empty($built[$key]['pantry']) ? ' · 🫙 ' . pantry_jar_limit($uid) : '')
          : ($key === 'root_cellar' ? count($cel) . '/' . $cslots . ' stored' : (critter_is_home($key) ? critter_status((int)$plot['id'], $key) : 'Built'))))); ?>
    <div class="btile built" id="b-<?= e($key) ?>">
      <details class="bt"<?= ($_GET['bld'] ?? '') === $key ? ' open' : '' ?>>
        <summary><span class="bticon" aria-hidden="true"><?= $icon ?></span>
          <span class="btname"><?= e($bname) ?></span>
          <?php if ($mx > 1): ?><span class="pips" role="img" aria-label="Level <?= $blv ?> of <?= $mx ?>"><?php for ($i = 1; $i <= $mx; $i++): ?><i class="<?= $i <= $blv ? 'on' : '' ?>"><?= e(trim(BUILDING_LEVEL_MARK[$i] ?? '') ?: 'I') ?></i><?php endfor; ?></span><?php endif; ?>
          <span class="btstat<?= $ready > 0 ? ' ready' : '' ?>"><?= e($status) ?></span></summary>
        <div class="btbody">
          <p><b>Now:</b> <?= e(BUILDING_NOW[$key][$blv] ?? $desc) ?></p>
          <?php if (critter_is_home($key)) echo critter_panel_html($u, $plot, $key);   // v1.0.0: the residents ?>
          <?php if ($ready > 0): ?>
            <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="collect"><input type="hidden" name="building" value="<?= e($key) ?>">
              <button class="btn small">Collect <?= $ready ?></button></form>
          <?php endif; ?>
          <?php if ($key === 'kitchen'): ?>
            <p>🍳 All your kitchens together: meal buffs last <b>+<?= $kb['buff_pct'] ?>%</b> longer, cooking gives <b>+<?= $kb['xp_pct'] ?>%</b> XP, you have <b><?= cook_pot_limit($u) ?></b> pots<?= $kb['feasts'] ? ', and you can cook feasts' : '' ?>.</p>
            <?php if (!empty($built[$key]['pantry'])): $jb = pantry_busy($uid); $jr = pantry_ready_count($uid); ?>
              <p>🫙 <b>Pantry:</b> <?= $jb ?> jars in use (<?= $kb['jars'] ?> in each of 5 rooms)<?= $jr ? ' · <b>' . $jr . ' ready</b>' : '' ?>. <a href="<?= e(url('inventory.php?tab=craft&c=pantry')) ?>">Open the Pantry →</a></p>
              <details class="how"><summary>How many jars?</summary>
                <p class="help"><?= (int)setting('pantry_jars') ?> to start, +<?= (int)setting('pantry_jars_k3') ?> when a Kitchen with a Pantry is level III, and +<?= (int)setting('stack_pantry_jar_per') ?> for each Pantry in your other gardens (up to +<?= (int)setting('stack_pantry_jar_max') ?>). You have <?= $kb['pantries'] ?> Pantr<?= $kb['pantries'] === 1 ? 'y' : 'ies' ?>.</p></details>
            <?php else: [$pc, $pm] = pantry_cost(); ?>
              <p class="btnext"><b>🫙 Pantry:</b> <?= (int)setting('pantry_jars') ?> jars in each room (jam, chutney, pickles, ferments, cordials) that keep for real days and never spoil.<br><span class="muted">Costs <?= money($pc) ?><?= $pm ? ' + ' . e(upgrade_mats_text($pm)) : '' ?> (Timber Planks: Satchel → Crafting → Building).</span></p>
              <form method="post" data-confirm="Add a Pantry to this Kitchen for <?= number_format($pc) ?> Petals?"><?= csrf_field() ?><input type="hidden" name="do" value="pantry_buy">
                <button class="btn small">🫙 Add a Pantry · <?= money($pc) ?></button></form>
            <?php endif; ?>
            <details class="how"><summary>How stacking works</summary>
              <p class="help"><?= count($kb['levels']) > 1 ? 'Your best kitchen counts fully; each level in your other gardens adds ' . (int)setting('stack_kitchen_buff_pct') . '% buff time and ' . (int)setting('stack_kitchen_xp_pct') . '% XP, and each other Kitchen III adds ' . (int)setting('stack_kitchen_pot_per_iii') . ' pot (up to ' . (int)setting('stack_kitchen_pot_max') . ').' : 'Build another kitchen in a second garden and it adds ' . (int)setting('stack_kitchen_buff_pct') . '% buff time and ' . (int)setting('stack_kitchen_xp_pct') . '% XP per level on top.' ?></p></details>
          <?php endif; ?>
          <?php if ($key === 'compost_bin'): ?>
            <p>♻️ Heap: <b><?= $sc % $need ?>/<?= $need ?></b> scraps for <?= e(HEAP_OUTPUTS[$hout][0]) ?><?= $hr ? ' · <b>' . $hr . ' ready</b>' : '' ?><?= $hr >= (int)setting('compost_heap_max') ? ' (full!)' : '' ?></p>
            <div class="btrow">
            <?php if ($haveScraps > 0): ?>
              <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="add_scraps">
                <button class="btn small">♻️ Add scraps (<?= $haveScraps ?>)</button></form>
            <?php endif; ?>
            <?php $opts = array_filter(HEAP_OUTPUTS, fn($o) => $o[1] <= $blv); if (count($opts) > 1): ?>
              <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="do" value="heap_out">
                <label>Heap makes <select name="out"><?php foreach ($opts as $oslug => $o): ?><option value="<?= e($oslug) ?>"<?= $oslug === $hout ? ' selected' : '' ?>><?= e($o[0]) ?> (<?= heap_need($blv, $oslug) ?> scraps)</option><?php endforeach; ?></select></label>
                <button class="btn small">Set</button></form>
            <?php endif; ?>
            </div>
            <?php if ($haveScraps < 1): ?><p class="help">Eat a raw crop to get Food Scraps, then add them here.</p><?php endif; ?>
          <?php endif; ?>
          <?= skin_panel_html($u, $plot, $key, (string)($built[$key]['skin'] ?? '')) /* v0.9.7: building looks */ ?>
          <?php if ($key === 'root_cellar'): ?>
            <p><?= count($cel) ?>/<?= $cslots ?> stored<?= $cel ? ': ' . e(implode(', ', array_column($cel, 'name'))) : '' ?></p>
            <p class="help">Store: open a perennial’s square. Replant: open an empty tilled square.</p>
          <?php endif; ?>
          <?php if ($next !== null): ?>
            <p class="btnext"><b>Level <?= $blv + 1 ?>:</b> <?= e($next) ?><br><span class="muted">Costs <?= money($uc) ?><?= $um ? ' + ' . e(upgrade_mats_text($um)) : '' ?> (Dressed Stone, Timber Planks and Rope: Satchel → Crafting → Building).</span></p>
            <?php if ($canUp): ?>
              <form method="post" data-confirm="Upgrade your <?= e($bname) ?> to level <?= $blv + 1 ?>?"><?= csrf_field() ?><input type="hidden" name="do" value="upgrade"><input type="hidden" name="building" value="<?= e($key) ?>">
                <button class="btn small">⬆️ Upgrade · <?= money($uc) ?></button></form>
            <?php else: ?><span class="muted">🔒 Garden level <?= $ul ?></span><?php endif; ?>
          <?php endif; ?>
        </div>
      </details>
      <?php if ($ready > 0): ?>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="collect"><input type="hidden" name="building" value="<?= e($key) ?>">
          <button class="btn small">Collect <?= $ready ?></button></form>
      <?php elseif ($canUp): ?>
        <form method="post" data-confirm="Upgrade your <?= e($bname) ?> to level <?= $blv + 1 ?>?"><?= csrf_field() ?><input type="hidden" name="do" value="upgrade"><input type="hidden" name="building" value="<?= e($key) ?>">
          <button class="btn small alt">⬆️ Lv <?= e(trim(BUILDING_LEVEL_MARK[$blv + 1] ?? '') ?: $blv + 1) ?> · <?= number_format($uc) ?></button></form>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <?php if ($bCan): ?>
  <h3 class="bsub">Ready to build</h3>
  <div class="btiles small">
  <?php foreach ($bCan as $key => [$bname, $icon, $lvl, $cost, $desc]): ?>
    <div class="btile" id="b-<?= e($key) ?>">
      <b><span aria-hidden="true"><?= $icon ?></span> <?= e($bname) ?></b>
      <span class="help"><?= e(BUILDING_SHORT[$key] ?? '') ?></span>
      <form method="post" data-confirm="Build a <?= e($bname) ?> for <?= number_format($cost) ?>?"><?= csrf_field() ?><input type="hidden" name="do" value="build"><input type="hidden" name="building" value="<?= e($key) ?>">
        <button class="btn small">Build · <?= money($cost) ?></button></form>
    </div>
  <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <?php if ($bLater): ?>
  <div class="blater"><span class="muted">🔒 Later, as the garden levels up:</span>
  <?php foreach ($bLater as $key => [$bname, $icon, $lvl, $cost, $desc]): ?>
    <details class="lk" id="b-<?= e($key) ?>"><summary><?= $icon ?> <?= e($bname) ?> <small>(Lv <?= $lvl ?>)</small></summary>
      <p class="help"><?= e(BUILDING_SHORT[$key] ?? '') ?> Costs <?= money($cost) ?><?= e(garden_xp_hint($plot, $lvl)) ?></p></details>
  <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php endif; /* v1.4.0: end of the Buildings tab */ ?>

<?php if ($tab === 'an'):   // v1.0.1: the animals (Biddy used to sit above the yard); v1.4.0: their own tab
    $biddyTrade = str_contains($biddy, 'value="biddy"'); ?>
<div class="box animals gtab" id="biddy">
  <?php if ($biddyTrade || $nbr['hint'] !== ''): ?><p class="help"><?= $biddyTrade ? '🐔 Biddy wants scraps' : ($biddy !== '' ? '🐔 Biddy is here' : '') ?><?= e($nbr['hint']) ?></p><?php endif; ?>
  <?php if ($homes): ?><ul class="animalhomes">
    <?php foreach ($homes as $hk): ?><li><a href="<?= e(url('garden.php?bld=' . $hk . '#b-' . $hk)) ?>"><?= BUILDINGS[$hk][1] ?> <?= e(BUILDINGS[$hk][0]) ?></a> <small class="muted"><?= e(critter_status((int)$plot['id'], $hk)) ?></small></li><?php endforeach; ?>
  </ul><?php endif; ?>
  <?= $biddy ?>
  <?= $nbr['html'] /* built from escaped parts in animals120_neighbours() */ ?>
  <?php if ($biddy === '' && $nbr['html'] === '' && setting('animals_on') !== '0'):   // v1.4.8: say who might come, on a quiet day
      $who = array_values(array_filter([setting('biddy_on') !== '0' ? '🐔 Biddy the hen' : '', setting('clementine_on') !== '0' ? '🐐 Clementine the goat' : '', setting('percy_on') !== '0' ? '🕊️ Percy the pigeon' : '']));
      if ($who): ?>
    <p class="help">No visitors at the fence today. <?= e(count($who) > 1 ? implode(', ', array_slice($who, 0, -1)) . ' and ' . end($who) : $who[0]) ?> drop by on some days to trade, and a lovelier yard (curb appeal) brings them a little more often.</p>
  <?php endif; endif; ?>
</div>
<?php endif; /* v1.4.0: end of the Animals tab */ ?>

<?php if ($tab === 'help'):   // v2.6.40: the Help tab is the pal Crew (hired helpers have retired)
    require_once __DIR__ . '/includes/pal_crew.php';
    pcrew_retire_helpers();
    $crewOpen = pcrew_open($u);
    $cslots = pcrew_slots((int)$plot['id']);
    $cpals = $crewOpen ? pj_pals($uid) : [];
    $today = (int)$u['game_day'];
    $seedOpts = $crewOpen ? pcrew_seed_options($uid) : [];
    $seedGrid = function (array $ticked) use ($seedOpts, $plot): string {
        if (!$seedOpts) return '<p class="muted sm">You hold no seeds a pal can plant. The pal will put back the seed each bed last had.</p>';
        $h = '<div class="crewseeds">';
        foreach ($seedOpts as $sid => $o) {
            $off = plant_season_state($o['plant'], gclock_plot_date((int)$plot['id'])) === 'off';
            $h .= '<label class="crewseed' . ($off ? ' off' : '') . '"><input type="checkbox" name="seeds[]" value="' . (int)$sid . '"' . (in_array($sid, $ticked, true) ? ' checked' : '') . '><span>' . e($o['plant']['name']) . ' <small>×' . (int)$o['qty'] . ($off ? ' · off season' : '') . '</small></span></label>';
        }
        return $h . '</div>';
    }; ?>
<div class="box crew gtab">
  <h3>🧩 Garden crew</h3>
  <p class="help">Put a pal on each job. They work <b>while you sleep</b>, and what they did is in the Hovel under Pals.</p>
  <?php if (!$crewOpen): ?><p class="muted">Garden crews open with pal jobs (gnome level <?= (int)pj_min_level() ?>) once you have a Puzzle Pal.</p><?php endif; ?>
  <div class="crewslots">
  <?php foreach (PCREW_ROLES as $rk => [$ri, $rl, $rd, $ropen]): $s = $cslots[$rk] ?? null; $sp = $s ? pj_pal($uid, (string)$s['pal_uid']) : null; ?>
    <div class="crewslot<?= $s ? ' on' : '' ?><?= $ropen ? '' : ' off' ?>">
      <span class="crewic" aria-hidden="true"><?= $ri ?></span>
      <div class="crewb">
        <b><?= e($rl) ?></b>
        <?php if ($s): ?>
          <small class="muted"><?= e($sp['name'] ?? 'A pal') ?> · <?= $s['mode'] === 'full' ? 'full time · night ' . ((int)$s['done'] + 1) . ((int)$s['done'] + 1 > PCREW_FRESH_NIGHTS ? ' · ' . round(pcrew_eff((int)$s['done'] + 1) * 100) . '%' : '') : 'sleep ' . min((int)$s['nights'], (int)$s['done'] + 1) . ' of ' . (int)$s['nights'] ?></small>
          <?php if (pcrew_tired($s)): ?><p class="crewtired"><span class="bang">!</span> <?= e($sp['name'] ?? 'The pal') ?> is tired of this job and works slower. Call them home for a rest day, then give them something else.</p><?php endif; ?>
          <form method="post" class="inline" data-confirm="Call <?= e($sp['name'] ?? 'the pal') ?> home? They rest until you sleep."><?= csrf_field() ?><input type="hidden" name="do" value="crew_recall"><input type="hidden" name="role" value="<?= e($rk) ?>"><input type="hidden" name="t" value="help">
            <button class="btn small alt">Call home</button></form>
          <?php if ($rk === 'plant'):
              $ticked = array_values(array_filter(array_map('intval', explode(',', (string)($s['seeds'] ?? ''))))); $skipIds = array_map('intval', q('SELECT tile_id FROM garden_pal_memory WHERE skip = 1 AND tile_id IN (SELECT id FROM plot_tiles WHERE plot_id = ?)', [$plot['id']])->fetchAll(PDO::FETCH_COLUMN)); ?>
            <details class="crewpick"><summary class="btn small alt">Seeds and beds</summary>
              <p class="help">A bed gets the seed it last had. If it has none, the pal uses a ticked seed.</p>
              <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="crew_seeds"><input type="hidden" name="t" value="help"><?= $seedGrid($ticked) ?><button class="btn small">Save seeds</button></form>
              <p class="help">Beds to leave alone (hands off):</p>
              <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="crew_skip"><input type="hidden" name="t" value="help"><div class="crewbeds">
                <?php foreach ($tiles as $trow) foreach ($trow as $tt): ?><label class="crewbed"><input type="checkbox" name="skip[]" value="<?= (int)$tt['id'] ?>"<?= in_array((int)$tt['id'], $skipIds, true) ? ' checked' : '' ?>><span><?= (int)$tt['x'] + 1 ?>,<?= (int)$tt['y'] + 1 ?></span></label><?php endforeach; ?>
              </div><button class="btn small">Save hands-off beds</button></form>
            </details>
          <?php endif; ?>
        <?php elseif (!$ropen): ?>
          <small class="muted"><?= e($rd) ?></small>
        <?php elseif ($crewOpen): $free = array_filter($cpals, fn($pp) => $pp['status'] === 'home'); ?>
          <small class="muted"><?= e($rd) ?></small>
          <details class="crewpick"><summary class="btn small">Assign a pal</summary>
            <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="crew_assign"><input type="hidden" name="role" value="<?= e($rk) ?>"><input type="hidden" name="t" value="help">
              <?php if (!$free): ?><p class="muted">All your pals are out.</p><?php else: ?>
              <p class="crewpals"><?php $first = true; foreach ($free as $pp): $rest = pcrew_is_resting($uid, $pp['uid'], $today); ?>
                <label class="crewpal<?= $rest ? ' rest' : '' ?>"><input type="radio" name="pal" value="<?= e($pp['uid']) ?>"<?= $rest ? ' disabled' : ($first ? ' checked' : '') ?>> <?= e($pp['name']) ?><?= $rest ? ' <small class="muted">resting until you sleep</small>' : ($pp['active'] ? ' <small class="muted">in your party</small>' : '') ?></label>
              <?php if (!$rest) $first = false; endforeach; ?></p>
              <p class="crewmode"><?php foreach (PCREW_NIGHTS as $n): ?><label><input type="radio" name="mode" value="<?= $n ?>"<?= $n === 1 ? ' checked' : '' ?>> <?= $n ?> sleep<?= $n > 1 ? 's' : '' ?></label> <?php endforeach; ?><label><input type="radio" name="mode" value="full"> Full time</label></p>
              <?php if ($rk === 'plant'): ?><p class="help">Seeds to use when a bed has no memory (optional). Beds always get their own seed back first.</p><?= $seedGrid([]) ?><?php endif; ?>
              <p class="crewmode"><label><input type="checkbox" name="unequip" value="1"> Take off my party if needed</label></p>
              <button class="btn small">Send to work</button>
              <?php endif; ?>
            </form>
          </details>
        <?php else: ?>
          <small class="muted"><?= e($rd) ?></small>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
  <p class="help">A pal called home rests until your next sleep. <b>Full time</b> keeps working until you call them home.</p>
</div>
<?php endif; /* v1.4.0: end of the Help tab */ ?>

<?php if ($tab === 'grow'): ?>
<div class="box gtab"><h3>📐 Add beds</h3>
  <?php $nbeds = (int)q_val('SELECT COUNT(*) FROM plot_tiles WHERE plot_id = ?', [$plot['id']]); $room = bed_room($plot); [$bc, $bi] = bed_add_cost($plot); $bcap = garden_max_side($plot); ?>
  <p>You have <b><?= $nbeds ?></b> beds. At garden level <?= (int)$plot['garden_level'] ?> this garden holds up to <b><?= $bcap * $bcap ?></b>
    (up to <?= (int)setting('max_plot_size') ** 2 ?> as it levels). New beds appear in your yard like decor: move them with ✏️ Design yard.</p>
  <?php if ($room > 0): ?>
    <p class="help">Next <?= min(4, $room) ?> beds cost <b><?= money($bc) ?></b><?= $bi ? ' + ' . e(upgrade_mats_text($bi)) : '' ?> (Timber Planks are made in Satchel → Crafting → Building). Each 4 beds the garden has make the next ones cost <?= (int)setting('bed_add_growth_pct') ?>% more, up to 6× the first price.</p>
    <form method="post" class="inline" data-confirm="Add <?= min(4, $room) ?> beds for <?= number_format($bc) ?><?= $bi ? ' and ' . e(upgrade_mats_text($bi)) : '' ?>?"><?= csrf_field() ?>
      <input type="hidden" name="do" value="expand"><button class="btn small">➕ Add <?= min(4, $room) ?> beds</button></form>
  <?php else: ?>
    <p class="help"><?= $bcap >= (int)setting('max_plot_size') ? 'This garden has as many beds as it can ever hold.' : 'A higher garden level lets it hold more beds. Harvests raise it.' ?></p>
  <?php endif; ?>
</div>

<?= sign_panel_html($u, $plot) /* v0.9.7: garden signpost */ ?>
<?php endif; /* v1.4.0: end of the Grow tab */ ?>

<p class="help">Your gnome’s stats, calling and meal buffs are on the home page’s <a href="<?= e(url('gnome.php?tab=gnome')) ?>">My Gnome</a> tab.</p>
<?php page_footer();
