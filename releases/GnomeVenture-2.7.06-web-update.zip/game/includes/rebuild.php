<?php
declare(strict_types=1);
/**
 * Rebuild a landmark (v0.7.29): a monthly job on the Job Board.
 * A haven, wonder or delve in your home region has fallen into ruin. Four stages, each handed in at once:
 *   1 foundations (dressed stone + Petals) · 2 the frame (timber + rope) · 3 feed the crew (home-cooked meals)
 *   4 finishing touches (fine finds + Petals).
 * Stone, timber and rope are crafted (Crafting → Building) from things gathered on adventures and wood chips.
 * v0.7.88: ruins are per gnome. Each gnome makes a ruin safe for themselves; the first to finish is its Founder (on the plaque).
 * Made safe for you: havens rest better and stock a 4th pantry item, wonders are a little easier, delve chests hold more.
 * v0.7.77: the monthly job is retired (no new offers). Repairs replace it: any gnome can take on a ruin at the place
 * itself (see repair_* below). Old jobs still run through rebuild_hand_in.
 */

const REBUILD_STAGES = [
    1 => ['Clear your path in', [['item', 'building-stone', 6], ['coins', '', 150]]],   // v0.7.88 stage names: the repair is making it safe for yourself
    2 => ['Shore up your corner', [['item', 'timber-plank', 6], ['item', 'rope', 3]]],
    3 => ['Earn the keeper’s trust', [['meal', '', 4]]],
    4 => ['Finishing touches', [['fine', '', 2], ['coins', '', 300]]],
];
const BUILDING_ITEMS = [
    'building-stone' => ['Dressed Stone', 'A squared-off block of stone, ready for building.', 14],
    'timber-plank' => ['Timber Plank', 'A sturdy plank, planed smooth. Builders always need more.', 12],
    'rope' => ['Rope', 'Strong twisted rope for hauling and tying.', 10],
    'beeswax' => ['Beeswax', 'Golden wax from a level 3 beehive. Smells of honey. Makes lovely candles.', 18],   // v0.7.95
];

/** v0.7.88: has this gnome made this place safe (finished its repair)? */
function landmark_rebuilt_by(array $lm, int $uid): bool
{
    return $uid > 0 && (bool)q_val('SELECT 1 FROM landmark_rebuilds WHERE landmark_id = ? AND user_id = ?', [(int)$lm['id'], $uid]);
}

/**
 * v0.7.87: is this place closed because it's in ruins? v0.7.88: ruins are per gnome, so it stays closed
 * for each gnome until that gnome has made it safe.
 */
function landmark_in_ruins(array $lm, int $uid): bool
{
    return in_array($lm['kind'] ?? '', ['haven', 'wonder', 'delve'], true) && !empty($lm['ruined']) && !landmark_rebuilt_by($lm, $uid);
}

/**
 * v0.7.87: about 1 in 3 havens, wonders and delves start in ruins (never in the start region), picked the same way on every
 * world from the place's name. Places someone has already repaired, or started repairing, stay ruins so their work counts.
 * Runs once (setting ruins_assigned); the admin can still set landmarks.ruined by hand afterwards.
 */
function ensure_ruins(bool $force = false): void
{
    if (!$force && setting('ruins_assigned') === '1') return;
    $start = (string)setting('start_region');
    $worked = array_fill_keys(array_map('intval', q('SELECT DISTINCT landmark_id FROM landmark_repairs')->fetchAll(PDO::FETCH_COLUMN)), true);
    foreach (q("SELECT m.id, m.kind, m.restored_at, l.slug, g.code FROM landmarks m JOIN locations l ON l.id = m.location_id
               LEFT JOIN regions g ON g.id = m.region_id")->fetchAll() as $m) {
        $ruined = 0;
        if (in_array($m['kind'], ['haven', 'wonder', 'delve'], true)) {
            $ruined = ((string)$m['code'] !== $start && crc32((string)$m['slug']) % 3 === 0) || isset($worked[(int)$m['id']]) || !empty($m['restored_at']) ? 1 : 0;
        }
        q('UPDATE landmarks SET ruined = ? WHERE id = ?', [$ruined, (int)$m['id']]);
    }
    q("DELETE FROM settings WHERE name = 'ruins_assigned'");
    db_insert('settings', ['name' => 'ruins_assigned', 'value' => '1']);
}

/** Make sure the building materials exist (before crafting recipes are imported). */
function ensure_building_items(): void
{
    foreach (BUILDING_ITEMS as $slug => [$name, $desc, $price]) {
        if (!q_val('SELECT 1 FROM items WHERE slug = ?', [$slug])) {
            db_insert('items', ['name' => $name, 'slug' => $slug, 'category' => 'part', 'rarity' => 20, 'base_price' => $price, 'description' => $desc]);
        }
    }
}

/** Things in the satchel that count for a need: [[item_id, name, qty], …], cheapest first. */
function rebuild_supply(int $uid, array $need): array
{
    [$type, $slug] = $need;
    $where = match ($type) {
        'item' => 'i.slug = ' . db()->quote($slug),
        'meal' => "i.category = 'food' AND i.slug NOT LIKE 'bought-%' AND i.id IN (SELECT output_item_id FROM recipes WHERE category = 'cooking' AND tier IN ('meal', 'feast'))",   // v0.9.4: Meal and Feast only, not snacks
        'fine' => "i.id IN (SELECT item_id FROM gatherables WHERE rarity IN ('uncommon', 'rare'))",
        'deco' => "i.category = 'decor'",   // 2.7.06 decorate: any decor item
        default => '1 = 0',
    };
    return q("SELECT i.id, i.name, ui.qty FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.qty > 0 AND $where ORDER BY i.base_price, i.name", [$uid])->fetchAll();
}

/** 2.7.06 befriend: the highest stop-friend level (STOP_FRIEND_LEVELS index) this gnome has with any stop villager whose stop lies in the region. */
function rebuild_friend_level(int $uid, int $regionId): int
{
    if ($regionId <= 0) return 0;
    require_once __DIR__ . '/stop_folk.php';
    $best = 0;
    foreach (q('SELECT sf.points FROM stop_friend sf JOIN stop_folk f ON f.id = sf.folk_id JOIN locations l ON l.id = f.location_id WHERE sf.user_id = ? AND l.region_id = ?', [$uid, $regionId])->fetchAll(PDO::FETCH_COLUMN) as $pts) $best = max($best, stop_friend_level((int)$pts)['index']);
    return $best;
}

/** 2.7.06 trial: how many times this gnome has cleared this place's own delve or lair (landmark_runs). */
function rebuild_trial_clears(int $uid, int $lmId): int
{
    if ($lmId <= 0) return 0;
    try { return (int)q_val("SELECT COUNT(*) FROM landmark_runs WHERE user_id = ? AND landmark_id = ? AND outcome = 'cleared'", [$uid, $lmId]); } catch (Throwable $e) { return 0; }
}

/** v2.0.76: what a list of needs asks for, with how much this gnome has: [[label, need, have], …]. $prog = days worked, for a `days` need. */
function rebuild_need_rows(array $u, array $needs, int $prog = 0, ?array $lm = null): array
{
    $out = [];
    foreach ($needs as $need) {
        [$type, $slug, $qty] = $need;
        if ($type === 'befriend') { $out[] = ['friendship level with a villager of this region (talk, give gifts)', $qty, rebuild_friend_level((int)$u['id'], (int)($lm['region_id'] ?? 0))]; continue; }   // 2.7.06
        if ($type === 'trial') { $out[] = ['clears of this place’s own delve or lair (win the fights there)', $qty, rebuild_trial_clears((int)$u['id'], (int)($lm['id'] ?? 0))]; continue; }
        if ($type === 'days') {
            $out[] = ['days of clearing (' . (int)$slug . '⚡ each)', $qty, min($prog, $qty)];
            continue;
        }
        if ($type === 'wait') { $out[] = ['game days to pass (they pass when you sleep)', $qty, min($prog, $qty)]; continue; }   // 2.7.06
        if ($type === 'vigil') { $out[] = ['game hours keeping vigil here', $qty, min($prog, $qty)]; continue; }
        $have = $type === 'coins' ? (int)$u['coins'] : array_sum(array_column(rebuild_supply((int)$u['id'], $need), 'qty'));
        $label = match ($type) {
            'item' => BUILDING_ITEMS[$slug][0] ?? ((string)q_val('SELECT name FROM items WHERE slug = ?', [$slug]) ?: $slug),
            'meal' => 'home-cooked meals or feasts (not snacks)',
            'fine' => 'uncommon or rare finds (any)',
            'deco' => 'decor items (any)',
            'coins' => setting('currency_name'),
        };
        $out[] = [$label, $qty, $have];
    }
    return $out;
}

/** What a stage of the OLD fixed list needs, with how much this gnome has: [[label, need, have], …]. */
function rebuild_stage_status(array $u, int $stage): array
{
    return rebuild_need_rows($u, REBUILD_STAGES[$stage][1] ?? []);
}

/** Hand in the next stage's materials. */
function rebuild_hand_in(array $u, array $job): array
{
    $uid = (int)$u['id'];
    $stage = (int)$job['progress'] + 1;
    if (!isset(REBUILD_STAGES[$stage])) return [false, 'This rebuild is finished.'];
    $u = q_one('SELECT * FROM users WHERE id = ?', [$uid]);
    foreach (rebuild_stage_status($u, $stage) as [$label, $need, $have]) {
        if ($have < $need) return [false, 'Stage ' . $stage . ' needs ' . $need . ' ' . $label . ' (you have ' . $have . ').'];
    }
    db()->beginTransaction();
    foreach (REBUILD_STAGES[$stage][1] as $need) {
        [$type, , $qty] = $need;
        if ($type === 'coins') {
            if (q('UPDATE users SET coins = coins - ? WHERE id = ? AND coins >= ?', [$qty, $uid, $qty])->rowCount() !== 1) { db()->rollBack(); return [false, 'You need ' . money($qty) . '.']; }
            continue;
        }
        $left = $qty;
        foreach (rebuild_supply($uid, $need) as $it) {
            $take = min($left, (int)$it['qty']);
            if ($take > 0 && !give_item($uid, (int)$it['id'], -$take)) { db()->rollBack(); return [false, 'Something went missing from your satchel.']; }
            $left -= $take;
            if ($left <= 0) break;
        }
        if ($left > 0) { db()->rollBack(); return [false, 'You don’t have enough for this stage.']; }
    }
    if (q('UPDATE user_jobs SET progress = progress + 1 WHERE id = ? AND progress = ?', [$job['id'], $stage - 1])->rowCount() !== 1) {
        db()->rollBack();
        return [false, 'That stage is already done.'];
    }
    $job['progress'] = $stage;
    require_once __DIR__ . '/jobs.php';
    job_pay($uid, $job);
    $msg = '🧱 ' . REBUILD_STAGES[$stage][0] . ': done!';
    if ($stage === count(REBUILD_STAGES)) $msg .= ' ' . rebuild_finish($u, $job);
    db()->commit();
    return [true, $msg];
}

/** The last stage of an old monthly job: restore its landmark (see rebuild_restore). */
function rebuild_finish(array $u, array $job): string
{
    return rebuild_restore($u, (int)substr((string)$job['target'], 3));
}

/**
 * v0.7.88: this gnome makes a ruin safe for themselves (a landmark_rebuilds row). The first gnome to do it is the Founder
 * (restored_at / restored_by), and is named first on the plaque. Used by repairs and the old monthly jobs.
 */
function rebuild_restore(array $u, int $lmId): string
{
    $lm = q_one('SELECT * FROM landmarks WHERE id = ?', [$lmId]);
    if (!$lm) return '';
    $uid = (int)$u['id'];
    try {
        db_insert('landmark_rebuilds', ['landmark_id' => $lmId, 'user_id' => $uid, 'done_at' => now()]);
    } catch (PDOException $e) {
        return '✨ ' . $lm['name'] . ' is already safe for you.';   // done before
    }
    unlock_entries($uid, 'landmark:' . (string)q_val('SELECT slug FROM locations WHERE id = ?', [$lm['location_id']]));
    if (q('UPDATE landmarks SET restored_at = ?, restored_by = ? WHERE id = ? AND restored_at IS NULL', [now(), $uid, $lmId])->rowCount() === 1) {
        return '✨ You’ve made ' . $lm['name'] . ' safe again, the first gnome to do it: you’re its Founder, and your name is on the plaque.';
    }
    return '✨ You’ve made ' . $lm['name'] . ' safe again. Your name joins the plaque.';
}

/** v0.7.88: how many gnomes have made this place safe. */
function landmark_restorers(array $lm): int
{
    return (int)q_val('SELECT COUNT(*) FROM landmark_rebuilds WHERE landmark_id = ?', [(int)$lm['id']]);
}

/** v0.7.88: "Founder: Name (date)." (the first gnome to make the place safe). */
function founder_line(array $lm): string
{
    $by = empty($lm['restored_by']) ? null : q_one('SELECT gnome_name, username FROM users WHERE id = ?', [(int)$lm['restored_by']]);
    return 'Founder: ' . ($by ? ($by['gnome_name'] ?: $by['username']) : 'a gnome') . (empty($lm['restored_at']) ? '' : ' (' . substr((string)$lm['restored_at'], 0, 10) . ')') . '.';
}

/** v0.7.88: the plaque: "🪧 Restored by N gnomes · Founder: Name (date).", or '' if nobody has made it safe yet. */
function restored_line(array $lm): string
{
    $n = landmark_restorers($lm);
    return $n ? '🪧 Restored by ' . $n . ' gnome' . ($n === 1 ? '' : 's') . ' · ' . founder_line($lm) : '';
}

/** v0.7.88: for a gnome who still has the ruin to make safe: "N gnomes have already made it safe; Founder: …", or ''. */
function landmark_safe_note(array $lm): string
{
    $n = landmark_restorers($lm);
    return $n ? $n . ' gnome' . ($n === 1 ? ' has' : 's have') . ' already made it safe; ' . founder_line($lm) : '';
}

// ---------------- Build plans (v2.0.76) ----------------
// Each ruined place can have its own four stages (data/build_plans.txt) instead of the one fixed list. A repair remembers which it
// started on (landmark_repairs.plan = 'v1' or empty), so a repair begun before a plan was written keeps the old stages.

const BUILD_VERBS = [
    'haul' => 'Haul', 'gather' => 'Gather', 'feed' => 'Feed the crew', 'light' => 'Light up', 'clear' => 'Clear',
    'carry' => 'Carry', 'decorate' => 'Decorate', 'wait' => 'Wait', 'vigil' => 'Keep vigil', 'befriend' => 'Befriend', 'trial' => 'Face the trial',   // 2.7.06: carry = haul by another name (heavy things), decorate = deco:N decor items, wait = wait:N game days pass, vigil = vigil:H game hours at the place
];
/** 2.7.06: until the pictures for the new verbs are drawn they borrow an old one (assets/img/steps/stage-<verb>.png). */
const BUILD_VERB_ART = ['carry' => 'haul', 'decorate' => 'haul', 'wait' => 'light', 'vigil' => 'light', 'befriend' => 'feed', 'trial' => 'clear'];

/** Parse a needs string ("item:rope:3,coins:250,meal:4,fine:2,days:3:3") into need tuples. Bad parts are dropped. */
function build_parse_needs(string $s): array
{
    $out = [];
    foreach (array_filter(array_map('trim', explode(',', $s))) as $part) {
        $f = explode(':', $part);
        $qty = (int)($f[count($f) - 1] ?? 0);
        $out[] = match ($f[0]) {
            'item' => count($f) === 3 && $f[1] !== '' && $qty > 0 ? ['item', $f[1], $qty] : null,
            'coins', 'meal', 'fine', 'deco', 'wait', 'vigil', 'befriend', 'trial' => count($f) === 2 && $qty > 0 ? [$f[0], '', $qty] : null,   // 2.7.06: deco:N, wait:N (game days), vigil:H (game hours)
            'days' => count($f) === 3 && (int)$f[1] > 0 && (int)$f[2] > 0 ? ['days', (string)(int)$f[2], (int)$f[1]] : null,   // [days, energy each, days needed]
            default => null,
        };
    }
    return array_values(array_filter($out));
}

/** @return array<string, array<int, array{name:string, verb:string, needs:array, text:string}>> plans by lower-case landmark name */
function build_plans(bool $reload = false): array
{
    static $cache = null;
    if ($cache !== null && !$reload) return $cache;
    $cache = [];
    $file = __DIR__ . '/data/build_plans.txt';
    foreach (is_file($file) ? file($file, FILE_IGNORE_NEW_LINES) : [] as $line) {
        $f = array_map('trim', explode('|', trim($line)));
        if (($f[0] ?? '') !== 'P' || count($f) < 7) continue;
        $n = (int)$f[2];
        $verb = isset(BUILD_VERBS[$f[3]]) ? $f[3] : 'haul';
        $needs = build_parse_needs($f[5]);
        if ($n < 1 || $n > 4 || !$needs) continue;
        $cache[strtolower($f[1])][$n] = ['name' => $f[4], 'verb' => $verb, 'needs' => $needs, 'text' => $f[6]];
    }
    foreach ($cache as $k => $st) {   // a plan is only used whole: all four stages
        ksort($st);
        if (array_keys($st) !== [1, 2, 3, 4]) unset($cache[$k]); else $cache[$k] = $st;
    }
    return $cache;
}

/** Does this landmark have its own build plan? */
function build_plan_of(array $lm): ?array
{
    return build_plans()[strtolower((string)($lm['name'] ?? ''))] ?? null;
}

/** The four stages a repair works through: its plan if it began on one, else the old fixed list. Same shape as a plan. */
function repair_stages(array $repair): array
{
    if (($repair['plan'] ?? '') === 'v1' && ($p = build_plan_of($repair))) return $p;
    $out = [];
    foreach (REBUILD_STAGES as $n => [$name, $needs]) {
        $out[$n] = ['name' => $name, 'verb' => 'haul', 'needs' => $needs, 'text' => ''];
    }
    return $out;
}

/** A repair row with the plan columns filled in (list rows and panel rows may not carry them). */
function repair_full(array $repair): array
{
    if (array_key_exists('plan', $repair) && array_key_exists('prog', $repair)) return $repair;
    return $repair + (q_one('SELECT plan, prog, prog_day FROM landmark_repairs WHERE id = ?', [(int)($repair['id'] ?? 0)]) ?: ['plan' => null, 'prog' => 0, 'prog_day' => null]);
}

/** The current stage of a repair: [stage number, stage def]. */
function repair_current(array $repair): array
{
    $repair = repair_full($repair);
    $n = (int)$repair['stage'] + 1;
    return [$n, repair_stages($repair)[$n] ?? null];
}

/** Can the gnome hand in the current stage right now? A `clear` stage is never handed in: it finishes by itself on its last day. */
function repair_ready(array $u, array $repair): bool
{
    $repair = repair_full($repair);
    [, $st] = repair_current($repair);
    if (!$st || in_array($st['needs'][0][0] ?? '', ['days', 'wait', 'vigil'], true)) return false;
    return !array_filter(rebuild_need_rows($u, $st['needs'], 0, q_one('SELECT * FROM landmarks WHERE id = ?', [(int)($repair['landmark_id'] ?? 0)]) ?: null), fn($x) => $x[2] < $x[1]);
}

// ---------------- Repairs (v0.7.77) ----------------
// A gnome makes a ruined haven, wonder or delve safe for themselves, at the place itself. Four stages, handed in one at a time
// (the same materials as the old job). Each stage pays Petals and XP. v0.7.88: ruins are per gnome; the first to finish is the Founder.

/** Rewards per stage for a landmark: [coins, xp]. Higher-level regions pay more. */
function repair_rewards(array $lm): array
{
    $L = region_min_level((int)($lm['region_id'] ?? 0));
    // v0.9.1: XP = repair_stage_xp + repair_stage_xp_per_level a level (was +20 a level)
    return [(int)setting('repair_stage_coins') + 10 * $L, (int)setting('repair_stage_xp') + (int)setting('repair_stage_xp_per_level') * $L];   // v0.7.86: Petals +10 a level (was +50)
}

/** Null if this gnome can take on the repair here now, else the reason. */
function repair_can_start(array $u, array $lm): ?string
{
    $uid = (int)$u['id'];
    if (!landmark_in_ruins($lm, $uid)) return 'Nothing here needs repairing.';   // v0.7.87: only places in ruins; v0.7.88: not once this gnome has made it safe
    $min = (int)setting('repair_min_level');
    if ((int)$u['level'] < $min) return 'Repairs open up at gnome level ' . $min . '.';
    // v0.7.85: a given-up repair (dropped_at set) is kept, so it can be taken on again where it was left off
    if ($mine = q_one('SELECT done_at, dropped_at FROM landmark_repairs WHERE user_id = ? AND landmark_id = ?', [$uid, $lm['id']])) {
        if ($mine['done_at']) return 'Nothing here needs repairing.';   // v0.7.88: finished by this gnome
        if (!$mine['dropped_at']) return 'You’re already repairing this.';
    }
    $active = (int)q_val('SELECT COUNT(*) FROM landmark_repairs r JOIN landmarks m ON m.id = r.landmark_id
                          WHERE r.user_id = ? AND r.done_at IS NULL AND r.dropped_at IS NULL', [$uid]);
    if ($active >= (int)setting('repair_max_active')) return 'You already have ' . $active . ' repairs going. Finish one first.';
    if ((int)$u['location_id'] !== (int)$lm['location_id']) return 'You need to be there to take it on.';
    require_once __DIR__ . '/journey.php';
    $slug = (string)q_val('SELECT slug FROM locations WHERE id = ?', [$lm['location_id']]);
    if (journey_lock($uid, 'place', $slug)) return 'Wren’s Journey has plans for this place first.';
    return null;
}

/** Take on a repair of a landmark. Returns [ok, message]. */
function repair_start(array $u, int $lmId): array
{
    $lm = q_one('SELECT * FROM landmarks WHERE id = ?', [$lmId]);
    if (!$lm) return [false, 'Nothing here needs repairing.'];
    if ($why = repair_can_start($u, $lm)) return [false, $why];
    [$coins, $xp] = repair_rewards($lm);
    $uid = (int)$u['id'];
    $old = q_one('SELECT id, stage FROM landmark_repairs WHERE user_id = ? AND landmark_id = ? AND done_at IS NULL AND dropped_at IS NOT NULL', [$uid, $lmId]);
    if ($old) {
        // v0.7.85: pick up the given-up row with its stage kept, so stages already paid are never paid again
        if (q('UPDATE landmark_repairs SET dropped_at = NULL WHERE id = ? AND user_id = ? AND done_at IS NULL AND dropped_at IS NOT NULL', [(int)$old['id'], $uid])->rowCount() !== 1) {
            return [false, 'You’re already repairing this.'];
        }
        return [true, '🔨 You pick up making ' . $lm['name'] . ' safe where you left off (' . (int)$old['stage'] . ' of 4 stages done).'];
    }
    try {
        $newId = db_insert('landmark_repairs', ['user_id' => $uid, 'landmark_id' => $lmId, 'stage' => 0, 'started_at' => now(), 'plan' => build_plan_of($lm) ? 'v1' : null]);
    } catch (PDOException $e) {
        return [false, 'You’re already repairing this.'];   // a double click
    }
    if (!empty($newId)) repair_arm_wait($uid, (int)$newId, ['id' => $newId, 'plan' => build_plan_of($lm) ? 'v1' : null, 'name' => $lm['name']], 1);
    return [true, '🔨 You start making ' . $lm['name'] . ' safe for yourself: clearing your own path in, shoring up your corner, earning the keeper’s trust. Hand in each stage when you have the materials, here, from the Job Board or from Tasks → Journey. Each one pays ' . money($coins) . ' and ' . $xp . ' XP.'];
}

/**
 * Pay for finishing a stage (inside the caller's transaction): Petals, XP, stage + 1, and the last stage restores the place.
 * $stage is the stage being finished (1-4); the update only goes through if the repair is still on the stage before it.
 */
function repair_advance(array $fresh, array $r, array $lm, int $stage, array $def): array
{
    require_once __DIR__ . '/gnome.php';   // add_xp
    $uid = (int)$fresh['id'];
    if (q('UPDATE landmark_repairs SET stage = stage + 1, prog = 0, settle_day = NULL WHERE id = ? AND user_id = ? AND stage = ? AND done_at IS NULL AND dropped_at IS NULL', [(int)$r['id'], $uid, $stage - 1])->rowCount() !== 1) {
        return [false, 'That stage is already done.'];
    }
    repair_arm_wait($uid, (int)$r['id'], $r + ['name' => $lm['name']], $stage + 1);   // 2.7.06: a wait stage starts counting its game days now
    [$coins, $xp] = repair_rewards($lm);
    q('UPDATE users SET coins = coins + ? WHERE id = ?', [$coins, $uid]);
    add_xp($uid, $xp, 'Repairs');   // v0.9.1: named source for the XP log
    $msg = '🧱 ' . $def['name'] . ': done! +' . money($coins) . ', +' . $xp . ' XP.';
    if ($stage === 4) {
        q('UPDATE landmark_repairs SET done_at = ? WHERE id = ? AND user_id = ? AND dropped_at IS NULL', [now(), (int)$r['id'], $uid]);
        $msg .= ' ' . rebuild_restore($fresh, (int)$lm['id']);
    }
    return [true, $msg];
}

/**
 * Sleep-days: a "work here" day that carried past 22:00 leaves the gnome busy until they sleep. The stage's pay waits for that
 * (settle_day); after the next sleep this finishes the stage. Cheap; called before repairs are read or worked.
 */
function repair_settle(int $uid): void
{
    if (!gclock_on()) return;
    $day = (int)q_val('SELECT game_day FROM users WHERE id = ?', [$uid]);
    foreach (q('SELECT * FROM landmark_repairs WHERE user_id = ? AND settle_day IS NOT NULL AND settle_day < ? AND done_at IS NULL AND dropped_at IS NULL', [$uid, $day])->fetchAll() as $r) {
        $lm = q_one('SELECT * FROM landmarks WHERE id = ?', [$r['landmark_id']]);
        if (!$lm) continue;
        [$stage, $def] = repair_current($r + ['name' => $lm['name']]);
        if (!$def || !in_array($def['needs'][0][0] ?? '', ['days', 'wait'], true)) { q('UPDATE landmark_repairs SET settle_day = NULL WHERE id = ?', [$r['id']]); continue; }
        $fresh = q_one('SELECT * FROM users WHERE id = ?', [$uid]);
        db()->beginTransaction();
        [$ok, $msg] = repair_advance($fresh, $r, $lm, $stage, $def);
        if (!$ok) { db()->rollBack(); continue; }
        db()->commit();
        notify($uid, '🪓 ' . $msg);
    }
}

/**
 * 2.7.06 `wait` stages: when stage $stageNo (1-4) of this repair is a wait of N game days, it is armed to finish on game day (today + N) through settle_day, which repair_settle() pays on a later page load.
 * Returns the day it will finish, or null when the stage is not a wait. (A wait stage of 0 days finishes at the next settle.)
 */
function repair_arm_wait(int $uid, int $repairId, array $repair, int $stageNo): ?int
{
    $st = repair_stages(repair_full($repair))[$stageNo] ?? null;
    if (!$st || ($st['needs'][0][0] ?? '') !== 'wait') return null;
    $day = (int)q_val('SELECT game_day FROM users WHERE id = ?', [$uid]) + max(1, (int)$st['needs'][0][2]);
    q('UPDATE landmark_repairs SET settle_day = ? WHERE id = ?', [$day - 1, $repairId]);   // repair_settle pays when settle_day < today, so day - 1 = on game day `day`
    return $day;
}

/** 2.7.06: keep vigil at the place for the stage's game hours (no energy; the time is spent like any long job). Returns [ok, message]. */
function repair_vigil(array $u, int $repairId): array
{
    $uid = (int)$u['id'];
    repair_settle($uid);
    $r = q_one('SELECT * FROM landmark_repairs WHERE id = ? AND user_id = ? AND done_at IS NULL AND dropped_at IS NULL', [$repairId, $uid]);
    if (!$r) return [false, 'That repair is finished or gone.'];
    $lm = q_one('SELECT * FROM landmarks WHERE id = ?', [$r['landmark_id']]);
    if (!$lm) return [false, 'That repair is gone.'];
    [$stage, $def] = repair_current($r + ['name' => $lm['name']]);
    if (!$def || ($def['needs'][0][0] ?? '') !== 'vigil') return [false, 'This stage is not a vigil.'];
    if ((int)$u['location_id'] !== (int)$lm['location_id']) return [false, 'You need to be there to keep vigil.'];
    if (!function_exists('gclock_on') || !gclock_on()) return [false, 'A vigil needs the game clock.'];
    $hours = max(1, (int)$def['needs'][0][2]);
    if (($busy = gclock_busy_minutes($uid)) > 0) return [false, 'You are still busy with a long job. Sleep, and finish it in the morning (' . round($busy / 60, 1) . ' h left).'];
    if (!game_spend($uid, $hours * 60)) return [false, 'There is not enough of the day left for a ' . $hours . ' hour vigil.'];
    $fresh = q_one('SELECT * FROM users WHERE id = ?', [$uid]);
    db()->beginTransaction();
    [$ok, $msg] = repair_advance($fresh, $r, $lm, $stage, $def);
    if (!$ok) { db()->rollBack(); return [false, $msg]; }
    db()->commit();
    return [true, '🕯️ You keep vigil for ' . $hours . ' hour' . ($hours === 1 ? '' : 's') . '. ' . $msg];
}

/** Hand in the next stage of a repair. Returns [ok, message]. */
function repair_hand(array $u, int $repairId): array
{
    $uid = (int)$u['id'];
    repair_settle($uid);
    $r = q_one('SELECT * FROM landmark_repairs WHERE id = ? AND user_id = ? AND done_at IS NULL AND dropped_at IS NULL', [$repairId, $uid]);
    if (!$r) return [false, 'That repair is finished or gone.'];
    $lm = q_one('SELECT * FROM landmarks WHERE id = ?', [$r['landmark_id']]);
    if (!$lm) return [false, 'That repair is gone.'];
    // v0.7.88: ruins are per gnome, so your repair stays yours to finish even after others have made the place safe
    [$stage, $def] = repair_current($r + ['name' => $lm['name']]);
    if (!$def) return [false, 'This repair is finished.'];
    if (($def['needs'][0][0] ?? '') === 'days') return [false, 'This stage is done by working here on different days: use “Work here today”.'];
    if (($def['needs'][0][0] ?? '') === 'wait') return [false, 'This stage is done by waiting: it finishes by itself when enough game days have passed.'];
    if (($def['needs'][0][0] ?? '') === 'vigil') return [false, 'This stage is done by keeping vigil here: use “Keep vigil”.'];
    $fresh = q_one('SELECT * FROM users WHERE id = ?', [$uid]);
    foreach (rebuild_need_rows($fresh, $def['needs'], 0, $lm) as [$label, $need, $have]) {
        if ($have < $need) return [false, 'Stage ' . $stage . ' needs ' . $need . ' ' . $label . ' (you have ' . $have . ').'];
    }
    db()->beginTransaction();
    foreach ($def['needs'] as $need) {
        [$type, , $qty] = $need;
        if (in_array($type, ['befriend', 'trial'], true)) continue;   // 2.7.06: a condition, nothing is handed over
        if ($type === 'coins') {
            if (q('UPDATE users SET coins = coins - ? WHERE id = ? AND coins >= ?', [$qty, $uid, $qty])->rowCount() !== 1) { db()->rollBack(); return [false, 'You need ' . money($qty) . '.']; }
            continue;
        }
        $left = $qty;
        foreach (rebuild_supply($uid, $need) as $it) {
            $take = min($left, (int)$it['qty']);
            if ($take > 0 && !give_item($uid, (int)$it['id'], -$take)) { db()->rollBack(); return [false, 'Something went missing from your satchel.']; }
            $left -= $take;
            if ($left <= 0) break;
        }
        if ($left > 0) { db()->rollBack(); return [false, 'You don’t have enough for this stage.']; }
    }
    [$ok, $msg] = repair_advance($fresh, $r, $lm, $stage, $def);
    if (!$ok) { db()->rollBack(); return [false, $msg]; }
    db()->commit();
    return [true, $msg];
}

/**
 * v2.0.76: one day of work on a `clear` stage, at the place itself. Counts once per Hollow day, costs the stage's energy,
 * and finishes the stage on the last day. Returns [ok, message].
 */
function repair_work(array $u, int $repairId): array
{
    $uid = (int)$u['id'];
    repair_settle($uid);
    $r = q_one('SELECT * FROM landmark_repairs WHERE id = ? AND user_id = ? AND done_at IS NULL AND dropped_at IS NULL', [$repairId, $uid]);
    if (!$r) return [false, 'That repair is finished or gone.'];
    $lm = q_one('SELECT * FROM landmarks WHERE id = ?', [$r['landmark_id']]);
    if (!$lm) return [false, 'That repair is gone.'];
    [$stage, $def] = repair_current($r + ['name' => $lm['name']]);
    if (!$def || ($def['needs'][0][0] ?? '') !== 'days') return [false, 'This stage is not done by working here.'];
    if ((int)$u['location_id'] !== (int)$lm['location_id']) return [false, 'You need to be there to work on it.'];
    [, $energy, $days] = $def['needs'][0];
    $energy = (int)$energy;
    if (($busy = gclock_busy_minutes($uid)) > 0) return [false, 'You are still busy with a long job. Sleep, and finish it in the morning (' . round($busy / 60, 1) . ' h left).'];   // before anything is written
    $today = gclock_my_date();
    $fresh = q_one('SELECT * FROM users WHERE id = ?', [(int)$u['id']]);
    db()->beginTransaction();
    if (q('UPDATE landmark_repairs SET prog = prog + 1, prog_day = ? WHERE id = ? AND user_id = ? AND stage = ? AND (prog_day IS NULL OR prog_day <> ?) AND done_at IS NULL AND dropped_at IS NULL',
          [$today, $repairId, $uid, $stage - 1, $today])->rowCount() !== 1) {
        db()->rollBack();
        return [false, 'You’ve already worked here today. Come back tomorrow.'];
    }
    if (!spend_energy($uid, $energy, 'repair')) { db()->rollBack(); return [false, 'Working here takes ' . $energy . '⚡.']; }
    $prog = (int)q_val('SELECT prog FROM landmark_repairs WHERE id = ?', [$repairId]);
    if ($prog < $days) {
        db()->commit();
        return [true, '🪓 A good day’s work: ' . $prog . ' of ' . $days . ' days done on “' . $def['name'] . '”. Come back tomorrow.'];
    }
    if (gclock_busy_minutes($uid) > 0) {   // the last day's work runs past 22:00: the stage pays once it is finished, after the next sleep
        q('UPDATE landmark_repairs SET settle_day = ? WHERE id = ?', [(int)q_val('SELECT game_day FROM users WHERE id = ?', [$uid]), $repairId]);
        db()->commit();
        return [true, '🪓 The last day’s work on “' . $def['name'] . '” runs into the night. Sleep, and the stage is done (' . money(repair_rewards($lm)[0]) . ' and ' . repair_rewards($lm)[1] . ' XP then).'];
    }
    [$ok, $msg] = repair_advance($fresh, $r, $lm, $stage, $def);
    if (!$ok) { db()->rollBack(); return [false, $msg]; }
    db()->commit();
    return [true, '🪓 ' . $msg];
}

/** Give up an unfinished repair. Materials already handed in are not returned. Returns [ok, message]. */
function repair_drop(array $u, int $repairId): array
{
    // v0.7.85: keep the row (stage kept) so taking it on again does not pay the stages twice
    if (q('UPDATE landmark_repairs SET dropped_at = ? WHERE id = ? AND user_id = ? AND done_at IS NULL AND dropped_at IS NULL', [now(), $repairId, (int)$u['id']])->rowCount() !== 1) {
        return [false, 'That repair is finished or gone.'];
    }
    return [true, '🏳️ You gave up that repair. The materials you handed in stay with the builders.'];
}

/** This gnome's unfinished repairs, oldest first (including ones others have already made safe: this gnome can still finish). */
function repair_list(int $uid): array
{
    repair_settle($uid);
    return q('SELECT r.id, r.landmark_id, r.stage, r.plan, r.prog, r.prog_day, r.started_at, m.name, m.kind, m.region_id, m.location_id, l.slug AS loc_slug, l.name AS loc_name
              FROM landmark_repairs r JOIN landmarks m ON m.id = r.landmark_id JOIN locations l ON l.id = m.location_id
              WHERE r.user_id = ? AND r.done_at IS NULL AND r.dropped_at IS NULL ORDER BY r.started_at, r.id', [$uid])->fetchAll();
}

/** One repair as a box: the four stages, what the current one needs, and the buttons. $repair is a repair_list row. */
function repair_box(array $u, array $repair, string $back): string
{
    $repair = repair_full($repair);
    $stages = repair_stages($repair);
    [$stage, $def] = repair_current($repair);
    if (!$def) return '';
    $isClear = ($def['needs'][0][0] ?? '') === 'days';
    $isWait = ($def['needs'][0][0] ?? '') === 'wait'; $isVigil = ($def['needs'][0][0] ?? '') === 'vigil';   // 2.7.06
    $st = rebuild_need_rows($u, $def['needs'], (int)$repair['prog'], q_one('SELECT * FROM landmarks WHERE id = ?', [(int)$repair['landmark_id']]) ?: null);
    $ready = repair_ready($u, $repair);
    $today = gclock_my_date();
    $workedToday = $isClear && (string)($repair['prog_day'] ?? '') === $today;
    [$coins, $xp] = repair_rewards($repair);
    $hidden = '<input type="hidden" name="lm" value="' . (int)$repair['landmark_id'] . '"><input type="hidden" name="repair" value="' . (int)$repair['id'] . '"><input type="hidden" name="back" value="' . e($back) . '">';
    $h = '<div class="rebuild repair"><h3>🔨 ' . e((string)$repair['name']) . '</h3><ol class="stages">';
    foreach ($stages as $n => $s) {
        $h .= '<li class="' . ($n < $stage ? 'done' : ($n === $stage ? 'now' : '')) . '">' . ($n < $stage ? '✅ ' : build_verb_img($s['verb'])) . e($s['name']) . '</li>';
    }
    $h .= '</ol>';
    $h .= '<p><b>Stage ' . $stage . ': ' . e($def['name']) . '</b> needs:</p>';
    if ($def['text'] !== '') $h .= '<p class="help">' . e($def['text']) . '</p>';
    $h .= '<ul>';
    foreach ($st as [$lbl, $need, $have]) {
        $h .= '<li class="' . ($have >= $need ? 'good' : 'bad') . '">' . $need . ' ' . e((string)$lbl) . ' <small class="muted">(' . ($isClear ? 'done so far: ' : 'you have ') . number_format($have) . ')</small></li>';
    }
    $usesTools = false;   // build plans can ask for tools (lanterns, trugs, baskets): they are handed in for good
    foreach ($def['needs'] as $nd) if (($nd[0] ?? '') === 'item' && (string)q_val('SELECT category FROM items WHERE slug = ?', [(string)$nd[1]]) === 'tool') $usesTools = true;
    $h .= '</ul>' . ($usesTools ? '<p class="help">🔧 Tools you hand in are used up.</p>' : '') . '<p class="help">Each stage pays ' . money($coins) . ' and ' . $xp . ' XP.</p>';
    if ($isWait) {
        $left = max(0, (int)q_val('SELECT settle_day FROM landmark_repairs WHERE id = ?', [(int)$repair['id']]) + 1 - (int)q_val('SELECT game_day FROM users WHERE id = ?', [(int)$u['id']]));
        $h .= '<p class="help">⏳ Nothing to hand in: this stage finishes by itself. ' . ($left > 0 ? $left . ' more game day' . ($left === 1 ? '' : 's') . ' (sleep to let them pass).' : 'It finishes the next time you look.') . '</p>';
    }
    $h .= $isWait ? ''
        : ($isVigil
        ? '<form method="post" class="inline" action="' . e(url('landmark.php')) . '">' . csrf_field() . '<input type="hidden" name="do" value="repair_vigil">' . $hidden
            . '<button class="btn small">' . build_verb_img('vigil') . 'Keep vigil <span class="cost">' . (int)$def['needs'][0][2] . ' h</span></button></form> '
        : ($isClear        ? '<form method="post" class="inline" action="' . e(url('landmark.php')) . '">' . csrf_field() . '<input type="hidden" name="do" value="repair_work">' . $hidden
            . '<button class="btn small"' . ($workedToday ? ' disabled' : '') . '>' . build_verb_img('clear') . 'Work here today <span class="cost">' . (int)$def['needs'][0][1] . '⚡' . e(gclock_cost_tag(null, null, 'repair')) . '</span></button></form> '
        : '<form method="post" class="inline" action="' . e(url('landmark.php')) . '">' . csrf_field() . '<input type="hidden" name="do" value="repair_hand">' . $hidden
            . '<button class="btn small"' . ($ready ? '' : ' disabled') . '>' . build_verb_img($def['verb']) . 'Hand in stage ' . $stage . '</button></form> '));
    if (!$isClear && !$isWait && !$isVigil && in_array($def['verb'], ['haul', 'carry'], true)) $h .= '<a class="btn small alt" href="' . e(url('inventory.php?tab=craft&c=building')) . '">Craft materials →</a> ';
    $h .= '<form method="post" class="inline" action="' . e(url('landmark.php')) . '" data-confirm="Give up this repair? The materials you’ve handed in are not returned.">' . csrf_field() . '<input type="hidden" name="do" value="repair_drop">' . $hidden
        . '<button class="btn small alt">Give up</button></form></div>';
    return $h;
}

/** v2.0.76: the little picture for a stage verb. PLACEHOLDER art until the real icons are drawn (see claude/todo-art-variety.md). */
function build_verb_img(string $verb): string
{
    $verb = isset(BUILD_VERBS[$verb]) ? $verb : 'haul';
    $file = BUILD_VERB_ART[$verb] ?? $verb;   // 2.7.06: borrowed picture until the new ones are drawn
    return '<img class="ico pix buildverb" src="' . e(art_url('assets/img/steps/stage-' . $file)) . '" alt="' . e(BUILD_VERBS[$verb]) . '" title="' . e(BUILD_VERBS[$verb]) . '" width="20" height="20" loading="lazy" decoding="async"> ';
}
