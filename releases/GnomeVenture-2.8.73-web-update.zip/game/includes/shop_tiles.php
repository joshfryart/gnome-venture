<?php
declare(strict_types=1);
/* v2.0.5: ONE tile renderer + ONE sheet (dialog) for every pure buy/sell item list (shop.php, market.php, marketday.php).
   JS lives in site.js ("shop tiles"), CSS at the end of style.css. v2.0.67: the tile is an item square (item_square.php); put tiles in item_grid(). */
require_once __DIR__ . '/item_square.php';

const SHOP_CATS = ['seed' => '🌱 Seeds', 'produce' => '🥕 Crops', 'flower' => '🌸 Flowers', 'food' => '🍲 Food', 'soil' => '🪱 Soil', 'mulch' => '🍂 Mulch',
    'supply' => '🧪 Supplies', 'tool' => '🧰 Tools', 'guide' => '📗 Guides', 'forage' => '🍄 Finds', 'part' => '🦴 Parts', 'decor' => '🏡 Decor', 'arrangement' => '💐 Arrangements', 'packet' => '📦 Seed packets'];

function shop_cat_of(string $c): string { return isset(SHOP_CATS[$c]) ? $c : 'other'; }
function shop_cat_rank(array $r): int { return (int)array_search(shop_cat_of((string)$r['category']), array_keys(SHOP_CATS + ['other' => 1]), true); }

/** Category chips that only hide and show tiles inside the nearest .shopwrap. */
function shop_chips(array $rows, string $mode = ''): string
{
    $bar = $mode === '' ? '' : shop_filter_bar($mode);
    $n = [];
    foreach ($rows as $r) { $k = shop_cat_of((string)$r['category']); $n[$k] = ($n[$k] ?? 0) + 1; }
    if (count($n) < 2) return $bar;
    $h = '<nav class="chips shopcats" aria-label="Show"><button type="button" class="on" data-cat="all">All <small>' . count($rows) . '</small></button>';
    foreach (SHOP_CATS + ['other' => '📦 Other'] as $k => $label) if (!empty($n[$k])) $h .= '<button type="button" data-cat="' . $k . '">' . $label . ' <small>' . $n[$k] . '</small></button>';
    return $h . '</nav>' . $bar;
}

/** Sort, rarity and "can afford" / "wanted" filters; site.js ("shop filters") reorders and hides tiles, nothing is posted. */
function shop_filter_bar(string $mode): string
{
    return '<div class="shopfilt" role="group" aria-label="Sort and filter">'
        . '<label>Sort <select data-sf="sort"><option value="">Default</option><option value="name">Name A–Z</option><option value="pl">Price: low to high</option><option value="ph">Price: high to low</option><option value="rar">Rarity: rarest first</option></select></label>'
        . '<label>Rarity <select data-sf="rar"><option value="">All</option><option value="c">Common</option><option value="u">Uncommon</option><option value="r">Rare</option><option value="l">Legendary</option></select></label>'
        . ($mode === 'buy' ? '<label class="sfck"><input type="checkbox" data-sf="afford"> Can afford</label>' : '<label class="sfck"><input type="checkbox" data-sf="want"> Wanted</label>')
        . '</div>';
}

/** v2.0.67: the basket bar. Sheets add to it (site.js "shop basket"); one post buys or sells everything in it. */
function shop_basket_html(string $mode, string $action): string
{
    return '<form method="post" class="basket" data-mode="' . $mode . '" action="' . e($action) . '" hidden>' . csrf_field()
        . '<input type="hidden" name="do" value="' . $mode . '"><div class="blist"></div><p class="sbad" hidden></p>'
        . '<div class="bfoot"><b class="btotal" data-lbl="' . ($mode === 'buy' ? 'Total' : 'You get') . '"></b>'
        . '<button type="button" class="btn ghost bclear">Empty</button><button class="btn bgo">🧺 ' . ($mode === 'buy' ? 'Buy' : 'Sell') . ' all</button></div></form>';
}

/** A short marker for the tile: season and price direction only. */
function shop_mini(string $html): string
{
    $o = '';
    if (str_contains($html, '⭐')) $o .= '⭐';
    if (str_contains($html, '🌿') || str_contains($html, '🌱')) $o .= '🌿';
    elseif (str_contains($html, '🍂')) $o .= '🍂';
    if (str_contains($html, '↑')) $o .= '<span class="up">↑</span>';
    elseif (str_contains($html, '↓')) $o .= '<span class="down">↓</span>';
    return $o;
}

/**
 * One tile + its sheet. v2.0.67: the tile is an item square (includes/item_square.php, mockup 4); the hooks stay:
 * div.btile.stile[data-cat data-id data-price data-max data-name] > button.spick[data-sheet] + dialog.isheet (site.js "shop tiles"),
 * .sel on the .stile from the basket (site.js "shop basket"), .catoff from the category chips. Options:
 *  id (int, form key), item (row with name/category/description/id), price (int each), max (int), priceHtml, mini (html), tags (html[]), info (html),
 *  dim (bool), badge (string), mode ('buy'|'sell'), action (form URL), open (bool: show the form), qtyName ('qty[ID]' default or 'qty'),
 *  fields (name => value hidden inputs, in order), totalLabel (override "Total"/"You get"), each (text after the price, default 'each'), counts (title for the badge), basket (bool: offer "Add to basket"; needs a .basket form in the .shopwrap).
 *  v2.0.67: coins (?int: the buyer's Petals; a price above it shows "Short N" on stone felt), offNote (words on a dim tile: "Sold out today"),
 *  flag ('New'), icon (html replacing the item picture on the tile and in the sheet). The mini html is read for ⭐ (wanted) and ↑ / ↓ (price trend);
 *  any other words in it become a small note chip. A numeric badge is the corner count, '✔' the done badge.
 */
function shop_tile(array $o): string
{
    static $IL = null;
    if ($IL === null) $IL = item_lookups();
    $i = (array)$o['item'];
    $id = (int)$o['id'];
    $price = (int)$o['price'];
    $max = (int)$o['max'];
    $mode = (string)($o['mode'] ?? 'buy');
    $priceHtml = (string)($o['priceHtml'] ?? money($price));
    $mini = (string)($o['mini'] ?? '');
    $tags = (array)($o['tags'] ?? []);
    $info = (string)($o['info'] ?? '');
    $badge = (string)($o['badge'] ?? '');
    $qtyName = (string)($o['qtyName'] ?? 'qty[' . $id . ']');
    [$rl, $rw] = item_rarity($i, $IL);
    $desc = (string)($i['description'] ?? '');
    $pieceH = (string)($o['piece'] ?? '');   // a wearable's puzzle piece picture, inside the About fold
    $descH = $desc === '' && $pieceH === '' ? '' : '<details class="helpfold sdesc" open><summary>About it</summary>' . ($desc === '' ? '' : '<p>' . desc_html($desc) . '</p>') . $pieceH . '</details>';   // always a fold, always open (Josh)
    $verb = $mode === 'buy' ? 'Buy' : 'Sell';
    $lbl = (string)($o['totalLabel'] ?? ($mode === 'buy' ? 'Total' : 'You get'));
    $hidden = '';
    foreach ((array)($o['fields'] ?? []) as $k => $v) $hidden .= '<input type="hidden" name="' . e((string)$k) . '" value="' . e((string)$v) . '">';
    $form = empty($o['open']) || $max < 1 ? '' : '<form method="post" class="sheetform" data-mode="' . $mode . '" data-price="' . $price . '" data-max="' . $max . '"' . (!empty($o['qtyDefault']) ? ' data-qdef="' . min($max, (int)$o['qtyDefault']) . '"' : '') . ' action="' . e((string)$o['action']) . '">' . csrf_field()
        . '<input type="hidden" name="do" value="' . $mode . '">' . $hidden
        . '<div class="qctl"><button type="button" class="qbtn" data-q="-1" aria-label="One less">−</button>'
        . '<input type="number" class="qin" name="' . e($qtyName) . '" value="' . (!empty($o['qtyDefault']) ? min($max, (int)$o['qtyDefault']) : 1) . '" min="1" max="' . $max . '" inputmode="numeric" aria-label="How many">'
        . '<button type="button" class="qbtn" data-q="1" aria-label="One more">+</button>'
        . '<button type="button" class="qbtn qmax" data-q="max">All</button></div>'
        . '<p class="sline"><span>' . $priceHtml . ' ' . e((string)($o['each'] ?? 'each')) . '</span> · <b class="stot" data-lbl="' . e($lbl) . '"></b></p>'
        . '<p class="sbad" hidden></p>'
        . '<button class="btn sgo">' . $verb . '</button>'
        . (!empty($o['basket']) ? '<button type="button" class="btn ghost sadd">🧺 Add to basket</button>' : '') . '</form>';

    // the square: wanted / trend from the mini marker, count or done from the badge, stone felt when dim or too dear
    $states = [];
    $chips = [];
    $wanted = str_contains($mini, '⭐');
    if ($wanted) { $states[] = 'want'; $chips[] = ['want', '★ Wanted']; }
    $trend = str_contains($mini, 'class="up"') ? 'up' : (str_contains($mini, 'class="down"') ? 'down' : '');
    $rest = trim(str_replace(['⭐', '🌿', '🍂', '↑', '↓'], '', html_entity_decode(strip_tags($mini), ENT_QUOTES, 'UTF-8')));
    $coins = $o['coins'] ?? null;
    $short = $mode === 'buy' && $coins !== null && $max > 0 && empty($o['dim']) && $price > (int)$coins ? $price - (int)$coins : 0;
    if ($short > 0) { $states[] = 'off'; $chips[] = ['short', 'Short ' . number_format($short) . '<span class="vh"> ' . e(setting('currency_name')) . '</span>']; }
    if (!empty($o['dim'])) {
        $states[] = 'off';
        if (($o['offNote'] ?? '') !== '') $chips[] = ['note', e((string)$o['offNote'])];
    }
    if ($rest !== '') $chips[] = ['note', e($rest)];
    if (!empty($o['basket'])) $chips[] = ['inb', '', true];   // "2 in basket", filled by site.js
    $count = null;
    if ($badge === '✔') $states[] = 'done';
    elseif ($badge !== '' && ctype_digit($badge)) $count = (int)$badge;
    $icon = (string)($o['icon'] ?? '');
    $sq = item_square(['item' => $i, 'rarity' => $rl, 'icon' => $icon, 'count' => $count,
        'countLabel' => (string)($o['badgeTitle'] ?? ($mode === 'buy' ? 'On the shelf' : 'You have')),
        'price' => $price, 'trend' => $trend, 'trendWord' => $trend === '' ? '' : ($mode === 'sell' ? ($trend === 'up' ? ', pays more today' : ', pays less today') : ($trend === 'up' ? ', dearer today' : ', cheaper today')),
        'chips' => $chips, 'states' => array_values(array_unique($states)), 'flag' => (string)($o['flag'] ?? ''),
        'class' => 'spick', 'attrs' => ['data-sheet' => true, 'aria-haspopup' => 'dialog']]);
    // v2.4.0: what eating it gives (energy and buff), for anything edible
    $foodH = '';
    if (!empty($i['edible']) && ($ft = item_food_line((string)($i['effects'] ?? ''), null, false)) !== '') $foodH = '<p class="sfood">' . e($ft) . '</p>';
    return '<div class="btile stile itmcell' . (!empty($o['dim']) ? ' dim' : '') . '" data-cat="' . shop_cat_of((string)($i['category'] ?? '')) . '" data-id="' . $id . '" data-price="' . $price . '" data-max="' . $max . '" data-name="' . e((string)$i['name']) . '">'
        . $sq
        . '<dialog class="isheet" aria-label="' . e((string)$i['name']) . '"><button type="button" class="sheetx" data-sheetx aria-label="Close">✕</button>'
        . '<div class="shead"><span class="sico" aria-hidden="true">' . ($icon !== '' ? $icon : item_icon($i)) . '</span><b class="sname">' . e((string)$i['name']) . '</b> <span class="rarword r' . $rl . '">' . e($rw) . '</span></div>'
        . ($tags ? '<p class="stags">' . implode(' ', $tags) . '</p>' : '') . $descH . $foodH . $info . $form . '</dialog></div>';
}
