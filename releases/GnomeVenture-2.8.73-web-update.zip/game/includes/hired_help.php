<?php
declare(strict_types=1);
/**
 * Hired help (v0.7.7). A garden with a Tool Shed can hire one NPC helper for 1, 3 or 7 days, paid up front.
 * The helper "visits" every few hours (lazy: worked out when the garden next loads):
 *   water – waters thirsty plants at each visit (growth is replayed visit by visit)
 *   weed  – pulls weeds from no-till beds
 *   harvest – picks ready crops; the owner gets the crop minus the helper's cut, and reduced XP
 */

const HELP_DAYS = [1, 3, 7];
const HELP_SKILLS = ['water' => ['💧', 'waters'], 'weed' => ['🌿', 'weeds'], 'harvest' => ['🧺', 'harvests']];

/** Starting roster: [name, species, icon, skills, wage per day, bio]. Admin can edit or add more. */
const HELPER_ROSTER = [
    ['Pip Dewfoot', 'Snail', '🐌', 'water', 40, 'Slow, steady and never forgets a thirsty plant. Leaves a shiny trail on the path.'],
    ['Hazel Thistledown', 'Hedgehog', '🦔', 'water,weed', 90, 'Snuffles out every weed and eats the slugs while she’s at it.'],
    ['Clover and Moss', 'Wren twins', '🐦', 'water,harvest', 120, 'They argue about everything, but they never drop a tomato.'],
    ['Old Burrow', 'Mole', '🐾', 'water,weed,harvest', 180, 'Has kept gardens since before your grandgnome was a seedling. Takes his pay in crops and stories.'],
];

function ensure_helpers(): int
{
    $added = 0;
    foreach (HELPER_ROSTER as [$name, $species, $icon, $skills, $wage, $bio]) {
        if (q_val('SELECT 1 FROM helpers WHERE name = ?', [$name])) continue;
        db_insert('helpers', ['name' => $name, 'species' => $species, 'icon' => $icon, 'skills' => $skills,
            'wage' => $wage, 'bio' => $bio, 'active' => 1]);
        $added++;
    }
    if (!q_val("SELECT 1 FROM encyclopedia_entries WHERE title = 'Hired help' AND chapter = 'General'")) {
        $eid = db_insert('encyclopedia_entries', ['chapter' => 'General', 'category' => 'Getting started', 'title' => 'Hired help',
            'body' => "Hired helpers have retired. Your Puzzle Pals tend the garden now, while you sleep: see [b]Garden crew and the Hovel[/b].",
            'unlock_key' => 'start', 'hint' => '', 'sort_order' => 3]);
        foreach (q("SELECT DISTINCT ue.user_id FROM user_encyclopedia ue JOIN encyclopedia_entries e ON e.id = ue.entry_id WHERE e.unlock_key = 'start'")->fetchAll(PDO::FETCH_COLUMN) as $uid) {
            db_insert('user_encyclopedia', ['user_id' => $uid, 'entry_id' => $eid, 'unlocked_at' => now()]);
        }
    }
    return $added;
}

function helper_skills(array $h): array
{
    return array_values(array_intersect(array_map('trim', explode(',', (string)$h['skills'])), array_keys(HELP_SKILLS)));
}

/** v0.7.99: every helper staying in this garden (a Tool Shed holds 1, 2 or 3 by its level). */
function current_hires(int $plotId): array
{
    return q('SELECT g.*, h.name, h.species, h.icon, h.skills, h.wage, h.bio FROM garden_hires g JOIN helpers h ON h.id = g.helper_id
              WHERE g.plot_id = ? AND g.active = 1 ORDER BY g.id', [$plotId])->fetchAll();
}

/** v0.7.99: how many helpers this garden's Tool Shed can house: one per shed level. */
function helper_slots(int $plotId): int
{
    return building_level($plotId, 'tool_shed');
}

/** Visit times due since the last visit, up to now and the end of the contract. */
function hire_visits(array $hire): array
{
    $step = max(1, (int)($hire['step_hours'] ?? setting('helper_visit_hours'))) * 3600;   // v2.3.0: a pal on garden duty brings its own step
    $end = min(gclock_hire_now($hire), ts($hire['ends_at']));   // sleep-days: a hired helper keeps the owner's game time
    $out = [];
    for ($v = ts($hire['last_visit']) + $step; $v <= $end && count($out) < 200; $v += $step) $out[] = $v;
    return $out;
}

/** Send a helper home early. Unused whole days are refunded. */
function dismiss_helper(array $u, int $plotId, int $hireId = 0): array
{
    $hire = null;
    foreach (current_hires($plotId) as $hh) if (!$hireId || (int)$hh['id'] === $hireId) $hire = $hh;   // v0.7.99: a chosen helper
    if (!$hire || (int)$hire['user_id'] !== (int)$u['id']) return [false, 'No helper to send home.'];
    $days = max(0, intdiv(ts($hire['ends_at']) - gclock_hire_now($hire), 86400));
    $refund = min((int)$hire['paid'], $days * (int)$hire['wage']);
    db()->beginTransaction();
    if (q('UPDATE garden_hires SET active = 0, ends_at = ? WHERE id = ? AND active = 1', [gmdate('Y-m-d H:i:s', gclock_hire_now($hire)), $hire['id']])->rowCount() === 1 && $refund > 0) {
        q('UPDATE users SET coins = coins + ? WHERE id = ?', [$refund, $u['id']]);
    }
    db()->commit();
    return [true, $hire['name'] . ' heads home.' . ($refund ? ' You get ' . money($refund) . ' back for the unused days.' : '')];
}

/**
 * Called from load_plot for each tile, before normal growth: replay the helper's watering visits.
 * Returns the tile, and counts waterings in $stats.
 */
function helper_water_tile(array $t, ?array $p, array $visits, array &$stats, ?array &$raw = null, bool $virtual = true): array
{
    if (!$p || !$visits) return $t;
    if (gclock_on()) return gclock_helper_water_tile($t, $p, $visits, $stats, $raw, $virtual);
    $lw0 = (string)$t['last_watered'];
    $before = $stats['water'];
    foreach ($visits as $v) {
        if ($v <= (ts($t['growth_updated_at']) ?: ts($t['planted_at']))) continue;   // before planting, or before you last tended it
        $t = tile_grow($t, $p, $v);
        if ((int)$t['growth_seconds'] >= (int)$p['grow_minutes'] * 60) break;   // ready: nothing more to water
        $wetUntil = $t['last_watered'] ? ts($t['last_watered']) + water_seconds($t, $p) : 0;
        if ($wetUntil <= $v) {
            $t['last_watered'] = gmdate('Y-m-d H:i:s', $v);
            $t['growth_updated_at'] = gmdate('Y-m-d H:i:s', $v);
            $stats['water']++;
        }
    }
    $wd = (string)$t['last_watered'] !== $lw0 ? GCLOCK_OWNER_DAY_SQL : 'water_day';   // sleep-days: a helper's watering counts for the owner's current game-day
    $write = fn() => q('UPDATE plot_tiles SET last_watered = ?, growth_seconds = ?, growth_updated_at = ?, water_day = ' . $wd . ' WHERE id = ?',
        [$t['last_watered'], $t['growth_seconds'], $t['growth_updated_at'], $t['id']]);
    if ($raw === null) { $write(); return $t; }
    if (tile_write_guarded($raw, $write)) {   // v2.4.97: only if nobody changed the square since it was read
        $raw = array_merge($raw, ['last_watered' => $t['last_watered'], 'growth_seconds' => $t['growth_seconds'], 'growth_updated_at' => $t['growth_updated_at']]);
        return $t;
    }
    $stats['water'] = $before;   // lost the race: their square stands, so this visit's waterings aren't counted
    return annotate_tile($raw, $p);
}

/** Finish a helper's visits: record them, close an ended contract, and return a "while you were out" line. */
function helper_finish(array $hire, array $visits, array $stats): ?string
{
    if (isset($hire['pj_job'])) return pj_garden_finish($hire, $visits, $stats);   // v2.3.0: a pal tending the garden (pal_jobs.php)
    $last = $visits ? gmdate('Y-m-d H:i:s', end($visits)) : $hire['last_visit'];
    $ended = ts($hire['ends_at']) <= gclock_hire_now($hire);
    q('UPDATE garden_hires SET last_visit = ?, visits = visits + ?, waterings = waterings + ?, weedings = weedings + ?, harvests = harvests + ?, active = ? WHERE id = ?',
        [$last, count($visits), $stats['water'], $stats['weed'], $stats['harvest'], $ended ? 0 : 1, $hire['id']]);
    $did = [];
    if ($stats['water']) $did[] = 'watered ' . $stats['water'] . ' time' . ($stats['water'] > 1 ? 's' : '');
    if ($stats['weed']) $did[] = 'weeded ' . $stats['weed'] . ' bed' . ($stats['weed'] > 1 ? 's' : '');
    if ($stats['harvest']) $did[] = 'harvested ' . $stats['harvest'] . ' crop' . ($stats['harvest'] > 1 ? 's' : '');
    if (!$did && !$ended) return null;
    return $hire['icon'] . ' ' . $hire['name'] . ($did ? ' ' . implode(', ', $did) . ' while you were out.' : '')
        . ($ended ? ($did ? ' Their stay is over and they’ve gone home.' : ' has finished their stay and gone home.') : '');
}
