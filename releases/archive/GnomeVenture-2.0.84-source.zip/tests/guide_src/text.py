"""Text of the Gnome Venture style guide. Edit here, then run: python3 tests/build_guide.py
Markup (tiny): '## h2', '### h3', '- bullet', '1. step', '> note', '| a | b |' tables (2nd line = separator), ``` code ```,
**bold**, `code`. A line holding only {{NAME}} or {{NAME:arg}} is filled in by build_guide.py (palette, catalogue, screenshots ...).
SECTIONS = (id, part, title, body). part: 'front', 'a', 'b', 'c', 'd', 'e'."""

ABOUT = """
This is the one reference for how Gnome Venture looks: the Hearthlight art style, the inline icon system, and the UI style sheet.
It is **rebuilt from the real files**, so the icon pages and colour tables are never out of date.

## How to read it
- **Part A**: the art rules for every picture (placeholders, creatures, folk, nav).
- **Part B**: inline icons (`ico-*`): how emoji are swapped for our own drawings, and how to add one.
- **Part C**: the UI style sheet: colours, type, spacing, components, and Joshua’s UI rules.
- **Part D**: Aseprite pixel art (Stitched Toy): the signature, canvas sizes, the 1 px black border, palettes, the trek map tiles, the Aseprite workflow and a per-asset checklist.

## Rebuild it
```
python3 tests/build_guide.py
```
Output: `game/assets/guides/Gnome-Venture-Style-Guide.pdf`. Download it in Admin, Images & art, Art & style guide.
Run it whenever an icon, a colour token or a rule changes. Text lives in `tests/guide_src/text.py`; layout in `guide.css`; component demos in `components.html`.

## Where the facts come from
{{SOURCES}}
"""

A1 = """
> **PNG art (v2.0.34):** the Aseprite PNGs of these pictures have **no cream halo**; they carry a 1 px black border instead (Part D). This part describes the SVG files, which still ship as the fallback and keep the halo and the layers below.

Hearthlight is the house style of every placeholder picture, creature, folk portrait, nav icon and inline icon. One look, three layers, drawn on a **64 x 64 grid**. All widths below are in grid units **u** (u = shorter side / 64; so 1 u = 1 px at 64 px). Pen weights below are for large stickers (pictures, creatures, portraits). **Icons (`ico-` names) use heavier pens**: see the icon rules.

*Note: these rules are written from `tests/hearth.py`, `hearth_all.py` and `claude/handoff.md`. Text source for this PDF and for `claude/art-style-guide.md` is this file; no older hand-written guide was found.*

## The three layers
1. **Cream halo**: a thick sticker edge round the whole silhouette, `#f2e4c0`, 3.2 u out from the shape (stroke 6.4) on large stickers; icons use 6.0 u. It lifts the picture off dark and light pages alike.
2. **Umber line**: a warm near-black outline, `#2a1a10`, 1.9 u out from the shape (stroke 3.8) on large stickers; icons use 3.4 u. Never pure black.
3. **Cel shade**: one crescent at the lower right, clipped to the silhouette, in a dark tint of the picture’s main colour, opacity .34. One light direction for every picture.

{{LAYERS}}

## Small rules
- Eyes: umber pupil (at least 1.25 u radius) on a cream disc, with a small cream glint on big pupils. A dark eye on a dark fill gets a cream disc and a ring so it reads.
- Inner contour: 1.0 u umber line at 55% opacity between big shapes. Dropped first when a file runs over its size cap.
- Wood and shafts keep body: no wooden line thinner than 6.6 u wide.
- Hairlines (legs, feelers, whiskers) snap to 1 or 1.5 u. Under 1 u they vanish at 16 px.
- Folk portraits (`npc-*`) use 60% halo and outline, because the portrait frame crops them.
- Nav icons (24 px) use whole-number coordinates, and rounded corners under 3 u are dropped.
- Ground shadow: umber at 42% opacity, an ellipse under standing things. Inline icons have none.

## Palette
Every picture starts from the shared art palette (`assets/img/ph/palette.json`). The restyle then nudges a few cold steps warmer (table below). Shade = the next darker step of the same family.
{{PALETTE}}

### Warmth nudges (old to new)
{{REMAP}}

### Shade tints
The cel crescent is not black. It takes the tint of the picture’s dominant hue.
{{TINT}}
"""

A2 = """
## Specimens
Existing Hearthlight pictures from `assets/img/ph/`, shown at 96 px.
{{SPECIMEN}}

## Size caps
Every SVG has a byte budget. The restyle walks down a **trim ladder** until a file fits.
{{CAPS}}

### Trim ladder (richest first)
1. Full: rim light, ambient shade, glint, inner contour, material marks.
2. No rim / AO / glint.
3. Also no inner contour.
4. Also no material marks.
5. Capsule silhouettes: ellipses become round-cap strokes, small corner radii vanish.
6. Capsules, no inner contour.
7. Capsules, no inner contour, no marks.

## Checks every file must pass
- No `<script>`, `<style>`, `style=`, filters, gradients, `xlink`, `href`, `<image>`, `<foreignObject>`, `<use>` or `on*=` handlers.
- `viewBox` unchanged by the restyle.
- Every `clipPath` id is unique (`hl-<name>`), so two icons on one page never clash.
- Rendered at 64 px, the halo must **not touch the 1 px frame** and the picture must fill at least 3% of it. Scenes, tiles, fences and `npc-*` busts are exempt (they bleed by design).
- Names: lowercase, hyphens. Prefixes mean something: `creature-`, `npc-`, `nav-`, `banner-`, `land-`, `guide-`, `tile-`.

## New or changed pictures
1. Draw plain SVG (no effects) in the game palette.
2. Restyle **last**: `PYTHONHASHSEED=1 python3 -B tests/hearth_all.py game/assets/img/ph <out>`
3. Check edges: `python3 -B tests/hearth_edge.py <out>` (0 flagged).
4. Copy `<out>/*.svg` over `game/assets/img/ph/`. Never copy `palette.json`.
5. **Never** re-run `gen_ph_*.py` over restyled files. It would undo the style.

## Known weak spots
Ember beetle eyes are hard to read. Nav festival, friends, villagers and arranging mush together at 24 px. Nav account has low contrast on dark.
"""

B1 = """
Inline icons replace emoji **inside page text** with our own Hearthlight drawings. Same look everywhere, no phone-to-phone emoji differences.

## How the swap works
- It happens at **render time**. `includes/emoji_icons.php` runs as the page’s output buffer (`ico_start()` in bootstrap) and swaps emoji for `<img class="ico">`.
- The map is `includes/data/ico_map.php`: emoji to slug, decorative flag, accessible name. Keys have no U+FE0F.
- Files live in `assets/img/ico/{slug}.svg`. **No file = the emoji stays.** So a map row can be added before the art.
- Longest match wins (a flag or family sequence beats its first emoji).
- Only text nodes are swapped. Never attributes, `<option>`, `<title>`, `<select>`, `<textarea>`, `<script>`, `<style>`, `<svg>`, `<noscript>`.
- JSON, CSV, XML, redirects and downloads are skipped. Setting `ico_swap` (default on) turns it off.
- The icon is an `<img>`: copy and paste of the page gives nothing for it.

## Player text keeps its emoji
Anything a player typed must print with **`eu()`** (emoji become `&#x..;` and the swap skips them): garden names, critter names, trade and job notes, carving titles, feedback, report details.

## Known limits
Emoji inside JS-built strings, attributes, `<option>`, `<title>` and SVG text stay emoji. Player names or notes copied into notices or flash messages (stored as plain text) can get swapped.

## Decorative or named?
- **Decorative** (most): `alt=""`. The words next to it carry the meaning.
- **Named**: the icon stands alone (energy, Petals, locked, done). Give it an accessible name in the map row.
"""

B2 = """
## The grid
Every icon is a **64 x 64** `viewBox` and is drawn as a plain silhouette first. Keep shapes chunky: it must read at **16 px**.
- Keep the artwork at least **6.5 u** away from the frame. The halo (6.0 u for icons) plus anti-alias must stay inside.
- One clear shape, 2 or 3 colours from the palette, one crescent of shade. No fine detail under 1 u.
- Pen weights for icons (the restyle adds them; `ICO_HALO` / `ICO_OUT` in `tests/hearth.py`): **halo 6.0 u, outline 3.4 u**, so the cream ring sits 2.6 u beyond the outline. Large stickers keep 3.2 / 1.9. Icons are drawn as plain shapes: the build adds the pens. (These are the SVG pens; the PNG icons have no halo, see Part D.)
- Size cap: 4096 bytes per icon. Typical is 1.5 to 3.5 KB.

## Sizes in the game
Icons are sized in **em**, so they follow the text they sit in. At body size that is 16 to 18 px. Allowed range inline: **16 to 24 px**. Bigger art (48 px and up) is not an inline icon: use a placeholder picture.
{{ICOCSS}}

## Seen at size
{{ICOSIZES}}

## Rules for placing icons
- Icon first, then words. Never an icon alone unless it has an accessible name.
- One icon per label. Do not stack two.
- Keep the same icon for the same thing everywhere (the map guarantees it).
- Do not recolour with CSS. The icon carries its own colours and halo.
"""

B3 = """
## Add an icon in 5 steps
1. **Draw** plain SVG on the 64 grid in `tests/ico_src/ico-<slug>.svg`. Flat fills from the palette. No gradients, text or filters.
2. **Map**: add one row to `includes/data/ico_map.php`:
```
'🐝' => ['ico-bee', true],
'⚡' => ['ico-energy', false, 'Energy'],
```
   The second value is “decorative” (true = no spoken name). Use false and a name when the icon stands alone.
3. **Restyle**: `PYTHONHASHSEED=1 python3 tests/ico_build.py restyle`. This writes `assets/img/ico/ico-<slug>.svg`. Never edit that folder by hand.
4. **Check**: `python3 -B tests/hearth_edge.py game/assets/img/ico` (0 flagged) and `php tests/emoji_icons.php game`.
5. **Regenerate this guide**: `python3 tests/build_guide.py`, then upload `assets/guides/` with the release.

## Naming
- Files: `ico-<slug>.svg`, lowercase, hyphens: `ico-watering-can.svg`.
- Name the **thing**, not the emoji: `ico-gnome-hat`, not `ico-pointy-hat-face`.
- One slug can serve several emoji (variants). Do not make near-duplicates.
- Prefixes `creature-`, `npc-`, `nav-` are for pictures, not inline icons.

## Do and don’t
{{DODONT:icons}}
"""

B4 = """
Everything in `assets/img/ico/`, read when this guide was built. Each card: the icon name, the emoji it replaces (from `ico_map.php`), then the icon at **48, 24 and 16 px** on a dark chip (the game’s dark surface) and a light chip.
{{CATSTATS}}
{{CATALOG}}
{{UNMAPPED}}
"""

C1 = """
All colours are **tokens** in `assets/style.css`, section 1 (`:root`). Components never hard-code a colour; dark mode only changes the tokens. Dark is the default. Dark overrides are always written `:root[data-theme="dark"] X`, never `@media (prefers-color-scheme)`.

Since v2.0.32 (**Stitched Toy chrome**) every token is a colour from the art palette (Part A families, the Part D table, or the Part D hue-shift recipe, marked in a CSS comment): cream and umber felt, moss for the main verb, gold thread for stitches. No pure black or white. The header, phone bottom bar and footer are umber felt (`--felt`) in both themes.

{{TOKENS}}

## Area hues
Each part of the game tints its pages through `--area*` tokens set by `body[data-area]`.
{{AREAS}}
"""

C2 = """
## Type
System font stack, no web fonts: `system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif`. Body is 16 px on phones and 15 px from 721 px up.
{{TYPE}}

## Space, shape, touch
{{SPACING}}

## Pixel frames (v2.0.32)
- No `border-radius` and no blurred shadows. A panel is framed with `box-shadow: var(--frame)`: 2 px edges, lighter on the lit upper-left (`--edge-lt`), darker lower-right (`--edge-dk`), a 2 px stepped `--drop`, notched corners. Rows inside a panel use `--frame-lite`.
- Frames take no layout space: give framed things about 4 px of room inside scrolling boxes.
- Buttons are felt toys: variants only set `--b-bg --b-hi --b-lo --b-ink --b-hover`. Margins are vertical only, so full-width buttons never overflow.
- Stitches are hard-stop stripes, 4 px on / 2 px off: `--hem` on felt, `--st-h` / `--st-v` for the edge stitch on special cards (prize, event, landing hero). Ordinary boxes stay unstitched.
- Pixel images use `.pix` (`image-rendering: pixelated`) at whole-number scales only. UI tiles live in `assets/img/ui/` (made by `tests/gen_ui_chrome.lua`, written at 2x).

## Breakpoints
- **Phone first**: design for about 412 px wide, dark. Base CSS is the phone.
- **721 px and up**: tablet and desktop. Gutter 24 px, header 60 px.
- **1200 px and up**: groups in the menu stay open (`.navfixed`), two-column tiles. Content never exceeds 1392 px.
- No sideways scroll at any width. Wide things wrap, fold or scroll *inside* their own box.
"""

C3 = """
Real markup and the real `style.css`, captured at build time. Each pair: dark (default) on the left, light on the right. Since v2.0.32 they show the Stitched Toy frames.
{{SHOTS}}
"""

C4 = """
These come straight from Joshua. They are checked on every screenshot before a release.

## The rules
1. **Centre things**: text, headings, cards, buttons, result lines. Check every screenshot for it.
2. **No sideways scrolling.** Ever.
3. **Phone first.** About 412 px, dark theme. Desktop is the same design with more room.
4. **Fold explanations.** Rules, hints and long text hide inside `details.fold`.
5. **Few words.** Short labels, short lines. If it needs a paragraph, fold it.
6. **Solid buttons only for the main verb.** Everything else is `ghost`.
7. **No lone full-width button** inside a wide desktop card.
8. **Equal tile grids** for action buttons. Rows of choices use `choice_row()`.
9. **Many-option filters** are a `<select>` in a GET form (`data-autosubmit`), not a wall of chips.
10. Keep the top bar slim.

## Build rules
- CSP is `style-src 'self'`: **no inline styles**. All CSS in `assets/style.css` (new work in the marked block at the end).
- Popups are `<dialog>` with `gvOpenDlg` / `gvCloseDlg`. Confirmations use `data-confirm` or `gvAsk`. Never `alert()` or `confirm()`. Never lock body scroll.
- Tap targets are at least 44 px (`--tap`). Small buttons are 36 px with a bigger hit area.
- In-place page loads need the page in `AJAX_PAGES`.
- Art falls back in order: real art, flower art, placeholder (`assets/img/ph/`), emoji.

## Do and don’t
{{DODONT:ui}}
"""

C5 = """
## Before you ship UI
- Look at it on a 390 px dark screenshot. Then light. Then 1200 px.
- Is everything centred? Any sideways scroll? Any wall of text that should be a fold?
- Is there more than one solid button in a card?
- Did new text use an emoji? Use an icon (or a plain word) instead. Player text goes through `eu()`.
- Run `php -l`, the suites in `claude/handoff.md`, then rebuild this guide.

## Keep the guide current
- Icons changed? Run `python3 tests/build_guide.py`.
- New component class or token? Add a demo to `tests/guide_src/components.html` and a line in `text.py`.
- New rule from Joshua? Add it to section C4 and to the do / don’t lists.
- Commit the new PDF with the release so Admin can serve it.
"""

D1 = """
**Stitched Toy** is the Aseprite (pixel) version of Hearthlight. It draws every sticker, icon, bust, scene and map tile as **hard-pixel art** that looks like a hand-stitched felt toy with enamel gloss. The game loads the PNG first and falls back to the SVG (`ph`, `ico`, `animals`, `landing`, `stops`, `gather`). Where Part D and Part A disagree, **Part D wins for pixel art**. Part A still rules palette families, names and the 64 grid.

> Since v2.0.34 stickers, icons and busts have **no cream halo**. They get a 1 px black border instead (see “Outline and border”). The Part A pages describe the SVG files, which still ship as the fallback and keep their halo.

## The signature
- **Hard pixels only**: no anti-aliasing, no blends, no gradients, no dither. Every pixel is a solid palette colour or fully transparent.
- **Hue-shifted ramps**: shadows go warmer and deeper, lights go yellow-orange. Never just darken.
- **Stitched seam**: dashed thread gold `#f5cf6a`, 2 px on and 1 px off, wherever there is a real join (back seam, lid, hem).
- **Edge stitch**: a 1 px dashed gold ring just inside the body edge, about every third diagonal pixel.
- **Button**: a 4 x 4 cut-corner gold disc with a darker lower right and two thread holes, at the head of a seam. It must still read at 32 px.
- **Enamel gloss**: a short comma on the lit upper left (`#ff9158`, dot `#ffc27a`). Spots get a 1 px glint so they look glazed.
- **Eyes (locked, never redesign)**: 5 x 5 cream `#f2e4c0` disc with cut corners, 3 x 3 umber `#2a1a10` pupil, 1 px cream glint on the pupil’s upper-left pixel. Set wide on the head. No blush patches.
- **Shape language**: chibi, big head (about 5/6 of the body width), 2 px bent limbs in lavender `#54447f` with a lit top `#7b66b4`, 4 x 4 club tips on antennae, diamond or bean markings.

## Canvas sizes
| Kind | Canvas | Notes |
| --- | --- | --- |
| Sticker, icon (`ico-*`) | 64 x 64 | At least 3 px clear before the border. Icons use chunky shapes, parts 3 px or wider |
| Bust (`npc-*`) | 80 x 100 | May run off the bottom edge (no border there). Eyes scale down only if the head is under 20 px wide |
| Map stops, small art | 32 to 48 | Scale pixel numbers by k = shorter side / 64, rounded. Outline stays 2 px, stitches and glints 1 px |
| Scenes, banners, landing | about 100 px short side, written at 2x | Do NOT scale the outline up. Nearest-neighbour 2x keeps line weights in proportion |
| Trek map tiles | 42 x 42 (sheets 84 x 126) | No border, see Trek map tiles |

## Outline and border
- **No cream halo** (changed 2026-10-22). Everything outside the art is transparent.
- **Last step, 1 px black border**: every transparent pixel **4-adjacent** (plus-shaped, no diagonals) to a non-transparent pixel becomes opaque `#000000`. It goes round the outside and round interior holes. Enclosed cream pockets under 8 px (eyes, glints) are kept. Applies to **stickers, icons and busts**. **Scenes, banners, landing art and map tiles get no border.**
- **Umber outline under the border**: 2 px grown from the silhouette, plus 1 extra px on the lower right (where `s = (x - cx) + (y - cy)` is above 12). Never pure black.
- **Selective by light**: `s < -18` is `#74462a`, `s < -2` is `#4a2c1a`, everything else `#2a1a10`. A pale subject (dust, hair, paper, bone) gets an inside outline of `#4a2c1a` on all sides.
- **Inner contour**: 1 px `#2a1a10` where one big shape overlaps another.
- **Shading**: one crescent at the lower right, a 1 px bounce line inside its edge, a 1 px rim on the upper left, a 1 px contact shadow under an overlapping part. One light direction everywhere.
- Scenes and map objects keep the three-tone outline on raised objects, one crescent per object, and stepped bands (about 5) instead of gradients.

## Palette
{{PIXPAL}}
For other colours use the **ramp recipe**, starting from the Part A family colour as base: gloss = toward yellow-orange and about 35% lighter; shade = toward red-violet and about 22% darker; deep = further toward violet and about 45% darker; bounce = shade warmed and 8% lighter; rim = gloss 10% darker. Example: moss `#4f9a45` gives shade `#2f6a3a`, deep `#1f3f3a`. Pale subjects use the cream-safe set: gloss `#fff3c8`, dot `#ffffff`, rim `#f5b860`. Never use `#000000` or `#ffffff` except the border and one white dot on a pale subject.
"""

D2 = """
Real files from `game/assets/img`, drawn at whole-number scales with nearest-neighbour. Each strip is shown on a light and a dark chip so the black border is checked on both page themes.

## Stickers, icons and animals
{{PIXSAMPLES}}

## Trek map tiles
The trek map is drawn from **46 hand-made tiles** in `assets/img/trek/`. Set `TK_PIXEL_TILES` false (before `includes/trek_art.php` loads) for the old code-drawn map. `TK_PIXEL_ME` (default false) swaps the player’s own gnome for the pixel `trek-me` marker. Tiles have **no halo and no border**; one shared palette serves open and underground.
{{TREKSAMPLES}}

| Group | Tiles |
| --- | --- |
| Open ground (10) | `floor-o-1..3`, `mud-o-1..2`, `roots-o-1..2`, `blight-o-1..2`, `crystal-o` |
| Underground (7) | `floor-u-1..3`, `mud-u`, `roots-u`, `blight-u`, `crystal-u` |
| Water and clay (7) | `chasm-1..2`, `drained`, `clay-wet`, `clay-loose`, overlays `ripple-pool`, `ripple-high` |
| Auto-join and walls (9) | sheets `wall-o-auto`, `wall-u-auto`, `water-auto` (84 x 126); `wall-o-deep`, `wall-u-deep` (42 x 42); caps `wallcap-n/s` (42 x 5), `wallcap-e/w` (5 x 42) |
| Bridge and rails (6) | `bridge-h`, `bridge-v`; rails `rail-n/s` (42 x 4), `rail-e/w` (4 x 42) |
| Markers (7) | `token-gold`, `token-ember` (34), `me` (38 x 40), `foot-h`, `foot-v` (12), `bang` (24), `flag` (20) |

All files are `trek-<name>.png`. Ground tiles are 42 x 42, opaque and full-bleed.

### Seamless rules
- The outer **3 px ring** of a ground tile is exactly the terrain’s ring colour (table below). Variants of one terrain (`floor-o-1..3`, `mud-o-1..2` ...) swap with no seam.
- Details stay at least 3 px from the edges unless designed to cross. A ground tile has **no crescent**: its texture is lit or flat with 1 px accents.
- Umber outline only on **raised objects** (crystal, planks, rails, stones, wall masses, markers). Ground, water and clay have none.
- Every asset and variant is drawn separately: no flip, rotate or recolour reuse. Alpha is 0 or 255 only. Must read at 42, 35 and 21 px.
- Map-key meaning is kept: ripples = high water, two dots = wet clay, cracks = loose clay, diamond = crystal, tuft = roots, dots = mud or blight.
{{TREKRINGS}}

### Auto-join sheets
`wall-o-auto`, `wall-u-auto` and `water-auto` are **84 x 126**: 4 columns x 6 rows of 21 x 21 quarters (RPG Maker A2 style). The game composes the 47 neighbour combinations from four quarters, one per quadrant, chosen by the 8 neighbours:
- both side neighbours are mass: the interior quarter, or the inner-corner quarter if the diagonal is empty;
- one side is mass: the edge quarter on the empty side;
- neither: the outer corner quarter.
Every quarter shares the same skeleton on its four border lines, so any two can sit side by side. On an empty side the first 3 px are the **apron** (the ground ring colour), then a 1 px outline (N `#74462a`, W and E `#4a2c1a`, S `#2a1a10`), a lit rim on N and W or a bounce line on S and E, then the base. The four iso quarters are pixel copies of the sheet’s own corners.

### Trek palette
Six steps per ramp, but one asset normally uses 8 to 14 colours. Gold thread (2 on, 1 off) only at real joins.
{{TREKPAL}}
"""

D3 = """
## Where the source lives
`aseprite-source/` in the repo holds the Lua scripts and `.aseprite` files behind every PNG, the `gvlib` helper library with its brief, and the rule files. Edit a script and rerun it; never retouch a PNG by hand. Keep the `.lua` with the art.

## Build one asset
1. Write a Lua script. Run it in batch mode: `"C:\\Program Files\\Aseprite\\Aseprite.exe" -b --script my.lua` (Aseprite 1.3.18).
2. `local GV = dofile(".../gvlib/gvlib.lua")` then `local c = GV.canvas{ w = 64, h = 64, mode = "sticker" }`.
3. Describe the shapes and colours; `c:build{...}` paints back to front. Parts get the base, crescent, bounce, rim, gloss and contours for free.
4. Add details after the parts: `c:seam`, `c:button`, `c:eye`, `c:spot`, `c:paint`. Draw a part only once.
5. `c:save("x.aseprite", "x.png")` builds the outline, saves both files and returns the check numbers.

| gvlib mode | Canvas | Border | Use |
| --- | --- | --- | --- |
| `sticker` | 64 x 64 | yes | Default: pictures, creatures, items |
| `icon` | 64 x 64 | yes | `ico-*`: chunky parts, longer gloss |
| `bust` | 80 x 100 | yes (not at the bottom edge) | `npc-*` folk portraits |
| `scene` | any, `out=2` for 2x | none | Banners, landing art, backgrounds, stops |

> The shipped art got its black border from a post-pass (`batch.py`). Check whether your copy of `gvlib.lua` still draws the old halo pens before drawing new stickers; if so, add the border pass.

## Check scripts
- `GV.check` (run by `c:save`): size, margin, `semi` (must be 0), colour count, `bw` (pure black or white pixels: 0 unless the border or a pale dot).
- `trek-pixel/check.py`: reads `palette.md` and warns on any opaque pixel not in the palette, and above 16 colours.
- View the PNG at 64, 32 and 16 px (tiles at 42, 35 and 21).

## Checklist for every asset
- Every pixel solid (alpha 0 or 255), no blends, dither or gradients?
- Stickers, icons, busts: 1 px `#000000` border on every outside edge (4-adjacent), no cream halo left? Scenes and tiles: no border?
- 3 px of room inside the frame (64 px canvas) before the border?
- One crescent, the bounce line and the 1 px contact shadow, and no other shade shapes?
- Outline selective by light, never pure black under the border?
- Eyes exactly as locked? Seam, edge stitch and button where the object has a join?
- Only palette colours (Part A, the Part D table, or the ramp recipe)?
- Limbs and shafts at least 2 px; stitches and glints 1 px?
- Readable at 64, 32 and 16 px?
- Name matches the original file name exactly (`<folder>/<name>.png`)? `broken-*` is the intact drawing plus damage; `stage-*` grows one feature per step.
- Avoid: dither bands, blush or cheek patches, zipper or double-wide stitching, blobby markings, shading under 2 px limbs.
"""

E1 = """
Rules for the **scene overhaul** art (stage backdrops, banners, maps, interiors, fight effects, battle sprites). It adds to Part D and never replaces it. Where this page and Part D disagree, this page wins for the files named here. The file list, names and counts are in `claude/art-spec-overhaul.md`.

## Which pieces get the black border
The 1 px `#000000` border is for things that **stand on a scene**. A scene itself has none. The page background and the stage are never bordered.
| Piece | Border | Mode (gvlib) | Notes |
| --- | --- | --- | --- |
| Stage backdrops, banners, maps, interiors | **none** | `scene`, `out = 2` | Three-tone umber outline on raised objects only |
| Stage miniatures (party, crew, enemies, bosses): see Toy miniatures | **yes**, all sides | `sticker` | Transparent outside, border last. Face right. Sit on a round base |
| Villager busts (`npc-*`, `npc-unknown`) | **yes**, not on the bottom edge | `bust` | Stand behind a counter or half-wall so the cut bottom is hidden |
| Fight effects (`fx-*`) | **none** | `scene` | Short-lived, drawn over a scene. 1 px umber contour only where a shape has an edge |
| Region mask (`map-world-regions`) | **none** | raw | Flat colours, no outline, no stitches. Never resized |

## Black border rules (restated for this set)
- Last step only: every transparent pixel **4-adjacent** (plus-shaped) to an opaque pixel becomes `#000000`. Round the outside and round interior holes. No diagonals.
- It is added after the umber outline. The umber outline stays under it (2 px, +1 on the lower right). Never use black for the outline, shading or detail.
- Border is **1 px at any canvas size**. Do not scale it with k. A 96 x 96 boss still gets a 1 px border.
- No cream halo on anything in this set.
- Do not border a sprite twice. Border once, on the final cropped sprite, before saving the PNG.
- Check on a light and a dark chip. If the border vanishes on dark, the umber under it is too dark: lighten the lower-right outline tone one step.
- Pure black `#000000` is allowed **only** for this border. A black pixel anywhere else is a fail.

## Aseprite rules for this set
- **Aseprite 1.3.18**, batch mode, driven by a Lua script that uses `gvlib`. Never retouch a PNG by hand. Keep the `.lua` and `.aseprite` with every PNG in `aseprite-source/final/aseprite/scenes/` (scenes) or the matching existing folder (sprites).
- **Colour mode: RGB**, 8 bits, with a **palette limit** per file (see the table). No indexed-colour tricks that change colours on export.
- **Hard pixels**: alpha is 0 or 255 only. No blur, smooth, outline-by-brush, gradient tool, dither pattern or layer opacity below 100 on the exported result. Layer blend mode: Normal only.
- **Layers** (top to bottom, names exactly): `border` (sprites only), `fx`, `detail`, `objects`, `ground`, `far`, `sky`. Merge nothing before the last step so the file stays editable. Hidden helper layers go in a group named `guide` and are never exported.
- **One frame** per file unless the spec says sheet. Sheets are **horizontal strips**, frames side by side with no gap, no padding, all the same size. Do not use animation tags for the engine; the game reads the strip by frame size.
- **Scenes are drawn small and exported at 2x**: backdrops on a 240 x 135 grid, banners 240 x 60, world map 320 x 180, region maps 240 x 135. Export with **Nearest-neighbour 200%**. This keeps line weights in proportion; do not draw the outline at the exported size.
- **Export**: `File > Export` equivalent in the script, `.png`, no trim, no scale beyond the 2x above, no metadata, 32-bit RGBA. Size must match the spec exactly or the file is rejected.
- **Naming**: lower case, hyphens, exactly the names in the spec. No spaces, no version suffix. Replace a file by overwriting; do not make `-v2`.
- **Transparency**: sprites and effects have a transparent background. Scenes are fully opaque (alpha 255 everywhere).

| File type | Grid drawn | Exported | Max colours | Border |
| --- | --- | --- | --- | --- |
| Stage backdrop | 240 x 135 | 480 x 270 | 32 | none |
| Banner | 240 x 60 | 480 x 120 | 24 | none |
| World map | 320 x 180 | 640 x 360 | 40 | none |
| Region map | 240 x 135 | 480 x 270 | 32 | none |
| Interior | 240 x 135 | 480 x 270 | 32 | none |
| Miniatures | see Toy miniatures | same | see that table | 1 px |
| Bust | 80 x 100 | 80 x 100 | 16 | 1 px, not bottom |
| Fight effect | per spec | per spec | 8 | none |

## Scene composition rules
- **Ground line**: backdrops put the walkable ground between y 190 and 215 (exported pixels). Characters stand with their feet on it. Keep the left and right thirds calm and the centre readable.
- **Depth by bands**: about 5 hard-edged colour bands for sky and haze, then far, mid and near layers. Each farther layer is lighter and less saturated. No gradients, no dither.
- **Raised objects** (trees, rocks, furniture, stalls) get the three-tone umber outline, one crescent, a bounce line and a rim. Ground, water, sky and haze get **no outline**.
- **Light**: always from the upper left. Windows and fires in interiors may add a warm rim, but the crescent stays lower right.
- **Stitched-toy signature in scenes**: a thread-gold hem stitch (2 on, 1 off) along the top and bottom edge of **banners** only. Seams and buttons only on real joins (a quilt, a sack, a banner cloth). Do not stitch terrain.
- **No text, no UI, no characters** in backdrops. Small background life (a bird, a lantern flame) is allowed and must be at least 4 px.
- **Cosy not scary**: even the lair, delve and Trek boss scenes stay warm in value. Danger is shown by shape and colour temperature, never gore or pure dark.
- **Palette**: only Part A families, the Part D table, or the ramp recipe. State which family you borrowed for a new landscape. Day lighting only (night is a code tint).
- **Maps**: draw regions as clearly different colour families so they read at 25 percent size. Leave a flat 24 x 24 spot for each pin (world) or 20 x 20 (region). Roads and mycelium paths 3 px wide minimum.

## Checks before a scene file ships
- Exact size, 32-bit RGBA, alpha 255 everywhere (scenes) or 0/255 only (sprites)?
- Under the colour cap, every colour from the palette rules, `bw` check shows no black except the sprite border?
- Scenes: no border, no halo, no gradient, no dither, no text?
- Sprites: 1 px black border on every outside edge, none on the bottom edge of a bust, facing right, feet on the bottom row?
- Ground line in the 190 to 215 band, side thirds calm?
- Viewed at 100 percent and at 50 percent: the subject still reads?
- Source `.lua` and `.aseprite` saved next to the PNG with the same base name?
"""

E2 = """
Fight and stage characters are drawn as **toy miniatures**: little figurines in a 3/4 view standing on a round base, as if set on a diorama table. This fits Stitched Toy (felt and enamel toys). It is Aseprite-only pixel art: hard pixels, palette ramps, 1 px black border.

## How to build one
**Aseprite only.** No 3D software, no voxel tools, no renders, no AI image tools, no imported images. Every pixel is placed in Aseprite (Lua script with `gvlib`, or by hand in the editor). Fake the 3D by hand: draw the figure in 3/4 view as a small solid with a lit top, a lit left face and a shaded right face. One crescent still falls lower right. A miniature that looks traced from a render or a photo is rejected.

## Camera and pose
- View: 3/4 from above, elevation about 30 degrees, figure turned so it **faces right and slightly toward the viewer**. Same camera for every miniature so they sit together on a stage. Code flips the sprite for the other side.
- Pose: standing idle, weight even, weapon or item held low. One neutral pose per file.
- Optional extra frames only as a horizontal strip: `-idle` (2 frames), `-hit` (1), `-ko` (1, lying or sitting on its base).
- Feet and base sit on the bottom rows. The base counts as part of the figure.

## The base
- A round disc seen as an ellipse, 2/3 of the sprite width, 6 px thick (top face, side face).
- Party bases are felt moss `#4f9a45` ramp with a thread-gold edge stitch. Enemy bases are felt soil or stone ramp with no stitching (they are not ours). Bosses get a wider base with a seam and a button.
- The base replaces the ground-shadow ellipse. No separate shadow.
- Gold stitch rule still applies: thread gold only on joins and base edges.

## Proportions and detail
- Chibi: head about 5/6 of the body width, squat body, **locked eyes** (Part D). On a miniature under 24 px tall the eyes scale to 3 x 3 disc, 2 x 2 pupil.
- Limbs at least 2 px. Accessories (hat, beard, pack, tool) are separate readable shapes.
- Silhouette must read at 32 px. Every enemy has one clear feature (horns, shell, wings) in the outline.
- Shading: 3 value planes (top lit, left mid, right shade) per big shape, plus the one crescent, bounce line and rim. No extra shade shapes, no dither.

## Sizes and counts
| Sprite | Canvas | Max colours | Border |
| --- | --- | --- | --- |
| Gnome, crew, villager (battle) | 64 x 80 | 20 | 1 px, all sides (base is at the bottom, so the bottom gets it too) |
| Small enemy | 56 x 64 | 16 | 1 px |
| Large enemy | 80 x 80 | 20 | 1 px |
| Boss | 112 x 112 | 24 | 1 px |
Existing 64 x 64 creature stickers stay for lists, the Almanac and icons. On the stage the code uses the miniature if the file exists, else the sticker standing on a code-drawn base.
"""

SECTIONS = [
    ('about', 'front', 'About this guide', ABOUT),
    ('a1', 'a', 'Hearthlight: the look', A1),
    ('a2', 'a', 'Limits, checks and new art', A2),
    ('b1', 'b', 'Inline icons: how they work', B1),
    ('b2', 'b', 'Icon size and grid', B2),
    ('b3', 'b', 'Adding an icon', B3),
    ('b4', 'b', 'Icon catalogue', B4),
    ('c1', 'c', 'Colour tokens', C1),
    ('c2', 'c', 'Type, space and breakpoints', C2),
    ('c3', 'c', 'Components', C3),
    ('c4', 'c', 'Joshua’s UI rules', C4),
    ('c5', 'c', 'Checklist and upkeep', C5),
    ('d1', 'd', 'Aseprite: Stitched Toy pixel art', D1),
    ('d2', 'd', 'Pixel samples and trek map tiles', D2),
    ('d3', 'd', 'Aseprite workflow and checklist', D3),
    ('e1', 'e', 'Scene art addendum: Aseprite and black border rules', E1),
    ('e2', 'e', 'Toy miniatures (stage characters)', E2),
]
PARTS = {'front': None, 'a': 'Part A. Hearthlight art', 'b': 'Part B. Inline icons', 'c': 'Part C. UI style sheet', 'd': 'Part D. Aseprite pixel art', 'e': 'Part E. Scene art addendum'}

DODONT = {
  'icons': (
    ['Draw plain SVG on the 64 grid', 'Keep 6.5 u clear of the frame', 'Make it read at 16 px', 'Use palette colours', 'Run the restyle, then the edge check', 'One map row per emoji', 'Give a name to icons that stand alone', 'Print player text with <code>eu()</code>'],
    ['Gradients, text, filters, <code>&lt;style&gt;</code>, scripts', 'Strokes under 1 u', 'Hand-edit files in <code>assets/img/ico/</code>', 'Recolour an icon with CSS', 'Put emoji in new UI text', 'Rely on colour alone for meaning', 'Expect swaps in attributes, options, titles or JS strings', 'Re-run <code>gen_ph_*.py</code> over restyled art'],
  ),
  'ui': (
    ['Centre text, headings, cards, buttons', 'Fold explanations', 'Few words, short lines', 'One solid button per card', 'Tokens for every colour', 'Dark first, then check light', 'Equal tiles for actions', '<code>&lt;dialog&gt;</code> for popups'],
    ['Sideways scroll', 'Inline styles (CSP blocks them)', 'Hard-coded colours', '<code>@media (prefers-color-scheme)</code> for dark', '<code>alert()</code> / <code>confirm()</code>', 'Lone full-width button on desktop', 'Long text walls on the page', 'Emoji in new UI (use an icon)'],
  ),
}
