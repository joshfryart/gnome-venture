<?php
declare(strict_types=1);
/**
 * One-time installer. Creates the database tables, starter content and your admin account,
 * then writes config.php. Once config.php exists this page refuses to run.
 * DELETE THIS FILE from your host after installing.
 */
define('APP_ROOT', __DIR__);
// The version lives only in includes/bootstrap.php (bootstrap exits when config.php is missing, so read the constant from it).
define('APP_VERSION', preg_match("/define\\('APP_VERSION', '([0-9.]+)'\\)/", (string)@file_get_contents(__DIR__ . '/includes/bootstrap.php'), $m_v) ? $m_v[1] : '0');
require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/pixel_art.php';   // v2.0.31: pixel_has() is called by the item seeders (garden100_items etc.)
require __DIR__ . '/includes/seed.php';

send_security_headers();
start_secure_session();

if (is_file(__DIR__ . '/config.php')) {
    http_response_code(403);
    exit('Already installed. For safety, delete install.php from your server.');
}

$errors = [];
$v = [
    'driver' => $_POST['driver'] ?? 'mysql',
    'host' => $_POST['host'] ?? 'localhost',
    'port' => $_POST['port'] ?? '3306',
    'name' => $_POST['name'] ?? '',
    'user' => $_POST['user'] ?? '',
    'site_name' => $_POST['site_name'] ?? 'Gnome Venture',
    'base_url' => $_POST['base_url'] ?? rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/\\'),
    'admin_user' => $_POST['admin_user'] ?? '',
    'admin_email' => $_POST['admin_email'] ?? '',
];

if (is_post()) {
    csrf_check();
    foreach ($v as $k => $val) {
        $v[$k] = is_string($val) ? trim($val) : '';
    }
    $pass = (string)($_POST['admin_pass'] ?? '');
    if (!in_array($v['driver'], ['mysql', 'sqlite'], true)) $errors[] = 'Pick a database type.';
    if (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $v['admin_user'])) $errors[] = 'Admin username: 3–20 letters, numbers or _.';
    if (!filter_var($v['admin_email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Admin email looks wrong.';
    if (strlen($pass) < 12) $errors[] = 'Admin password must be at least 12 characters.';
    if ($pass !== ($_POST['admin_pass2'] ?? '')) $errors[] = 'Admin passwords do not match.';

    if ($v['driver'] === 'sqlite') {
        // Stored relative to the game folder, so the folder can be moved after installing
        $dbConf = ['driver' => 'sqlite', 'path' => 'data/game.sqlite'];
        if (!is_dir(__DIR__ . '/data') || !is_writable(__DIR__ . '/data')) $errors[] = 'The data/ folder must exist and be writable.';
    } else {
        $dbConf = ['driver' => 'mysql', 'host' => $v['host'], 'port' => (int)$v['port'],
            'name' => $v['name'], 'user' => $v['user'], 'pass' => (string)($_POST['pass'] ?? '')];
    }

    if (!$errors) {
        @set_time_limit(900);       // the first import adds thousands of rows: give slow shared hosts time
        @ignore_user_abort(true);   // and keep going even if the browser gives up waiting
        try {
            $GLOBALS['CONFIG'] = ['db' => $dbConf, 'base_url' => $v['base_url']];
            db();
        } catch (Throwable $e) {
            $errors[] = 'Could not connect to the database: ' . $e->getMessage();
        }
    }

    if (!$errors) {
        try {
            db_migrate(db(), $dbConf['driver']);
            if ((int)q_val('SELECT COUNT(*) FROM users') > 0) {
                throw new RuntimeException('This database already has players in it. Use an empty database.');
            }
            db()->beginTransaction();
            foreach (settings_schema() as $k => $def) {
                set_setting($k, (string)$def['default']);
            }
            set_setting('site_name', $v['site_name'] ?: 'Gnome Venture');
            // Links in emails: the address used to install (the admin can change it in Game settings)
            $host = preg_replace('/[^A-Za-z0-9.:\-\[\]]/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
            set_setting('site_url', ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://') . $host);
            if ($dbConf['driver'] === 'sqlite') set_setting('mail_mode', 'log');   // a PC can't send email: write it to the mail log
            set_setting('db_version', APP_VERSION);
            setting('__reload__');
            seed_starter_content();
            $uid = db_insert('users', [
                'username' => $v['admin_user'], 'email' => strtolower($v['admin_email']),
                'password_hash' => password_hash($pass, PASSWORD_DEFAULT), 'role' => 'admin',
                'coins' => (int)setting('starting_coins'), 'created_at' => now(), 'onboarded' => 0,
            ]);
            // The admin creates their gnome and first garden in the welcome flow, like every player.
            db()->commit();

            $config = [
                'db' => $dbConf,
                'base_url' => $v['base_url'],
                'debug' => false,
            ];
            $php = "<?php\n// Generated by install.php. Keep this file private.\nreturn " . var_export($config, true) . ";\n";
            if (file_put_contents(__DIR__ . '/config.php', $php, LOCK_EX) === false) {
                throw new RuntimeException('Could not write config.php. Make the site folder writable, or create config.php by hand with this content:' . "\n\n" . $php);
            }
            @chmod(__DIR__ . '/config.php', 0640);
            $done = true;
        } catch (Throwable $e) {
            if (db()->inTransaction()) db()->rollBack();
            $errors[] = $e->getMessage();
        }
    }
}
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Install</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="game"><header class="banner"><span class="logo">Garden game installer</span></header>
<div class="wrap"><main class="narrowmain">
<?php if (!empty($done)): ?>
  <div class="box"><h2>All planted! 🌱</h2>
  <p>Your game is installed and your admin account is ready.</p>
  <p><strong>Now delete <code>install.php</code> from your server.</strong></p>
  <p><a class="btn" href="login.php">Log in</a></p></div>
<?php else: ?>
  <?php foreach ($errors as $err): ?><div class="flash err"><?= nl2br(e($err)) ?></div><?php endforeach; ?>
  <form method="post" class="box form">
    <?= csrf_field() ?>
    <h2>1. Database</h2>
    <label>Type
      <select name="driver">
        <option value="mysql" <?= $v['driver'] === 'mysql' ? 'selected' : '' ?>>MySQL / MariaDB (your web host)</option>
        <option value="sqlite" <?= $v['driver'] === 'sqlite' ? 'selected' : '' ?>>SQLite (testing on your own computer)</option>
      </select></label>
    <p class="help">For MySQL, create an empty database in your host's control panel first, then copy its details here.</p>
    <label>Host <input name="host" value="<?= e($v['host']) ?>"></label>
    <label>Port <input name="port" value="<?= e($v['port']) ?>"></label>
    <label>Database name <input name="name" value="<?= e($v['name']) ?>"></label>
    <label>Database user <input name="user" value="<?= e($v['user']) ?>" autocomplete="off"></label>
    <label>Database password <input type="password" name="pass" autocomplete="off"></label>
    <h2>2. Your game</h2>
    <label>Game name <input name="site_name" value="<?= e($v['site_name']) ?>"></label>
    <label>Web folder (leave as-is unless you know otherwise) <input name="base_url" value="<?= e($v['base_url']) ?>"></label>
    <h2>3. Your admin account</h2>
    <label>Username <input name="admin_user" value="<?= e($v['admin_user']) ?>" required></label>
    <label>Email <input type="email" name="admin_email" value="<?= e($v['admin_email']) ?>" required></label>
    <label>Password (12+ characters) <input type="password" name="admin_pass" required minlength="12"></label>
    <label>Password again <input type="password" name="admin_pass2" required minlength="12"></label>
    <button class="btn">Install</button>
  </form>
<?php endif; ?>
</main></div></body></html>
