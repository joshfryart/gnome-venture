<?php
declare(strict_types=1);
/**
 * v2.6.40: Garden crew. Every garden has five pal slots (Water, Weed, Pests, Harvest, Plant). A pal in a slot works while the gnome SLEEPS:
 * game_new_day() calls pcrew_night() once per sleep, in a fixed order: pests, weeds, harvest, plant, water. Time modes: 'timed' (1/3/7 sleeps,
 * counted from the next sleep) or 'full' (until called home). A pal sent home rests one game day (garden_pal_rest) and cannot be assigned until the next sleep.
 * What happened is saved per sleep in sleep_report (the Hovel shows it). Design + mockups: claude/todo.md (2026-11-10), pal_garden_mockups.html.
 * Growth is lazy (gclock_tile_grow settles whole days from water_day), so each tile is settled to the day that just ended, worked, then watered FOR that day.
 */
require_once __DIR__ . '/pal_jobs.php';
require_once __DIR__ . '/trade.php';   // notify()

const PCREW_ROLES = [   // key => [icon, label, what it does, open?]
    'water'   => ['💧', 'Water', 'Waters every dry bed so it grows.', true],
    'weed'    => ['🌿', 'Weed', 'Pulls weeds from no-till beds.', true],
    'pests'   => ['🐛', 'Pests', 'Picks pests off the beds.', true],
    'harvest' => ['🧺', 'Harvest', 'Picks every ripe crop into your satchel.', true],
    'plant'   => ['🌰', 'Plant', 'Replants emptied beds with the same seed, or seeds you pick.', true],
];
const PCREW_NIGHTS = [1, 3, 7];
const PCREW_FRESH_NIGHTS = 7;    // full speed for this many nights on the same job
const PCREW_TIRED_NIGHT = 14;    // from this night on the pal wants a change (! and a note)
const PCREW_XP_PCT = 40;      // share of the old Gardening XP a pal earns from crew work
const PCREW_XP_DAILY = 12;    // most Gardening XP one pal earns in one night

/** Make sure the tables exist (an update that has not had "Upgrade database" pressed yet). Safe to call often. */
function pcrew_boot(): void
{
    static $ok = false;
    if ($ok) return;
    try {
        q('SELECT id FROM garden_pal_slots LIMIT 1');
        q('SELECT id FROM garden_pal_rest LIMIT 1');
        q('SELECT id FROM sleep_report LIMIT 1');
        q('SELECT seeds FROM garden_pal_slots LIMIT 1');
        q('SELECT tile_id FROM garden_pal_memory LIMIT 1');
    } catch (Throwable $e) {
        global $CONFIG;
        db_migrate(db(), (string)$CONFIG['db']['driver']);
    }
    $ok = true;
}

function pcrew_open(array $u): bool
{
    return function_exists('ppal_open') && ppal_open() && !is_guest($u) && pj_open($u) && gclock_on();
}

/** The slots of a garden by role. */
function pcrew_slots(int $plotId): array
{
    pcrew_boot();
    $out = [];
    foreach (q('SELECT * FROM garden_pal_slots WHERE plot_id = ?', [$plotId])->fetchAll() as $r) $out[(string)$r['role']] = $r;
    return $out;
}

function pcrew_count(int $uid): int
{
    try { pcrew_boot(); return (int)q_val('SELECT COUNT(*) FROM garden_pal_slots WHERE user_id = ?', [$uid]); } catch (Throwable $e) { return 0; }
}

/** Game day the pal is free again (0 = not resting). */
function pcrew_rest_until(int $uid, string $palUid): int
{
    pcrew_boot();
    return (int)q_val('SELECT until_day FROM garden_pal_rest WHERE user_id = ? AND pal_uid = ?', [$uid, $palUid]);
}

function pcrew_is_resting(int $uid, string $palUid, int $today): bool
{
    return pcrew_rest_until($uid, $palUid) > $today;
}

function pcrew_send_home(int $uid, string $palUid, int $today): void
{
    q("UPDATE ppal_found SET status = 'home' WHERE user_id = ? AND pal_uid = ? AND status = 'crew'", [$uid, $palUid]);
    $until = $today + 1;
    if (q('UPDATE garden_pal_rest SET until_day = ? WHERE user_id = ? AND pal_uid = ?', [$until, $uid, $palUid])->rowCount() < 1) {
        try { db_insert('garden_pal_rest', ['user_id' => $uid, 'pal_uid' => $palUid, 'until_day' => $until]); } catch (Throwable $e) {}
    }
}

/** How well a pal works on night $n (1-based) of the same job: 100% for 7 nights, down to 60% on night 14, then 50%. */
function pcrew_eff(int $n): float
{
    if ($n <= PCREW_FRESH_NIGHTS) return 1.0;
    if ($n >= PCREW_TIRED_NIGHT) return $n === PCREW_TIRED_NIGHT ? 0.6 : 0.5;
    return round(1 - 0.4 * ($n - PCREW_FRESH_NIGHTS) / (PCREW_TIRED_NIGHT - PCREW_FRESH_NIGHTS), 2);
}

/** Is this slot's pal tired of the job (the next night is night 14 or later)? */
function pcrew_tired(array $slot): bool
{
    return ($slot['mode'] ?? '') === 'full' && (int)$slot['done'] + 1 >= PCREW_TIRED_NIGHT;
}

/** Put a pal in a slot. Returns [ok, message]. */
function pcrew_assign(array $u, int $plotId, string $role, string $palUid, string $mode, int $nights, bool $unequip = false, array $seeds = []): array
{
    $uid = (int)$u['id'];
    pcrew_boot();
    if (!pcrew_open($u)) return [false, 'Garden crews open with pal jobs (gnome level ' . pj_min_level() . ').'];
    if (!isset(PCREW_ROLES[$role]) || !PCREW_ROLES[$role][3]) return [false, 'That job is not open yet.'];
    if (!q_val('SELECT 1 FROM plots WHERE id = ? AND user_id = ?', [$plotId, $uid])) return [false, 'That is not your garden.'];
    if ($mode !== 'full' && !in_array($nights, PCREW_NIGHTS, true)) return [false, 'Pick 1, 3 or 7 days, or full time.'];
    $today = (int)$u['game_day'];
    $p = pj_pal($uid, $palUid);
    if (!$p) return [false, 'You have not met that pal.'];
    if (pcrew_is_resting($uid, $palUid, $today)) return [false, $p['name'] . ' is resting at home until you sleep.'];
    if ($p['status'] !== 'home') return [false, $p['name'] . ' is already out.'];
    if ($p['active'] && !$unequip) return [false, $p['name'] . ' is on your party. Tick "Take off my party" to send them out instead.'];
    if (q_val('SELECT 1 FROM garden_pal_slots WHERE plot_id = ? AND role = ?', [$plotId, $role])) return [false, 'That slot already has a pal.'];
    if (!pj_claim_pal($uid, $palUid, 'crew')) return [false, $p['name'] . ' is already out.'];
    try {
        db_insert('garden_pal_slots', ['plot_id' => $plotId, 'user_id' => $uid, 'role' => $role, 'pal_uid' => $palUid, 'mode' => $mode === 'full' ? 'full' : 'timed',
            'nights' => $mode === 'full' ? 0 : $nights, 'done' => 0, 'start_day' => $today, 'created_at' => now(),
            'seeds' => $role === 'plant' ? implode(',', pcrew_clean_seeds((int)$u['id'], $seeds)) : null]);
    } catch (Throwable $e) {
        q("UPDATE ppal_found SET status = 'home' WHERE user_id = ? AND pal_uid = ?", [$uid, $palUid]);
        return [false, 'That slot already has a pal.'];
    }
    $len = $mode === 'full' ? 'full time' : $nights . ' sleep' . ($nights > 1 ? 's' : '');
    return [true, $p['name'] . ' takes the ' . strtolower(PCREW_ROLES[$role][1]) . ' job (' . $len . '). They start working when you sleep.'];
}

/** Call a pal home early. It rests until the next sleep. */
function pcrew_recall(array $u, int $plotId, string $role): array
{
    $uid = (int)$u['id'];
    pcrew_boot();
    $s = q_one('SELECT * FROM garden_pal_slots WHERE plot_id = ? AND user_id = ? AND role = ?', [$plotId, $uid, $role]);
    if (!$s) return [false, 'Nobody is on that job.'];
    q('DELETE FROM garden_pal_slots WHERE id = ?', [$s['id']]);
    pcrew_send_home($uid, (string)$s['pal_uid'], (int)$u['game_day']);
    $p = pj_pal($uid, (string)$s['pal_uid']);
    return [true, ($p['name'] ?? 'Your pal') . ' comes home to rest until you sleep.'];
}

/** The night pass for one gnome, called from game_new_day() after the day has moved on. Never throws. */
function pcrew_night(int $uid): void
{
    try {
        pcrew_boot();
        $slots = q('SELECT * FROM garden_pal_slots WHERE user_id = ? ORDER BY id', [$uid])->fetchAll();
        $owner = q_one('SELECT * FROM users WHERE id = ?', [$uid]);
        if (!$owner) return;
        $D = (int)$owner['game_day'];
        $report = [];
        $byPlot = [];
        foreach ($slots as $s) $byPlot[(int)$s['plot_id']][(string)$s['role']] = $s;
        foreach ($byPlot as $plotId => $roles) {
            $plot = q_one('SELECT * FROM plots WHERE id = ?', [$plotId]);
            if (!$plot) continue;
            $did = pcrew_work_plot($owner, $plot, $roles, $D);
            foreach ($roles as $role => $s) {
                $pal = pj_pal($uid, (string)$s['pal_uid']);
                $name = $pal['name'] ?? 'A pal';
                $n = $did[$role] ?? 0;
                $first = (int)$s['start_day'] >= $D;   // assigned today before this sleep ran: starts tonight, counted as night 1
                $doneNow = (int)$s['done'] + 1;
                $ended = $s['mode'] === 'timed' && $doneNow >= (int)$s['nights'];
                $xp = $pal && $n > 0 ? min(PCREW_XP_DAILY, (int)ceil($n * PCREW_XP_PCT / 100)) : 0;
                if ($xp > 0) pj_add_xp($uid, (string)$pal['key'], $xp, 0);
                $report[] = ['plot' => (string)($plot['garden_name'] ?: 'Garden'), 'plot_id' => $plotId, 'role' => $role, 'pal' => $name, 'n' => $n, 'text' => (string)($did[$role . '_text'] ?? ''),
                             'mode' => (string)$s['mode'], 'night' => $doneNow, 'nights' => (int)$s['nights'], 'ended' => $ended, 'eff' => (int)round(pcrew_eff($doneNow) * 100), 'tired' => $s['mode'] === 'full' && $doneNow + 1 >= PCREW_TIRED_NIGHT, 'warn' => (string)($did[$role . '_warn'] ?? '')];
                if ($ended) {
                    q('DELETE FROM garden_pal_slots WHERE id = ?', [$s['id']]);
                    pcrew_send_home($uid, (string)$s['pal_uid'], $D);
                } else {
                    q('UPDATE garden_pal_slots SET done = ?, last_day = ? WHERE id = ?', [$doneNow, $D, $s['id']]);
                }
            }
        }
        if ($report) {
            pcrew_save_report($uid, $D, ['crew' => $report]);
            $bits = [];
            foreach ($report as $r) if ($r['n'] > 0) $bits[] = $r['text'];
            if (function_exists('notify')) notify($uid, '🧩 Your pals worked the garden: ' . ($bits ? implode(' · ', $bits) : 'nothing needed doing') . '.');
        }
    } catch (Throwable $e) {
        error_log('pcrew_night: ' . $e->getMessage());
        if (db()->inTransaction()) db()->rollBack();
    }
}

/** The tile work of one garden, in order. Returns [role => count, role_text => words, role_warn => problem]. */
function pcrew_work_plot(array $owner, array $plot, array $roles, int $D): array
{
    $uid = (int)$owner['id'];
    $out = ['water' => 0, 'weed' => 0, 'pests' => 0, 'harvest' => 0, 'plant' => 0];
    $names = [];
    foreach ($roles as $role => $s) $names[$role] = (string)(pj_pal($uid, (string)$s['pal_uid'])['name'] ?? 'Your pal');
    $plants = [];
    $planted = [];   // plant name => count, for the report
    $whyNot = [];    // beds left empty => reason
    $stock = [];     // seed item id => held, kept as it drops
    $chosen = isset($roles['plant']) ? array_values(array_filter(array_map('intval', explode(',', (string)($roles['plant']['seeds'] ?? ''))))) : [];
    $eff = [];
    foreach ($roles as $role => $sl) $eff[$role] = pcrew_eff((int)$sl['done'] + 1);
    $works = function (string $role, int $tileId) use ($roles, $eff, $D): bool {   // a tired pal skips some beds, the same ones every time it is asked
        if (!isset($roles[$role])) return false;
        return $eff[$role] >= 1.0 || hollow_unit('crew|' . $role . '|' . $tileId . '|' . $D) < $eff[$role];
    };
    $plantDate = hollow_date_add(hollow_season_epoch(), $D - 1);
    $mem = [];
    foreach (q('SELECT m.* FROM garden_pal_memory m JOIN plot_tiles t ON t.id = m.tile_id WHERE t.plot_id = ?', [$plot['id']])->fetchAll() as $m) $mem[(int)$m['tile_id']] = $m;
    $workOnly = (bool)array_filter($mem, fn($m) => (int)($m['skip'] ?? 0) === 2);   // any bed ticked to work: the Plant pal plants only those
    foreach (q('SELECT * FROM plot_tiles WHERE plot_id = ? ORDER BY y, x', [$plot['id']])->fetchAll() as $raw) {
        $p = null;
        if ($raw['plant_id']) { $pid = (int)$raw['plant_id']; $p = $plants[$pid] ??= q_one('SELECT * FROM plants WHERE id = ?', [$pid]); }
        if ($p && (int)($mem[(int)$raw['id']]['plant_id'] ?? 0) !== (int)$p['id']) { pcrew_remember((int)$raw['id'], (int)$p['id']); $mem[(int)$raw['id']] = ['plant_id' => (int)$p['id'], 'skip' => (int)($mem[(int)$raw['id']]['skip'] ?? 0)]; }   // learn what grows here
        $t = annotate_tile($raw, $p);
        $settled = $D - 1;
        if ($p) {
            // A bed watered by hand (or rained on) for the day that just ended has grown through it: count that day before looking for ripe crops.
            // A dry bed is settled one day less, so the Water pal (water step below) can still water it for that day.
            $wetFx = gfx_on() ? garden_day_fx($t, $p, hollow_date_add(hollow_season_epoch(), $D - 1)) : ['wet' => false];
            if ((string)($t['water_day'] ?? '') === (string)($D - 1) || !empty($wetFx['wet'])) $settled = $D;
            $t = gclock_tile_grow($t, $p, $settled);
            $t = array_merge($t, ['grow_day' => $settled]);
        }
        $touched = false;
        if ($works('pests', (int)$t['id']) && !empty($t['pest'])) { q('UPDATE plot_tiles SET pest = NULL, pest_at = NULL WHERE id = ?', [$t['id']]); $t['pest'] = null; $out['pests']++; }
        if ($works('weed', (int)$t['id']) && ($t['method'] ?? '') === 'notill' && (int)$t['weeds'] > 0) { $t['weeds'] = 0; $out['weed']++; $touched = true; }
        if ($p || $touched) {
            $keep = $t;
            $r2 = $raw;
            tile_write_guarded($r2, fn() => save_growth($keep));   // a lost race just skips this square tonight
        }
        if ($p && $p['kind'] !== 'cover' && $works('harvest', (int)$t['id']) && tile_info($t, $p)['ready']) {
            db()->beginTransaction();
            try {
                do_harvest($owner, $t, $p, $names['harvest'], 0, true);
                db()->commit();
                $out['harvest']++;
            } catch (Throwable $e) {
                if (db()->inTransaction()) db()->rollBack();
            }
        }
        $fresh = q_one('SELECT * FROM plot_tiles WHERE id = ?', [$t['id']]);
        if (!$fresh) continue;
        // plant: an empty, prepared bed gets the same seed back, or one of the ticked seeds
        $hadCrop = (int)($mem[(int)$fresh['id']]['plant_id'] ?? 0) > 0;
        $needTill = (int)$fresh['tilled'] !== 1;   // a harvested bed goes back to bare ground: the pal tills it again, but only a bed that grew something before
        if (!$fresh['plant_id'] && $works('plant', (int)$fresh['id']) && ((int)$fresh['tilled'] === 1 || ($needTill && $hadCrop && ($fresh['method'] ?? '') !== 'notill')) && (int)($mem[(int)$fresh['id']]['skip'] ?? 0) !== 1 && (!$workOnly || (int)($mem[(int)$fresh['id']]['skip'] ?? 0) === 2)
            && ts((string)$fresh['settle_until']) <= gclock_plot_now((int)$plot['id'])) {
            [$sid, $np, $why] = pcrew_pick_seed($owner, $fresh, $mem[(int)$fresh['id']] ?? null, $chosen, $stock, $plantDate);
            if ($np && $needTill) {   // the same effects as the Till action (no tool, no energy)
                $ft = annotate_tile($fresh, null);
                $care = care_points($ft);
                q('UPDATE plot_tiles SET tilled = 1, method = ?, settle_until = NULL, fertility = ?, soil_life = ?, moisture = ?, mulch = 0, weeds = 0, bed_score = 0, maint_at = NULL, checkpoint = 0, neglect_hours = 0, care = ?, care_at = ? WHERE id = ?',
                    ['till', clamp100((int)$fresh['fertility'] + 5), clamp100((int)$fresh['soil_life'] - care_till_damage($ft)), clamp100((int)$fresh['moisture'] - 10), $care, now(), $fresh['id']]);
                $fresh = q_one('SELECT * FROM plot_tiles WHERE id = ?', [$fresh['id']]);
            }
            if ($np && give_item($uid, $sid, -1)) {
                $stock[$sid]--;
                $upd = q('UPDATE plot_tiles SET plant_id = ?, planted_at = ?, growth_seconds = 0, growth_updated_at = ?, last_watered = NULL, water_day = NULL, owed_days = 0, grow_day = ?, harvests = 0, nipped = 0, pest = NULL, pest_at = NULL
                          WHERE id = ? AND plant_id IS NULL', [$np['id'], gclock_maint_now((int)$plot['id']), now(), $D - 1, $fresh['id']])->rowCount();
                if ($upd === 1) {
                    $out['plant']++; $planted[$np['name']] = ($planted[$np['name']] ?? 0) + 1;
                    pcrew_remember((int)$fresh['id'], (int)$np['id']); $mem[(int)$fresh['id']] = ['plant_id' => (int)$np['id'], 'skip' => 0];
                    $plants[(int)$np['id']] = $np;
                } else { give_item($uid, $sid, 1); }
            } elseif ($why !== '') { $whyNot[$why] = ($whyNot[$why] ?? 0) + 1; }
            $fresh = q_one('SELECT * FROM plot_tiles WHERE id = ?', [$t['id']]);
        }
        if (!$fresh || !$fresh['plant_id']) continue;   // nothing growing: nothing to water
        $p = $plants[(int)$fresh['plant_id']] ??= q_one('SELECT * FROM plants WHERE id = ?', [(int)$fresh['plant_id']]);
        if ($p && $works('water', (int)$fresh['id']) && (string)($fresh['water_day'] ?? '') !== (string)($D - 1)) {
            $fx = gfx_on() ? garden_day_fx(annotate_tile($fresh, $p), $p, hollow_date_add(hollow_season_epoch(), $D - 1)) : ['wet' => false];
            if (!empty($fx['wet'])) continue;   // rain did it
            q('UPDATE plot_tiles SET water_day = ?, last_watered = ? WHERE id = ?', [$D - 1, now(), $t['id']]);
            $out['water']++;
        }
    }
    $texts = [];
    if (isset($roles['water'])) $texts['water'] = $names['water'] . ' watered ' . $out['water'] . ' bed' . ($out['water'] === 1 ? '' : 's');
    if (isset($roles['weed'])) $texts['weed'] = $names['weed'] . ' weeded ' . $out['weed'] . ' bed' . ($out['weed'] === 1 ? '' : 's');
    if (isset($roles['pests'])) $texts['pests'] = $names['pests'] . ' cleared pests from ' . $out['pests'] . ' bed' . ($out['pests'] === 1 ? '' : 's');
    if (isset($roles['harvest'])) $texts['harvest'] = $names['harvest'] . ' picked ' . $out['harvest'] . ' crop' . ($out['harvest'] === 1 ? '' : 's');
    if (isset($roles['plant'])) {
        $bits = []; foreach ($planted as $nm => $n) $bits[] = $n . ' ' . strtolower($nm);
        $texts['plant'] = $names['plant'] . ($bits ? ' planted ' . implode(', ', $bits) : ' had nothing to plant');
        if ($whyNot) { $w = []; foreach ($whyNot as $why => $n) $w[] = $n . ' bed' . ($n > 1 ? 's' : '') . ' left empty: ' . $why; $out['plant_warn'] = implode('; ', $w); }
    }
    foreach ($texts as $k => $v) $out[$k . '_text'] = $v;
    return $out;
}

// ---------------------------------------------------------------------------------------------------------------------
// Planting (the Plant slot). Same seed as the bed had before, else the seeds the gnome ticked (a grid of seeds they hold).
// ---------------------------------------------------------------------------------------------------------------------

/** Remember what grows in a bed, so the Plant slot can put the same seed back. Called when anyone plants and by the night pass. */
function pcrew_remember(int $tileId, int $plantId): void
{
    try {
        pcrew_boot();
        if (q('UPDATE garden_pal_memory SET plant_id = ? WHERE tile_id = ?', [$plantId, $tileId])->rowCount() < 1) {
            try { db_insert('garden_pal_memory', ['tile_id' => $tileId, 'plant_id' => $plantId, 'skip' => 0]); } catch (Throwable $e) {}
        }
    } catch (Throwable $e) { error_log('pcrew_remember: ' . $e->getMessage()); }
}

/** Seeds a pal may plant that this gnome holds: [seed item id => [item row, plant row, qty]]. Never treasure seeds or saplings. */
function pcrew_seed_options(int $uid): array
{
    $out = [];
    foreach (q("SELECT i.*, ui.qty FROM user_items ui JOIN items i ON i.id = ui.item_id WHERE ui.user_id = ? AND ui.qty > 0 AND i.category = 'seed' ORDER BY i.name", [$uid])->fetchAll() as $it) {
        if (str_contains(strtolower((string)$it['slug']), 'treasure')) continue;
        $pl = q_one('SELECT * FROM plants WHERE seed_item_id = ?', [$it['id']]);
        if (!$pl || $pl['kind'] === 'cover') continue;
        $out[(int)$it['id']] = ['item' => $it, 'plant' => $pl, 'qty' => (int)$it['qty']];
    }
    return $out;
}

/** The ticked seed ids, keeping only ones a pal may plant (known seed items, no treasure seeds). Held or not: the pick stays when you run out. */
function pcrew_clean_seeds(int $uid, array $ids): array
{
    $keep = [];
    foreach (array_unique(array_map('intval', $ids)) as $id) {
        if ($id < 1) continue;
        $it = q_one("SELECT slug, category FROM items WHERE id = ?", [$id]);
        if (!$it || $it['category'] !== 'seed' || str_contains(strtolower((string)$it['slug']), 'treasure')) continue;
        $pl = q_one('SELECT kind FROM plants WHERE seed_item_id = ?', [$id]);
        if ($pl && $pl['kind'] !== 'cover') $keep[] = $id;
    }
    return array_slice($keep, 0, 24);
}

/** Change the seeds a Plant slot may use. */
function pcrew_set_seeds(array $u, int $plotId, array $ids): array
{
    $uid = (int)$u['id'];
    pcrew_boot();
    $s = q_one("SELECT * FROM garden_pal_slots WHERE plot_id = ? AND user_id = ? AND role = 'plant'", [$plotId, $uid]);
    if (!$s) return [false, 'Nobody is on the Plant job.'];
    $clean = pcrew_clean_seeds($uid, $ids);
    q('UPDATE garden_pal_slots SET seeds = ? WHERE id = ?', [implode(',', $clean), $s['id']]);
    return [true, $clean ? 'The Plant pal will use ' . count($clean) . ' kind' . (count($clean) > 1 ? 's' : '') . ' of seed when a bed has no memory of its own.' : 'The Plant pal will only put back the same seed.'];
}

/** Beds for the Plant pal in one garden: $avoidIds = leave alone (skip 1), $workIds = work only these when any is set (skip 2). Avoid wins a clash. */
function pcrew_set_skip(array $u, int $plotId, array $avoidIds, array $workIds = []): array
{
    $uid = (int)$u['id'];
    pcrew_boot();
    if (!q_val('SELECT 1 FROM plots WHERE id = ? AND user_id = ?', [$plotId, $uid])) return [false, 'That is not your garden.'];
    $mine = array_map('intval', q('SELECT id FROM plot_tiles WHERE plot_id = ?', [$plotId])->fetchAll(PDO::FETCH_COLUMN));
    $avoid = array_values(array_intersect($mine, array_map('intval', $avoidIds)));
    $work = array_values(array_diff(array_intersect($mine, array_map('intval', $workIds)), $avoid));
    foreach ($mine as $tid) {
        $skip = in_array($tid, $avoid, true) ? 1 : (in_array($tid, $work, true) ? 2 : 0);
        if (q('UPDATE garden_pal_memory SET skip = ? WHERE tile_id = ?', [$skip, $tid])->rowCount() < 1 && $skip) {
            try { db_insert('garden_pal_memory', ['tile_id' => $tid, 'plant_id' => 0, 'skip' => $skip]); } catch (Throwable $e) {}
        }
    }
    $m = [];
    if ($work) $m[] = count($work) . ' bed' . (count($work) > 1 ? 's' : '') . ' to work (only these are planted)';
    if ($avoid) $m[] = count($avoid) . ' bed' . (count($avoid) > 1 ? 's' : '') . ' left alone';
    return [true, $m ? 'Plant pal: ' . implode(', ', $m) . '.' : 'The Plant pal works every bed again.'];
}

/** Pick the seed for one empty bed: [item id, plant row, why-not text]. */
function pcrew_pick_seed(array $owner, array $tile, ?array $mem, array $chosen, array &$stock, string $date): array
{
    $uid = (int)$owner['id'];
    $try = [];
    if ($mem && (int)$mem['plant_id'] > 0) { $pl = q_one('SELECT * FROM plants WHERE id = ?', [(int)$mem['plant_id']]); if ($pl && $pl['kind'] !== 'cover') $try[] = [(int)$pl['seed_item_id'], $pl, true]; }
    foreach ($chosen as $sid) { $pl = q_one('SELECT * FROM plants WHERE seed_item_id = ?', [$sid]); if ($pl) $try[] = [(int)$sid, $pl, false]; }
    $why = '';
    foreach ($try as [$sid, $pl, $same]) {
        if (($stock[$sid] ?? null) === null) $stock[$sid] = (int)q_val('SELECT qty FROM user_items WHERE user_id = ? AND item_id = ?', [$uid, $sid]);
        if ($stock[$sid] < 1) { $why = $why ?: 'out of ' . strtolower($pl['name']) . ' seeds'; continue; }
        if (plant_season_state($pl, $date) === 'off') { $why = $why ?: strtolower($pl['name']) . ' is out of season'; continue; }
        if ((int)$tile['fertility'] < (int)$pl['min_soil']) { $why = $why ?: strtolower($pl['name']) . ' needs richer soil'; continue; }
        return [$sid, $pl, ''];
    }
    return [0, null, $why ?: ($chosen ? 'no seed to use' : 'no seed remembered here and none ticked (tick seeds in Seeds and beds)')];
}

function pcrew_save_report(int $uid, int $day, array $data): void
{
    pcrew_boot();
    $cur = q_one('SELECT * FROM sleep_report WHERE user_id = ? AND game_day = ?', [$uid, $day]);
    if ($cur) {
        $body = array_merge(json_decode((string)$cur['body'], true) ?: [], $data);
        q('UPDATE sleep_report SET body = ? WHERE id = ?', [json_encode($body), $cur['id']]);
    } else {
        db_insert('sleep_report', ['user_id' => $uid, 'game_day' => $day, 'body' => json_encode($data), 'created_at' => now()]);
        q('DELETE FROM sleep_report WHERE user_id = ? AND game_day <= ?', [$uid, $day - 3]);   // the last 3 reports are kept
    }
}

/** The latest sleep report [game_day, data] or null. */
function pcrew_latest_report(int $uid): ?array
{
    try {
        pcrew_boot();
        $r = q_one('SELECT * FROM sleep_report WHERE user_id = ? ORDER BY game_day DESC LIMIT 1', [$uid]);
        return $r ? [(int)$r['game_day'], json_decode((string)$r['body'], true) ?: []] : null;
    } catch (Throwable $e) { return null; }
}

/**
 * Hired helpers retire (Josh, 2026-11-10): every active contract ends, unused whole days are refunded, the player is told once. Runs once per site (setting flag).
 */
function pcrew_retire_helpers(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        if (setting('crew_helpers_retired') === '1') return;
        foreach (q('SELECT g.*, h.name, h.wage FROM garden_hires g JOIN helpers h ON h.id = g.helper_id WHERE g.active = 1')->fetchAll() as $hire) {
            $left = max(0, intdiv(ts($hire['ends_at']) - gclock_hire_now($hire), 86400));
            $refund = min((int)$hire['paid'], $left * (int)$hire['wage']);
            if (q('UPDATE garden_hires SET active = 0 WHERE id = ? AND active = 1', [$hire['id']])->rowCount() !== 1) continue;
            if ($refund > 0) q('UPDATE users SET coins = coins + ? WHERE id = ?', [$refund, $hire['user_id']]);
            if (function_exists('notify')) notify((int)$hire['user_id'], '🧰 ' . $hire['name'] . ' has gone home: your pals do the garden work now.' . ($refund > 0 ? ' Unused wages refunded: ' . money($refund) . '.' : ''));
        }
        set_setting('crew_helpers_retired', '1');
    } catch (Throwable $e) { error_log('pcrew_retire_helpers: ' . $e->getMessage()); }
}
