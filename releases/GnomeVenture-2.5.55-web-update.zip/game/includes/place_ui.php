<?php
declare(strict_types=1);
// v2.0.61: shared place UI pieces (World / Town / Stops consolidation, phase 1: moved out of world.php unchanged)

/** v2.0.84: felt card picture for a route's destination: one drawn vignette per place kind (assets/img/town/route-KIND.png), the village's when a kind has none. */
function go_route_art(array $to): string
{
    $dir = __DIR__ . '/../assets/img/town/';
    $k = loc_real_kind($to);
    if (!is_file($dir . 'route-' . $k . '.png')) $k = 'village';
    return is_file($dir . 'route-' . $k . '.png') ? felt_art_img('assets/img/town/route-' . $k . '.png') : '';
}

/** v2.0.84: the danger chip on a route card: green fine for you, amber a bit high, red too high. */
function go_level_chip(int $lvl, int $min, int $max = 0): string
{
    $max = max($min, $max);
    [$cls, $word] = $min <= $lvl ? ['ok', 'fine for you'] : ($min <= $lvl + 4 ? ['warn', 'a bit high'] : ['bad', 'too high']);
    return '<span class="pchip rchip rchip--' . $cls . '" title="Danger level">Lv ' . $min . ($max > $min ? '–' . $max : '') . ' · ' . $word . '</span>';
}

/** The pick-a-place map for the Go tab: the region map opened zoomed in on you (＋ − ⤢ and drag still work), places are tap targets. '' when this region has no map. */
function go_map_html(array $u, array $node, int $goId, string $destHtml = ''): string
{
    $rid = (int)($node['region_id'] ?? 0);
    if (!$rid) return '';
    if (myc_on() && region_art_path($rid) === '') $map = '<div class="mapwrap regionwrap mycwrap">' . myc_region_block($u, $rid, $goId) . '</div>';
    else {
        $svg = region_map_svg($u, $rid, $goId, true);
        $map = $svg === '' ? '' : '<div class="mapwrap regionwrap"><div class="rzoom"><div class="rzctl" hidden><button type="button" class="btn small" data-z="in" aria-label="Zoom in">＋</button><button type="button" class="btn small" data-z="out" aria-label="Zoom out">−</button><button type="button" class="btn small" data-z="fit" aria-label="Whole region">⤢</button></div>' . $svg . '</div></div>';
    }
    if ($map === '') return '';
    return '<section class="box gomap" aria-label="Places near you"><div class="gomaphead"><h3>🗺️ Pick a place</h3><a class="btn small alt" href="' . e(url('world.php?tab=map&r=' . $rid . '#regionmap')) . '">🌍 Full map</a></div>'
        . '<p class="help">Tap a place to see the way there, or pick a card below. ⤢ shows the whole region.</p>' . $map . $destHtml . '</section>';
}

/** Where to next: route cards, Wander, Fast travel, Gather, how-it-works fold. */
function go_panel_html(array $u, array $node, string $here, callable $badge, array $kindIcons, array $GL, bool $onRoad): string
{
    ob_start(); ?>
<?php $routes = visible_routes($u, (int)$node['id']); $lvl = (int)$u['level']; ?>
<div class="box gopanel">
  <h3>🧭 Where to next?</h3>
  <?php $shiftLeft = ts($u['community_shift_until'] ?? null) - time();
  if ($shiftLeft > 0):   // v0.7.48: say so instead of offering walks that would be refused ?>
    <p class="box notice">🧑‍🌾 You’re on a tending shift at the community garden for another <b><?= e(nice_time($shiftLeft)) ?></b>. Finish it, or end it early, before you set off.
      <form method="post" action="<?= e(url('community.php')) ?>" class="inline"><?= csrf_field() ?><input type="hidden" name="do" value="end_shift"><button class="btn small alt">End shift</button></form>
      <a class="btn small" href="<?= e(url('community.php')) ?>">Back to the garden →</a></p>
  <?php elseif ($routes): ?>
    <ul class="rcards">
      <?php foreach ($routes as $r):
          $to = $r['to'];
          $tL = LANDSCAPES[$to['landscape'] ?? ''] ?? null;
          $seen = in_array($to['kind'], ['market', 'hub'], true) || place_known((int)$u['id'], $to);
          [$dMin, $dMax] = route_danger($u, $r);
          $isRoad = ($r['kind'] ?? '') === 'road';
          $kindWord = $to['kind'] === 'market' ? 'Town' : ucfirst(loc_real_kind($to));   // v1.2.2
          $dir = compass_between((int)$node['id'], (int)$to['id']);   // v1.7.6: one short meta line
          $far = $to['kind'] === 'market' && $to['region'] !== $node['region']; ?>
        <li><form method="post" action="<?= e(url('adventure.php')) ?>" class="goform"><?= csrf_field() ?>
          <input type="hidden" name="do" value="start"><input type="hidden" name="route_id" value="<?= (int)$r['id'] ?>">
          <button class="rcard<?= $isRoad ? '' : ' rcard--side' ?>" aria-label="<?= e('Go to ' . $to['name'] . ' (' . $kindWord . ', ' . ($isRoad ? 'road' : 'side path') . ')') ?>">
            <span class="rcard__art"><?= go_route_art($to) ?></span>
            <span class="rcard__ribbon"><span class="rcard__name"><?= e($to['name']) ?></span></span>
            <?php if (!$seen): ?><span class="rcard__flag">new</span><?php endif; ?>
            <span class="rcard__kind"><?= $kindIcons[loc_real_kind($to)] ?? ($tL ? $tL[0] : '📍') ?> <?= e($kindWord) ?> · <?= $isRoad ? '🛣️ road' : '🌿 side path' ?><?= $far ? ' · in ' . e((string)$to['region']) : '' ?></span>
            <span class="rcard__meta">
              <?php if ($dir): ?><span class="pchip">🧭 <?= e($dir) ?></span><?php endif; ?>
              <span class="pchip"><?= (int)$r['steps'] ?> steps</span>
              <span class="pchip">⚡<?= (int)route_energy($u, $r) ?></span>
              <?php if (!empty($r['quick'])): ?><span class="pchip">💨 <?= e(nice_time((int)$r['walk_min'] * 60)) ?></span><?php endif; ?>
              <?= go_level_chip($lvl, $dMin, $dMax) ?>
            </span>
            <span class="rcard__go" aria-hidden="true">Go ›</span>
          </button>
        </form></li>
      <?php endforeach; ?>
    </ul>
  <?php else: ?>
    <p class="muted">No paths lead from here yet.</p>
  <?php endif; ?>
  <div class="gx-actions goextra">
    <?php if (in_array($node['kind'], ['market', 'hub'], true)): ?>
      <a class="gbtn alt" href="<?= e(url('town.php')) ?>" title="<?= e($here . ' town square') ?>">🏘️ Town square</a>
    <?php elseif ($node['kind'] === 'village'): ?>
      <a class="gbtn alt" href="<?= e(url('town.php')) ?>" title="<?= e($node['name'] . ' rest stop') ?>">🪧 Rest stop</a>
    <?php endif; ?>
    <a class="gbtn alt" href="<?= e(url('world.php?tab=travel#fasttravel')) ?>">🧭 Fast travel</a>
    <?php if ($shiftLeft <= 0): // v0.7.97: gathering has its own tab ?>
      <a class="gbtn alt" href="<?= e(url('world.php?tab=gather')) ?>" title="Gather here, or seek something on the Gather tab">🧺 Gather <small><?= $GL[0] ?> <?= e($GL[1]) ?></small></a>
    <?php endif; ?>
  </div>
  <?php if ($next = next_region_suggestion($u)): ?>
    <p class="nextup">🧭 Next: <a href="<?= e(url('world.php?tab=map&r=' . (int)$next['id'] . '#regionmap')) ?>"><b><?= e($next['gnomish_name']) ?></b></a> <?= $badge(max(1, (int)$next['min_level'])) ?> <span class="nxvia">via <?= e($next['via']) ?> ›</span></p>
  <?php endif; ?>
  <details class="helpfold"><summary>❓ How travelling works</summary>
    <p class="help">You walk the underground mycelium one stop at a time. 🛣️ Roads run town to town past three villages. Next to home (towns, havens, villages with your garden) they match your level, or a few levels under it with <a href="<?= e(url('account.php#easyroads')) ?>">easy roads</a> on. Further along they stay at the recommended level of the region they lead into, so places you’ve outgrown stay easy: a quick walk 💨 takes only half the time. Wandering off the road starts as easy as the road you left and gets harder one step at a time; wild country, with bosses, starts at step <?= (int)setting('explore_wild_from') ?>. Past step <?= (int)setting('explore_deep_from') ?> lie the deep wilds, matched to your own level; areas you’ve outgrown give less XP and fewer Petals.
      🌿 Side paths lead to places you’ve found by wandering off the road. The badge is the danger level: green is fine for you, amber is a bit above, red is well above.
      Losing a fight never costs items: you wake up back where you started. Once you’ve walked to a region, you can fast travel there from the 🧭 Travel tab.</p>
  </details>
</div>
<?php return (string)ob_get_clean();
}

/** Seasons & weather fold (?tab=seasons opens it). */
function season_fold_html(array $u): string
{
    ob_start(); ?>
<?php // v2.0.4 menu folds: Seasons & weather (was seasons.php) is a fold here; ?tab=seasons opens it
$sRegion = hollow_user_region($u);
$sn = hollow_now($sRegion);
$sNext = hollow_next_season();
$sFc = hollow_forecast($sRegion, 3);
$sCh = hollow_weather_chances($sn['season'], $sRegion);
arsort($sCh);
$sRegions = q('SELECT code, gnomish_name AS name, real_name FROM regions ORDER BY id')->fetchAll(); ?>
<details class="fold box seasonfold" id="seasons"<?= ($_GET['tab'] ?? '') === 'seasons' ? ' open' : '' ?>>
  <summary><?= $sn['season_emoji'] ?> Seasons &amp; weather <small class="muted"><?= e($sn['season_label']) ?> · <?= $sn['weather_emoji'] ?> <?= e($sn['weather_label']) ?></small></summary><?php /* v2.3.x: name, then the state as a muted note (as the Road Journal fold), so it breaks between them, not mid-phrase */ ?>
  <p><b><?= e(hollow_line($sRegion)) ?></b></p>
  <p class="muted"><?= e(HOLLOW_SEASONS[$sn['season']][3]) ?> <?= e(HOLLOW_WEATHER[$sn['weather']][3]) ?>
    <?= $sn['mode'] === 'game' ? 'Day ' . $sn['season_day'] . ' of ' . $sn['season_length'] . '.' : 'Following the real calendar.' ?>
    <?= e(HOLLOW_SEASONS[$sNext['season']][0] . ' ' . HOLLOW_SEASONS[$sNext['season']][1]) ?> begins in <?= (int)$sNext['in_days'] ?> day<?= $sNext['in_days'] === 1 ? '' : 's' ?>.
    <?= $sn['season_forced'] || $sn['weather_forced'] ? '<br><small>(An override is on' . ($sn['season_forced'] ? ': season' : '') . ($sn['weather_forced'] ? ': today’s weather' : '') . '.)</small>' : '' ?></p>
  <h3>Forecast</h3>
  <div class="fcgrid">
  <?php foreach ($sFc as $f): ?>
    <div class="box"><b><?= e($f['label']) ?></b><div class="wxbig" aria-hidden="true"><?= $f['emoji'] ?></div><?= e($f['wlabel']) ?></div>
  <?php endforeach; ?>
  </div>
  <h3>The year</h3>
  <div class="seasonrow">
  <?php foreach (HOLLOW_SEASONS as $k => $s): ?>
    <div class="box<?= $k === $sn['season'] ? ' cur' : '' ?>"><div class="wxbig" aria-hidden="true"><?= $s[0] ?></div><b><?= e($s[1]) ?></b><br><small class="muted"><?= $sn['mode'] === 'game' ? hollow_season_length() . ' days' : '3 months' ?></small></div>
  <?php endforeach; ?>
  </div>
  <h3>What <?= e(HOLLOW_SEASONS[$sn['season']][1]) ?> weather is like</h3>
  <table class="wxtable">
  <?php foreach ($sCh as $k => $pct): if ($pct <= 0) continue; ?>
    <tr><td><?= HOLLOW_WEATHER[$k][0] ?> <?= e(HOLLOW_WEATHER[$k][1]) ?></td><td><?= $pct ?>%</td></tr>
  <?php endforeach; ?>
  </table>
  <h3>Around the world today</h3>
  <table class="wxtable">
  <?php foreach ($sRegions as $r): $w = hollow_weather_info(hollow_weather($r['code']), 'day'); ?>
    <tr><td><?= e($r['name']) ?> <small class="muted">(<?= e($r['real_name']) ?>)</small></td><td><?= $w['emoji'] ?> <?= e($w['label']) ?></td></tr>
  <?php endforeach; ?>
  </table>
  <?php if (is_admin()): ?><p class="help"><a href="<?= e(url('admin/settings.php#s-seasons-weather')) ?>">Admin: seasons &amp; weather settings and overrides</a></p><?php endif; ?>
</details>
<?php return (string)ob_get_clean();
}

/** Land for sale / your garden card at village stops. */
function land_card_html(array $u, array $node, ?array $nodeRegion): string
{
    ob_start(); ?>
<?php if ($node['kind'] === 'village' && $node['region_id']):
    $mine = q_one('SELECT * FROM plots WHERE user_id = ? AND region_id = ?', [$u['id'], $node['region_id']]);
    $owned = (int)q_val('SELECT COUNT(*) FROM plots WHERE user_id = ?', [$u['id']]); ?>
  <div class="box deed">
    <?php if ($mine): ?>
      🏡 Your garden in <?= e($nodeRegion['gnomish_name'] ?? 'this region') ?>: <b><?= eu($mine['garden_name'] ?: 'Garden') ?></b>.
    <?php elseif ($owned < max_gardens($u)): ?>
      📜 Land for sale: start a garden here for <b><?= money(deed_cost((int)$u['id'])) ?></b>. Native crops grow faster at home.
      <form method="post" action="<?= e(url('world.php')) ?>" class="inline" data-confirm="Buy a land deed here for <?= number_format(deed_cost((int)$u['id'])) ?>?"><?= csrf_field() ?>
        <input type="hidden" name="do" value="deed"><button class="btn small">Buy land deed</button></form>
    <?php else: ?>
      <span class="muted">📜 Land for sale here<?= next_garden_level($u) ? ' (another garden from gnome level ' . next_garden_level($u) . ')' : ' (you tend as many gardens as a gnome can)' ?>.</span>
    <?php endif; ?>
  </div>
<?php endif; ?>
<?php return (string)ob_get_clean();
}

// Town helpers moved from town.php (phase 1b, unchanged)
/** Who's at a place: little links to each NPC. */
function npc_faces(array $npcs, bool $names): string
{
    $h = '';
    foreach ($npcs as $n) {
        $h .= '<a class="npcface" href="' . e(url('villagers.php?id=' . (int)$n['id'])) . '" data-folk-npc="' . (int)$n['id'] . '" title="' . e($n['name']) . '">' . npc_icon($n['species'])
            . ($names ? ' ' . e($n['name']) . (!empty($n['traveller']) ? ' <small class="tag">traveller</small>' : '') : '') . '</a>';
    }
    return $h;
}

/** One place's things to do. */
function action_buttons(array $s, array $u, array $uses, string $q): string
{
    $closed = spot_closed($s);
    $h = '<div class="tacts">';
    foreach (town_actions((int)$s['id']) as $a) {
        if ($a['kind'] === 'link') {
            $h .= '<a class="btn act alt" href="' . e(url((string)$a['link'])) . '">' . e($a['label']) . '</a>';
            continue;
        }
        $left = (int)$a['daily'] > 0 ? (int)$a['daily'] - ($uses[(int)$a['id']] ?? 0) : null;
        $cost = town_cost_label($a);
        $chance = town_chance($u, $a);
        // v0.7.61: "any seed" / "any food" costs let you choose which one, in a pop-up of your satchel
        $pick = in_array($a['cost_item'], ['anyseed', 'anyfood'], true) ? (string)$a['cost_item'] : '';
        $h .= '<form method="post" class="tact"' . ($pick ? ' data-needpick="' . $pick . '"' : '') . '>' . csrf_field() . '<input type="hidden" name="do" value="act">'
            . '<input type="hidden" name="action_id" value="' . (int)$a['id'] . '"><input type="hidden" name="spot" value="' . (int)$s['id'] . '">'
            . ($pick ? '<input type="hidden" name="item_id" value="0">' : '')
            . ($q !== '' ? '<input type="hidden" name="hub" value="1">' : '')
            . '<button class="btn act"' . ($closed || $left === 0 ? ' disabled' : '') . '>' . (str_ends_with((string)$a['slug'], '-drink') ? '☕ ' : '') . e($a['label']) . ($cost !== '' ? ' <span class="cost">' . e($cost) . '</span>' : '') . '</button>'
            . (str_ends_with((string)$a['slug'], '-drink') ? ' <button class="btn act alt" name="togo" value="1"' . ($closed || $left === 0 ? ' disabled' : '') . '>🥤 Take it to go</button>' : '')
            . '<small class="muted">' . ($left === null ? '' : ($left > 0 ? $left . ' left today' : 'done for today'))
            . ($chance < 100 ? ' · ' . $chance . '% chance' : '') . '</small></form>';
    }
    return $h . '</div>';
}

/** v0.7.66: the townsfolk's favours (on the Notice Board and in the square's Quests tab). $sid 0 = from the Quests tab. */
function town_favours_box(int $uid, string $town, bool $hub, int $sid): void
{
    if (setting('orders_on') === '1') { orders_board_box($uid, $town, $hub, $sid); return; }   // v1.0.0 wave 2b: orders replace the flat weekly favours (admin can switch back)
    $folk = town_folk($town); ?>
    <div class="box favours"><h3>📌 Favours from the townsfolk</h3>
      <?php $shown = 0; foreach ($folk as $n): $o = favour_offer($uid, $n, $town); if (!$o) continue; $shown++;
          $have = (int)q_val('SELECT qty FROM user_items WHERE user_id = ? AND item_id = ?', [$uid, $o['item']['id']]); ?>
        <div class="favour<?= $o['done'] ? ' done' : '' ?>"><span class="ficon"><?= npc_icon($n['species']) ?></span>
          <div><b><a href="<?= e(url('villagers.php?id=' . (int)$n['id'])) ?>"><?= e($n['name']) ?></a></b>: “Could you bring me <?= (int)$o['qty'] ?> × <?= e($o['item']['name']) ?>?”
            <br><small class="muted">Reward: <?= money($o['coins']) ?>, 10 XP and friendship · you have <?= $have ?></small></div>
          <?php if ($o['done']): ?><span class="muted">✔️ Done this week</span>
          <?php else: ?><form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="favour"><input type="hidden" name="npc" value="<?= (int)$n['id'] ?>">
            <input type="hidden" name="spot" value="<?= $sid ?>"><?php if (!$sid): ?><input type="hidden" name="view" value="quests"><?php endif; ?><?php if ($hub): ?><input type="hidden" name="hub" value="1"><?php endif; ?>
            <button class="btn small" <?= $have < $o['qty'] ? 'disabled' : '' ?>>Deliver</button></form><?php endif; ?>
        </div>
      <?php endforeach; ?>
      <?php if (!$shown): ?><p class="muted">Nothing for you yet. Chat with the townsfolk: once they know you (Acquaintance or better), they’ll pin a favour here each week.</p><?php endif; ?>
      <?php if ($folk && $shown < count($folk)): ?><p class="help">Townsfolk who don’t know you yet: <?= e(implode(', ', array_map(fn($n) => $n['name'], array_filter($folk, fn($n) => !favour_offer($uid, $n, $town))))) ?>.</p><?php endif; ?>
    </div>
<?php
}

/** v0.7.61: a pop-up of the player's seeds or food to choose from (used by "Feed the birds" and "Have a picnic"). */
function town_pickers(int $uid): string
{
    require_once __DIR__ . '/item_square.php';   // v2.0.67: the choices are item squares (hooks .pcard[data-id], .pickgrid kept)
    $out = '';
    foreach (['anyseed' => ['seed', 'Which seeds for the birds?'], 'anyfood' => ['food', 'What will you eat? You get its energy, plus 1 for the fresh air.']] as $kind => [$cat, $title]) {
        $items = q('SELECT i.*, ui.qty FROM user_items ui JOIN items i ON i.id = ui.item_id
                    WHERE ui.user_id = ? AND ui.qty > 0 AND i.category = ? ORDER BY i.base_price, i.name', [$uid, $cat])->fetchAll();
        $cards = '';
        foreach ($items as $i) {
            $cards .= item_square(['item' => $i, 'count' => (int)$i['qty'], 'class' => 'pcard', 'attrs' => ['data-id' => (int)$i['id']]]);
        }
        $out .= '<dialog class="picker townpick" data-kind="' . $kind . '" aria-label="' . e($title) . '"><div class="pickbox">'
            . '<div class="pickhead"><b>' . e($title) . '</b> <span class="muted">cheapest first</span><button type="button" class="pickx" aria-label="Close">✕</button></div>'
            . ($cards !== '' ? item_grid($cards, 'pickgrid') : '<p class="muted">You don’t have any.</p>')
            . '</div></dialog>';
    }
    return $out;
}

/** Shared place tabs. $tabs = [key => [label, href, badge text or '']]. $class: 'tabs' or 'tabs st-tabs'. */
function place_tabs_html(array $tabs, string $active, string $label = 'Place sections', string $class = 'tabs'): string
{
    $h = '<nav class="' . e($class) . '" aria-label="' . e($label) . '">';
    foreach ($tabs as $k => [$lab, $href, $badge]) {
        if (is_array($href)) {   // a tab that submits a form elsewhere on the page: ['form' => form id]
            $h .= '<button type="submit" form="' . e((string)$href['form']) . '"' . (isset($href['title']) ? ' title="' . e((string)$href['title']) . '"' : '') . '>' . $lab . '</button>';
            continue;
        }
        $h .= '<a class="' . ($k === $active ? 'on' : '') . '" href="' . e($href) . '">' . $lab
            . ($badge !== '' ? ' <span class="st-tabbadge" title="' . e($badge) . '">' . e($badge) . '</span>' : '') . '</a>';
    }
    return $h . '</nav>';
}

/** The Stop tab body for any place: Orders link, Passport, Seasons, Land for sale (villages only). */
function stop_tab_html(array $u, array $node, bool $hub): string
{
    require_once __DIR__ . '/stop_pass.php';
    $uid = (int)$u['id'];
    foreach (stop_sets_check($uid) as $m) flash($m);   // a set can be complete after an admin changed the numbers
    $nodeRegion = !empty($node['region_id']) ? q_one('SELECT * FROM regions WHERE id = ?', [$node['region_id']]) : null;
    // v2.3.x: the same section head and note as the other Town tabs (Orders, Villagers); .st-page is the container the wide layout keys off
    $h = '<div class="st-page"><h2 class="gx-h">🛂 Stamp passport</h2><p class="gx-note gx-note--top">A stamp for every rest stop you visit. Sets pay rewards and titles.</p>';
    $titles = stop_titles($uid);
    $tf = '';
    if ($titles) {   // v2.3.x: a fold row inside the passport summary box, not a wall of tags above it
        $tf = '<details class="fold st-titles"><summary>Titles earned <small class="muted">' . count($titles) . '</small></summary><p class="st-tags">';
        foreach ($titles as $t) $tf .= '<span class="tag">“' . e($t) . '”</span> ';
        $tf .= '</p><a class="st-almanac" href="' . e(url('book.php?ch=Milestones')) . '">Choose yours in the Almanac →</a></details>';
    }
    require_once __DIR__ . '/road_life.php';
    $h .= stop_passport_html($u, $tf);
    $h .= '<p class="gx-note">📜 <a href="' . e(url('jobs.php?t=requests' . ($hub ? '&hub=1' : ''))) . '">Orders</a> · all open orders are on the Tasks page.</p>';
    $h .= '<div class="st-folds">' . road_journal_html($uid) . season_fold_html($u) . '</div>' . land_card_html($u, $node, $nodeRegion);
    return $h . '</div>';
}

/**
 * v2.5.53: the slim Rest stop card for the Here picture (a popover): your stamps, then the two things a stop offers: "Take hold here" (adopt this stop) and
 * "Garden here" (the land deed). Forms carry data-vform, so assets/hubscene.js posts them to town.php in place and the card comes back with the result.
 */
function stop_slim_card_html(array $u, array $node, bool $hub, string $msg = '', bool $ok = true): string
{
    require_once __DIR__ . '/stop_pass.php';
    require_once __DIR__ . '/stop_adopt.php';
    $uid = (int)$u['id'];
    if (($node['kind'] ?? '') === 'village') stop_stamp($uid, $node);   // v2.5.54: being here is the visit
    $stamps = count(stop_stamps_of($uid));
    $total = count(stop_road_stops());
    $here = (bool)q_val('SELECT 1 FROM stop_stamps WHERE user_id = ? AND location_id = ?', [$uid, (int)$node['id']]);
    $form = fn(string $do, string $kind, string $btn, string $ask = '') => '<form method="post" class="inline" data-vform' . ($ask !== '' ? ' data-confirm="' . e($ask) . '"' : '') . '>'
        . '<input type="hidden" name="do" value="' . $do . '">' . ($kind !== '' ? '<input type="hidden" name="kind" value="' . $kind . '">' : '') . '<input type="hidden" name="card" value="stop">' . $btn . '</form>';
    $h = '<div class="st-slim">' . ($msg !== '' ? '<p class="' . ($ok ? 'good' : 'bad') . '" role="status">' . e($msg) . '</p>' : '')
        . '<p class="st-sumline"><b>' . $stamps . '</b> of ' . $total . ' road stops stamped' . ($here ? ' · ✅ this one' : '') . '</p>'
        . '<progress max="' . max(1, $total) . '" value="' . $stamps . '" aria-label="Road stops stamped"></progress>';
    $h .= '<div class="st-slim__acts">';
    // Take hold here: adopt this stop
    if ($node['kind'] === 'village' && on_road((int)$node['id']) && (stop_adopt_limit() > 0 || stop_adoption((int)$node['id']))) {
        $a = stop_adoption((int)$node['id']);
        $h .= '<div class="box"><b>🏡 Take hold here</b>';
        if ($a && (int)$a['user_id'] === $uid) {
            $done = ($a['perk_day'] ?? '') === hollow_date('Y-m-d');
            $h .= '<p>You look after ' . e($node['name']) . '. Tier ' . (int)$a['tier'] . '.</p>'
                . $form('local', '_perk', '<button class="btn small"' . ($done ? ' disabled' : '') . '>🎁 ' . ($done ? 'Welcome taken today' : 'Collect the welcome') . '</button>')
                . stop_slim_needs($u, $node, $a, $form);
        } elseif ($a && $a['user_id']) {
            $h .= '<p class="muted">Looked after by ' . e(stop_gnome_label($a)) . '.</p>';
        } else {
            [$slots, $count] = stop_adopt_slots($uid);
            $fee = max(0, (int)setting('stop_adopt_cost'));
            $why = !$here ? 'Collect this stop’s stamp first (it comes with your first visit).' : ($count >= $slots ? 'You look after ' . $count . ' of ' . $slots . ' stops already.' : '');
            $h .= '<p>Look after it and it grows a bench, a stall, a well and a hall for everyone. Costs ' . money($fee) . '.</p>'
                . ($why === '' ? $form('local', '_adopt', '<button class="btn small">🏡 Take hold of ' . e($node['name']) . '</button>', 'Take hold of ' . $node['name'] . ' for ' . number_format($fee) . '?') : '<p class="muted">' . e($why) . '</p>');
        }
        $h .= '</div>';
    }
    // Garden here: the land deed (or your garden in this region)
    if ($node['kind'] === 'village' && $node['region_id']) {
        $plot = q_one('SELECT * FROM plots WHERE user_id = ? AND region_id = ?', [$uid, $node['region_id']]);
        $owned = (int)q_val('SELECT COUNT(*) FROM plots WHERE user_id = ?', [$uid]);
        $h .= '<div class="box"><b>🌱 Garden here</b>';
        if ($plot) $h .= '<p>Your garden here: <b>' . eu($plot['garden_name'] ?: 'Garden') . '</b>.</p><a class="btn small" href="' . e(url('garden.php')) . '">Open your garden ›</a>';
        elseif ($owned < max_gardens($u)) $h .= '<p>Land for sale: <b>' . money(deed_cost($uid)) . '</b>. Native crops grow faster at home.</p>'
            . $form('deed', '', '<button class="btn small">📜 Buy land deed</button>', 'Buy a land deed here for ' . number_format(deed_cost($uid)) . '?');
        else $h .= '<p class="muted">' . (next_garden_level($u) ? 'Another garden from gnome level ' . next_garden_level($u) . '.' : 'You tend as many gardens as a gnome can.') . '</p>';
        $h .= '</div>';
    }
    return $h . '</div><p class="vmore"><a href="' . e(url('town.php?view=passport')) . '">Full passport, sets and seasons ›</a></p>';
}

/** v2.5.54: the next upgrade's needs of a stop you look after, each with a hand-in box, for the Rest stop popover (posts in place; _give). */
function stop_slim_needs(array $u, array $node, array $a, callable $form): string
{
    $tiers = stop_tiers_for($node);
    $next = (int)$a['tier'] + 1;
    if (!isset($tiers[$next])) return '<p class="good"><b>🎉 Every upgrade is built.</b></p>';
    $pool = stop_pool_of($a);
    $h = '<p><b>Next: ' . e((string)$tiers[$next]['name']) . '</b> needs:</p><ul class="st-needs">';
    foreach (stop_tier_needs($tiers[$next]) as [$k, $q]) {
        $given = min($q, (int)($pool[$k] ?? 0));
        $have = stop_need_have($u, $k);
        $left = $q - $given;
        $h .= '<li class="' . ($left <= 0 ? 'good' : '') . '"><span>' . ($left <= 0 ? '✅ ' : '') . e(stop_need_label($k)) . ' <b>' . $given . '/' . $q . '</b> <small class="muted">(you have ' . number_format($have) . ')</small></span>';
        if ($left > 0) {
            $max = max(1, min($left, $have));
            $h .= $form('local', '_give', '<input type="hidden" name="need" value="' . e($k) . '"><input type="number" name="qty" min="1" max="' . $left . '" value="' . $max . '" aria-label="How many"> <button class="btn small"' . ($have < 1 ? ' disabled' : '') . '>Hand in</button>');
        }
        $h .= '</li>';
    }
    return $h . '</ul>';
}

/** Main-stop tabs: Square, Villagers, Shops, Orders, Stop. $folkCount badges Villagers (0 = none). v2.0.67: in town, Shops and Orders are town.php views
 *  (old world.php?tab=markets and jobs.php?t=orders links still work); labels are one word after the icon (the strip never wraps). */
function main_stop_tabs(bool $hub, bool $inTown, string $active, int $folkCount = 0): array
{
    $q = $hub ? 'hub=1&' : '';
    return [
        'square' => ['🏘️ ' . ($inTown ? 'Square' : 'Here'), url('town.php' . ($hub ? '?hub=1' : '')), ''],
        'villagers' => ['👥 Villagers', url('town.php?' . $q . 'view=villagers'), $folkCount > 0 ? (string)$folkCount : ''],
        'shops' => ['🏪 Shops', $inTown ? url('town.php?' . $q . 'view=shops') : url('world.php?tab=markets'), ''],
        'orders' => ['📜 Orders', $inTown ? url('town.php?' . $q . 'view=orders') : url('jobs.php?t=requests' . ($hub ? '&hub=1' : '')), ''],   // 5th tab for now (Joshua, 2026-10-27)
        'stop' => ['🛂 Stop', url('town.php?' . $q . 'view=stop'), ''],
    ];
}

/** v2.0.67: the main-stop tab strip (mockup3): stitched leather, icon over a one-word label, one row at any width. $tabs from main_stop_tabs(). */
function main_stop_tabs_html(array $tabs, string $active, string $label = 'Town sections'): string
{
    $h = '<nav class="mtabs" aria-label="' . e($label) . '">';
    foreach ($tabs as $k => [$lab, $href, $badge]) {
        [$ic, $word] = array_pad(explode(' ', (string)$lab, 2), 2, '');
        $on = $k === $active;
        $h .= '<a class="mtabs__a' . ($on ? ' on' : '') . '" href="' . e($href) . '" data-inplace' . ($on ? ' aria-current="page"' : '') . '>'
            . '<span class="mtabs__ic" aria-hidden="true">' . $ic . '</span><span class="mtabs__t">' . $word . '</span>'
            . ($badge !== '' ? '<span class="mtabs__badge" aria-hidden="true">' . e($badge) . '</span><span class="vh">, ' . e($badge) . ' in town now</span>' : '') . '</a>';
    }
    return $h . '</nav>';
}

/** v2.0.67: Square card art for a town place: its own picture (a few specials), the kind's, else the signpost fallback. Path from the web root. */
const TOWN_PLACE_ART_SLUG = ['sp-grind' => 'grind', 'sp-monastery' => 'monastery', 'mm-stones' => 'stones', 'mm-pub' => 'pub'];
function town_place_art(array $s): string
{
    $dir = __DIR__ . '/../assets/img/town/';
    foreach ([TOWN_PLACE_ART_SLUG[(string)($s['slug'] ?? '')] ?? '', (string)($s['kind'] ?? ''), 'special'] as $n) {
        if ($n !== '' && preg_match('/^[a-z0-9_-]+$/', $n) && is_file($dir . 'place-' . $n . '.png')) return 'assets/img/town/place-' . $n . '.png';
    }
    return '';
}

/** v2.0.67: Shops card art per shops.shop_type, else the signpost. */
function town_shop_art(string $type): string
{
    $dir = __DIR__ . '/../assets/img/town/';
    if (preg_match('/^[a-z0-9_-]+$/', $type) && is_file($dir . 'shop-' . $type . '.png')) return 'assets/img/town/shop-' . $type . '.png';
    return is_file($dir . 'place-special.png') ? 'assets/img/town/place-special.png' : '';
}

/** A 144x108 felt-card picture (decorative). */
function felt_art_img(string $path): string
{
    return $path !== '' ? '<img class="pix" src="' . e(url($path)) . '" width="144" height="108" alt="" loading="lazy" decoding="async">' : '';
}

/**
 * v2.0.67: one Square place card (mockup3): a felt card that links to the place (closed places stay links: a shut place can still be read).
 * States: idle; all done today (stone felt, tick); closed by the clock (padlock, the hours in words); closed for repairs (barrier);
 * found only here (kind special: gold stitch, gold sign, star).
 */
function town_place_card(array $s, int $uid, array $uses, string $q): string
{
    require_once __DIR__ . '/journey.php';
    $closed = spot_closed($s);
    $acts = array_filter(town_actions((int)$s['id']), fn($a) => $a['kind'] !== 'link');
    $todo = 0;
    foreach ($acts as $a) if ((int)$a['daily'] <= 0 || ($uses[(int)$a['id']] ?? 0) < (int)$a['daily']) $todo++;
    $jl = journey_lock($uid, 'spot', (string)$s['slug']);
    $gold = ($s['kind'] ?? '') === 'special';
    $state = $jl ? ' is-repair' : ($closed ? ' is-closed' : ($acts && !$todo ? ' is-done' : ''));
    $chip = $jl ? '<span class="pchip pchip--repair">🚧 closed for repairs</span>'
        : ($closed ? '<span class="pchip pchip--closed">🔒 ' . e($closed) . '</span>'
        : ($acts ? ($todo ? '<span class="pchip pchip--todo">' . $todo . ' thing' . ($todo === 1 ? '' : 's') . ' to do</span>' : '<span class="pchip pchip--done">✔️ all done today</span>')
        : '<span class="pchip pchip--look">Have a look</span>'));
    $folk = '';
    foreach (npcs_at_spot($s) as $n) $folk .= '<span aria-hidden="true" title="' . e($n['name']) . '">' . npc_icon($n['species']) . '</span><span class="vh">' . e($n['name']) . ' is here.</span>';
    $gc = gnome_count_at_spot((int)$s['id'], $uid);
    if ($gc) $folk .= ($folk !== '' ? ' ' : '') . '🧑‍🌾 ' . $gc . ' gnome' . ($gc === 1 ? '' : 's') . ' here';
    return '<a class="gcard placecard' . ($gold ? ' placecard--gold' : '') . $state . '" href="' . e(url('town.php?' . $q . 'spot=' . (int)$s['id'])) . '">'
        . '<span class="gcard__art">' . felt_art_img(town_place_art($s)) . '</span>'
        . '<span class="gcard__ribbon"><span class="gcard__label">' . e($s['name']) . '</span>' . ($gold ? '<span class="vh">, found only here</span>' : '') . '</span>'
        . '<span class="gcard__meta">' . $chip . ($folk !== '' ? '<span class="pfolk">' . $folk . '</span>' : '') . '</span></a>';
}

/** v2.0.67: the Shops tab of a main stop (mockup3): this town's shops, then Mossbottom's (reachable from anywhere). Same rules as world.php's Shops tab. */
function town_shops_html(array $u, string $town): string
{
    require_once __DIR__ . '/world.php';
    $list = fn(string $region): array => q('SELECT s.*, l.name AS loc_name, l.id AS loc_id FROM shops s JOIN locations l ON l.id = s.location_id
              WHERE l.region = ? AND s.open = 1 ORDER BY s.name', [$region])->fetchAll();
    $h = '';
    if ($town !== HUB_REGION) {
        $shops = $list($town);
        $h .= '<h3 class="gx-h">🏪 Shops in ' . e($town) . '</h3>' . ($shops ? '<ul class="scards">' . town_shop_cards($shops, $u) . '</ul>' : '<p class="gx-note">No shops here yet.</p>');
    }
    $hubShops = $list(HUB_REGION);
    $h .= '<h3 class="gx-h">🍄 Mossbottom hub <span class="gx-h__sub">reachable from anywhere</span></h3>'
        . ($hubShops ? '<ul class="scards">' . town_shop_cards($hubShops, $u) . '</ul>' : '<p class="gx-note">No shops here yet.</p>');
    return $h;
}

/** Shop cards: vignette per shop type, the name on a sign, the description, who is at the counter. Whole card = the link; closed shops stay links. */
function town_shop_cards(array $shops, array $u): string
{
    $out = '';
    foreach ($shops as $s) {
        $staff = staff_on_duty((int)$s['id']);
        $reach = shop_reachable($u, $s);
        $inner = '<span class="scard__art">' . felt_art_img(town_shop_art((string)($s['shop_type'] ?? ''))) . '</span>'
            . '<span class="scard__ribbon"><span class="scard__name">' . e($s['name']) . '</span></span>'
            . '<span class="scard__desc">' . e((string)$s['description']) . '</span>'
            . '<span class="scard__staff">' . ($staff ? 'At the counter: ' . e(implode(', ', array_column($staff, 'name'))) : 'Closed — nobody on shift') . '</span>';
        $cls = 'scard' . ($staff ? '' : ' is-closed');
        $out .= '<li>' . ($reach
            ? '<a class="' . $cls . '" href="' . e(url('shop.php?id=' . (int)$s['id'])) . '">' . $inner . '</a>'
            : '<div class="' . $cls . '">' . $inner . '<a class="scard__walk" href="' . e(url('world.php?go=' . (int)$s['loc_id'] . '#gopanel')) . '">🚶 Walk to ' . e((string)$s['loc_name']) . ' to shop here</a></div>') . '</li>';
    }
    return $out;
}

/** v2.0.67: the Orders tab of a main stop (mockup3): each order a pinned felt note. Same data and Deliver POST as orders_board_box (do=order to town.php). */
function town_orders_html(int $uid, string $town, bool $hub): string
{
    if (setting('orders_on') !== '1') { ob_start(); town_favours_box($uid, $town, $hub, 0); return (string)ob_get_clean(); }   // admin switched back to favours
    require_once __DIR__ . '/friends.php';
    $board = orders_board($town);
    $cy = orders_cycle();
    $next = date('D j M', strtotime(hollow_date_add($cy['end'], 1) . ' UTC'));
    $h = '<h3 class="gx-h" id="orders">📜 Orders from the townsfolk</h3>'
        . '<p class="gx-note gx-note--top">Fill an order before its deadline. Harder orders (a higher quality bar) pay more. New orders every ' . (int)$cy['len'] . ' days; next round ' . e($next) . '.</p>';
    if (!$board) return $h . '<p class="gx-note">No open orders in ' . e($town) . ' right now. The next round is pinned on ' . e($next) . '.</p>';
    $h .= '<ul class="ocards">';
    foreach ($board as ['npc' => $n, 'o' => $o]) {
        $done = order_done($uid, (int)$n['id'], $o['cycle']);
        $c = $done ? null : order_check($uid, $o);
        $d = (int)$o['diff'];
        $tags = '<span class="otag otag--stars" role="img" aria-label="Difficulty: ' . $d . ' of 3" title="Difficulty">' . str_repeat('★', $d) . str_repeat('☆', 3 - $d) . '</span>'
            . ($o['bar'] ? '<span class="otag">' . e($o['bar']) . '</span>' : '')
            . '<span class="otag' . ($o['days_left'] <= 1 ? ' otag--warn' : '') . '">⏳ ' . (int)$o['days_left'] . ' day' . ($o['days_left'] === 1 ? '' : 's') . ' left</span>';
        $rw = 'Reward: ' . money($o['coins']) . ', ' . (int)$o['xp'] . ' XP, +' . (int)$o['friend'] . ' friendship' . ($o['reward_item'] ? ', 🎁 ' . e($o['reward_item']['name']) : '');
        if ($c) $rw .= ' · you have ' . (int)$c['have'] . ($c['quality'] !== null && ($o['kind'] === 'arrangement' || $o['minq'] > 0) ? ' (' . ($o['kind'] === 'arrangement' ? 'best ' . (int)$c['quality'] : 'grade ' . e(market_grade((int)$c['quality'])) . ', ' . (int)$c['quality']) . ')' : '') . ($c['note'] ? ' · ' . e($c['note']) : '');
        $foot = $done ? '<span class="ocard__done">✔️ Delivered</span>'
            : '<form method="post">' . csrf_field() . '<input type="hidden" name="do" value="order"><input type="hidden" name="npc" value="' . (int)$n['id'] . '">'
              . '<input type="hidden" name="spot" value="0"><input type="hidden" name="view" value="orders">' . ($hub ? '<input type="hidden" name="hub" value="1">' : '')
              . '<button class="fbtn ocard__act"' . ($c['enough'] ? '' : ' disabled') . '>Deliver</button></form>';
        $h .= '<li class="ocard' . ($done ? ' is-done' : '') . '">'
            . '<a class="ocard__who" href="' . e(url('villagers.php?id=' . (int)$n['id'])) . '" data-folk-npc="' . (int)$n['id'] . '"><span class="ocard__face">' . npc_portrait($n, 'small') . '</span><span class="vlcard__ribbon"><span class="vlcard__name">' . e($n['name']) . '</span></span></a>'
            . '<p class="ocard__q">“' . e($o['text']) . '”</p><p class="ocard__tags">' . $tags . '</p><p class="ocard__rw">' . $rw . '</p>'
            . '<div class="ocard__foot">' . $foot . '</div></li>';
    }
    return $h . '</ul>';
}

/** v2.0.61: the place switcher bar: World / Here / Mossbottom. $active: 'world', 'here' or 'hub'. */
function place_switcher_html(array $node, string $active): string
{
    $items = [
        'world' => ['🌍 <span>World</span>', url('world.php')],
        'here' => ['📍 <span>' . e((string)$node['name']) . '</span>', url('town.php')],
        'hub' => ['🍄 <span>Mossbottom</span>', url('town.php?hub=1')],
    ];
    $h = '<nav class="psw" aria-label="Where to">';
    foreach ($items as $k => [$lab, $href]) $h .= '<a class="' . ($k === $active ? 'on' : '') . '" href="' . e($href) . '"' . ($k === $active ? ' aria-current="page"' : '') . '>' . $lab . '</a>';
    return $h . '</nav>';
}

/** Place header: scene art (a file in assets/img/scenes/, temporarily red-outlined for review), kicker line, name, optional line and chips. */
function place_header_html(string $art, string $alt, string $kicker, string $title, string $line = '', array $chips = []): string
{
    $hasArt = $art !== '' && is_file(__DIR__ . '/../assets/img/scenes/' . $art);
    $h = '<header class="ph' . ($hasArt ? '' : ' ph-noart') . '">';   // v2.0.65: the name sits on a felt sign under (phone) or beside (desktop) the art
    if ($hasArt) {
        $h .= '<figure class="ph-art"><img src="' . e(url('assets/img/scenes/' . $art)) . '" alt="' . e($alt) . '" width="480" height="240" decoding="async"></figure>';
    }
    $h .= '<div class="ph-body"><p class="ph-kick">' . e($kicker) . '</p><h1>' . e($title) . '</h1>'
        . ($line !== '' ? '<p class="ph-amb">' . e($line) . '</p>' : '');
    if ($chips) $h .= '<p class="ph-chips">' . implode('', array_map(fn($c) => '<span class="chip">' . $c . '</span>', $chips)) . '</p>';
    return $h . '</div></header>';
}

/** Daypart, weather and season chips for a place header (HTML-escaped text, emoji included). */
function place_chips(array $u): array
{
    $n = hollow_now(hollow_user_region($u));
    return [e($n['daypart_emoji'] . ' ' . $n['daypart_label']), e($n['weather_emoji'] . ' ' . $n['weather_label']), e($n['season_emoji'] . ' ' . $n['season_label'] . ' ' . $n['season_day'])];
}

/** v2.0.65: the one villager row (main stop and rest stop). $face and $action are ready HTML; $lines are ready HTML lines; $extra (errands) folds under the row.
 *  v2.0.67: a felt row (mockup3) as an <li> for a <ul class="vlcards">: face + name sign (one link when $href is given), the lines, one action; $badge = ready HTML. */
function villager_row_html(string $face, string $name, array $lines, string $action = '', string $extra = '', string $extraTitle = '', bool $open = false, string $badge = '', string $href = '', string $whoAttr = ''): string
{
    $who = '<span class="vlcard__face">' . $face . '</span><span class="vlcard__ribbon"><span class="vlcard__name">' . $name . '</span></span>';
    $h = '<li class="vlcard">' . ($href !== '' ? '<a class="vlcard__who" href="' . e($href) . '"' . $whoAttr . '>' . $who . '</a>' : '<span class="vlcard__who">' . $who . '</span>');
    $h .= ($action !== '' ? '<span class="vlcard__act">' . $action . '</span>' : '') . '<span class="vlcard__main">';
    foreach ($lines as $l) if ($l !== '') $h .= '<span class="vlcard__sub">' . $l . '</span>';
    $h .= $badge . '</span>';
    if ($extra !== '') $h .= '<details class="vfold vlcard__fold"' . ($open ? ' open' : '') . '><summary>' . $extraTitle . '</summary>' . $extra . '</details>';
    return $h . '</li>';
}
