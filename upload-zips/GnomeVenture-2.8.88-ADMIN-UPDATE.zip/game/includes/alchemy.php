<?php
declare(strict_types=1);
/**
 * Alchemy Table: the potions after the first Healing Potion (that one lives in pal_jobs.php).
 * Items are made here (adds only, safe to repeat), recipes come from data/crafts.txt (category potions).
 * Icons: assets/img/ph/<slug>.png; until art is installed they show 🧪 (NAME_EMOJI) or the soil emoji.
 *  - Healing tiers: heal a pal at home (pj_heal) and the gnome (My Gnome Health box, hp_use).
 *  - Drinks (edible): a timed buff through eat_item, so they take the meal-buff slot.
 *  - Lucky Draught: drink it, or pack one on a pal's gathering trip (+ALCHEMY_LUCK_PAL luck for that trip).
 *  - Garden Tonic: a soil improver; the garden 'soil' action reads its effects like compost.
 */

/** slug => [name, item category, rarity, price, edible, effects or null, description] */
const ALCHEMY_ITEMS = [
    'strong-healing-potion' => ['Strong Healing Potion', 'supply', 14, 130, 0, null,
        'A deep green tonic that fizzes. A pal drinks it for +24 HP; you get back three quarters of your health.'],
    'grand-healing-elixir' => ['Grand Healing Elixir', 'supply', 22, 400, 0, null,
        'Thick, golden and smells of mountain flowers. Heals a pal or you completely.'],
    'lucky-draught' => ['Lucky Draught', 'supply', 10, 70, 1, ['temp' => ['luck' => 6, 'minutes' => 90]],
        'Sparkly pink and slightly ticklish. Drink it for Luck +6, or pack one for a pal on a gathering trip (Luck +4 for the trip).'],
    'sages-draught' => ['Sage’s Draught', 'supply', 10, 70, 1, ['temp' => ['lore' => 4, 'sense' => 2, 'minutes' => 120]],
        'A bitter blue tea that makes old words easy to read. Lore +4, Sense +2.'],
    'stoneskin-brew' => ['Stoneskin Brew', 'supply', 10, 65, 1, ['temp' => ['hardiness' => 4, 'grit' => 2, 'minutes' => 90]],
        'Muddy, gritty and very good for you. Hardiness +4, Grit +2.'],
    'swiftfoot-elixir' => ['Swiftfoot Elixir', 'supply', 10, 70, 1, ['temp' => ['nimble' => 4, 'sense' => 2, 'minutes' => 90]],
        'Light as dragonfly wings, with a berry bite. Nimble +4, Sense +2.'],
    'garden-tonic' => ['Garden Tonic', 'soil', 6, 30, 0, ['fertility' => 10, 'n' => 10, 'p' => 10, 'k' => 10, 'life' => 4, 'minutes' => 5],
        'A green bottle of seaweed and meadow herbs. Pour it on a square: fertility +10, nitrogen, phosphorus and potassium +10 each, soil life +4, within 5 minutes.'],
    // 2.7.58 tool augments (includes/augments.php): fitted to a tool from the Satchel, one at a time
    'aug-hide-binding' => ['Hide Binding', 'supply', 12, 15, 0, null,
        'Strips of hide bound round the handle. Fit it to a tool from your Satchel: its wear limit is 25% longer. Stays until the tool is replaced.'],
    'aug-hide-binding-2' => ['Hide Binding II', 'supply', 30, 105, 0, null,
        'A rare hide, waxed and bound twice. Fit it to a tool: its wear limit is 50% longer. A Fine or Masterwork tool also takes one rare Hide part.'],
    'aug-plate-edge' => ['Plate Edge', 'supply', 14, 26, 0, null,
        'A creature plate ground to an edge. Fit it to a gathering tool: 25% of finds are one rarity higher, even above what the tool could gather alone. 40 uses.'],
    'aug-wing-fletch' => ['Wing Fletch', 'supply', 14, 24, 0, null,
        'Feathers tied on for the draught. Fit it to a gathering tool: 35% chance of one extra item per find. 25 uses.'],
    'aug-gem-charm' => ['Gem Charm', 'supply', 20, 26, 0, null,
        'A bead in a blob of ooze, strung on a cord. Fit it to a gathering tool: Luck +4 when the find is picked. 30 uses.'],
    'aug-ooze-salve' => ['Ooze Salve', 'supply', 10, 9, 0, null,
        'Sticky grey salve that seals cracks. Fit it to a tool: the next 3 mends that would cost Petals are free.'],
    'aug-silk-lashing' => ['Silk Lashing', 'supply', 16, 49, 0, null,
        'Silk wound tight round a repair kit. Fit it to a tool: a kit mend takes one fewer Tool Repair Kit (at least 1). 40 mends.'],
];

/** Healing tiers, weakest first: slug => [pal HP (0 = full), gnome % of max (0 = the hp_potion_percent setting)]. */
const ALCHEMY_HEAL = [
    'healing-potion' => [12, 0],
    'strong-healing-potion' => [24, 75],
    'grand-healing-elixir' => [0, 100],
];

const ALCHEMY_LUCK = 'lucky-draught';
const ALCHEMY_LUCK_PAL = 4;

/** Make the potion items. Adds only; never changes one that exists (admin edits stand). Returns how many were added. */
function alchemy_ensure_items(): int
{
    $n = 0;
    foreach (ALCHEMY_ITEMS as $slug => [$name, $cat, $rarity, $price, $edible, $fx, $desc]) {
        if (q_val('SELECT 1 FROM items WHERE slug = ?', [$slug])) continue;
        db_insert('items', ['name' => $name, 'slug' => $slug, 'category' => $cat, 'rarity' => $rarity, 'base_price' => $price,
            'description' => $desc, 'edible' => $edible, 'effects' => $fx ? json_encode($fx) : null, 'tradable' => 1]);
        $n++;
    }
    return $n;
}

/** The healing tiers this gnome holds: slug => ['id', 'name', 'qty', 'pal' (HP, 0 = full), 'pct' (gnome %)]. Only tiers with qty > 0. */
function alchemy_heals(int $uid): array
{
    $ph = implode(',', array_fill(0, count(ALCHEMY_HEAL), '?'));
    $by = [];
    foreach (q("SELECT i.id, i.slug, i.name, ui.qty FROM user_items ui JOIN items i ON i.id = ui.item_id
                WHERE ui.user_id = ? AND ui.qty > 0 AND i.slug IN ($ph)", array_merge([$uid], array_keys(ALCHEMY_HEAL)))->fetchAll() as $r) $by[(string)$r['slug']] = $r;
    $out = [];
    foreach (ALCHEMY_HEAL as $slug => [$pal, $pct]) {
        if (!isset($by[$slug])) continue;
        $out[$slug] = ['id' => (int)$by[$slug]['id'], 'name' => (string)$by[$slug]['name'], 'qty' => (int)$by[$slug]['qty'], 'pal' => $pal, 'pct' => alchemy_gnome_pct($slug)];
    }
    return $out;
}

/** Percent of the gnome's max health a healing tier gives. */
function alchemy_gnome_pct(string $slug): int
{
    $pct = ALCHEMY_HEAL[$slug][1] ?? 0;
    if ($pct > 0) return $pct;
    require_once __DIR__ . '/health.php';
    return hp_pct('hp_potion_percent', 50);
}

/** HP a healing tier gives a pal with $max HP. */
function alchemy_pal_heal(string $slug, int $max): int
{
    $n = ALCHEMY_HEAL[$slug][0] ?? 0;
    return $n > 0 ? $n : $max;
}

/** "+24 HP" or "Full HP" for a pal button. */
function alchemy_pal_label(string $slug): string
{
    $n = ALCHEMY_HEAL[$slug][0] ?? 0;
    return $n > 0 ? '+' . $n . ' HP' : 'Full HP';
}

function alchemy_item_id(string $slug): int
{
    static $ids = [];
    return $ids[$slug] ??= item_id_by_slug($slug);
}

function alchemy_count(int $uid, string $slug): int
{
    $id = alchemy_item_id($slug);
    return $id ? (int)q_val('SELECT qty FROM user_items WHERE user_id = ? AND item_id = ?', [$uid, $id]) : 0;
}

/** Drink a boost potion (an edible ALCHEMY_ITEMS entry) from My Gnome. Returns [ok, message]. */
function alchemy_drink(array $u, int $itemId): array
{
    $slug = (string)q_val('SELECT slug FROM items WHERE id = ?', [$itemId]);
    if (empty(ALCHEMY_ITEMS[$slug][4])) return [false, 'That isn’t a potion you can drink.'];
    require_once __DIR__ . '/gnome.php';
    [$ok, $msgs] = eat_item($u, $itemId);
    return [$ok, implode(' ', $msgs)];
}
